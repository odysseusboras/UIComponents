import { FormControl } from '@angular/forms';
import { firstError } from '@borassoft/ui-components';
import * as i0 from "@angular/core";
/**
 * The single password / secret-credential input used app-wide: masked by
 * default, with a trailing eye toggle that reveals the value until toggled
 * back. Takes the FormControl directly via [control] so the wrapped
 * mat-form-field surfaces validation errors through the shared firstError
 * helper without a CVA indirection.
 */
export declare class UiSharedPasswordFieldComponent {
    control: import("@angular/core").InputSignal<FormControl<string>>;
    labelKey: import("@angular/core").InputSignal<string>;
    autocomplete: import("@angular/core").InputSignal<string>;
    hintKey: import("@angular/core").InputSignal<string>;
    maxlength: import("@angular/core").InputSignal<number | null>;
    subscriptSizing: import("@angular/core").InputSignal<"fixed" | "dynamic">;
    protected revealed: import("@angular/core").WritableSignal<boolean>;
    protected firstError: typeof firstError;
    protected required: import("@angular/core").Signal<boolean>;
    protected toggle(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<UiSharedPasswordFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UiSharedPasswordFieldComponent, "ui-shared-password-field", never, { "control": { "alias": "control"; "required": true; "isSignal": true; }; "labelKey": { "alias": "labelKey"; "required": true; "isSignal": true; }; "autocomplete": { "alias": "autocomplete"; "required": false; "isSignal": true; }; "hintKey": { "alias": "hintKey"; "required": false; "isSignal": true; }; "maxlength": { "alias": "maxlength"; "required": false; "isSignal": true; }; "subscriptSizing": { "alias": "subscriptSizing"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=ui-shared-password-field.component.d.ts.map