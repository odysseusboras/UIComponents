import { TemplateRef } from '@angular/core';
import * as i0 from "@angular/core";
/**
 * One tab of <ui-shared-tabs>. Its content renders lazily, only while selected.
 * Label: `labelKey` (translated) or `label` (raw text). With `link` the tab is a route.
 */
export declare class UiSharedTabComponent {
    labelKey: import("@angular/core").InputSignal<string>;
    label: import("@angular/core").InputSignal<string>;
    /** Routed tab: a routerLink target (relative to the current route). The tabs strip then navigates and the app's <router-outlet> shows the page. */
    link: import("@angular/core").InputSignal<string | any[] | null>;
    icon: import("@angular/core").InputSignal<string>;
    content: import("@angular/core").Signal<TemplateRef<unknown>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UiSharedTabComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UiSharedTabComponent, "ui-shared-tab", never, { "labelKey": { "alias": "labelKey"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "link": { "alias": "link"; "required": false; "isSignal": true; }; "icon": { "alias": "icon"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}
//# sourceMappingURL=ui-shared-tab.component.d.ts.map