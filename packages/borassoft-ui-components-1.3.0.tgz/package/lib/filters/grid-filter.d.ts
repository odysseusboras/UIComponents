import { InjectionToken, Provider, Type } from '@angular/core';
import { AbstractControl } from '@angular/forms';
/**
 * What `<ui-shared-grid>` needs from a projected filter. The option/text inputs
 * provide it under `UI_GRID_FILTER`, so the same component is a form input on its
 * own and a grid filter once it has a `field` / `fields` / `clauseBuilder`.
 */
export interface UiGridFilter {
    /** OData clause for the applied value; null when it filters nothing. */
    clause(): string | null;
    isApplied(): boolean;
    /** Search: what the user typed or picked becomes the applied value. */
    applyPending(): void;
    /** Clear: back to the initial value. */
    clearAll(): void;
    /** The applied value, for a grid that remembers its view across reloads. */
    value(): unknown;
    /** Puts a remembered value back in place as both pending and applied. */
    restore(value: unknown): void;
}
export declare const UI_GRID_FILTER: InjectionToken<UiGridFilter>;
/** Registers a component's `filter` state under `UI_GRID_FILTER` so the grid finds it. */
export declare function provideGridFilter(component: () => Type<{
    filter: UiGridFilter;
}>): Provider;
export type ClauseBuilder<T> = (value: T) => string | null;
/** An OData string literal: `O'Brien` → `'O''Brien'`. */
export declare function odataString(value: string): string;
/** ANDs the non-empty clauses (each parenthesised when there is more than one); undefined when none. */
export declare function andClauses(clauses: readonly (string | null | undefined)[]): string | undefined;
/**
 * OData v4 literal for a filter value: numbers, booleans and GUIDs are written
 * bare (`Id eq 5`, `TypeId eq e059…`), everything else as a quoted string. A
 * string column holding GUID-shaped text needs its own `clauseBuilder`.
 */
export declare function odataLiteral(value: unknown): string;
/** `field eq <literal>`; null without a field. */
export declare function eqClause<T>(field: string | undefined | null): ClauseBuilder<T> | null;
/**
 * Pending vs applied value of an input used as a grid filter: the control holds
 * what the user typed/picked, the grid filters by the applied value, which only
 * moves on Search / Clear. Without a clause builder the input is not a filter
 * and every method is a no-op.
 */
export declare class GridFilterState<T> implements UiGridFilter {
    private control;
    private builder;
    private initial;
    /** `undefined` = still at the initial value. */
    private applied;
    constructor(control: () => AbstractControl, builder: () => ClauseBuilder<T> | null, initial?: () => T | null);
    isFilter(): boolean;
    /** Seeds the control with the initial value (e.g. the "active" pill). Call from ngOnInit. */
    init(): void;
    /** Puts a remembered value in place as both pending and applied (no Search needed). */
    restore(value: T): void;
    clause(): string | null;
    isApplied(): boolean;
    applyPending(): void;
    clearAll(): void;
    /** The value the grid filters by: what Search applied, else the initial one. */
    value(): T | null;
}
//# sourceMappingURL=grid-filter.d.ts.map