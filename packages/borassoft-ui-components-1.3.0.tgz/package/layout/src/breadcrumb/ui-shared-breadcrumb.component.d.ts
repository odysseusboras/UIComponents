import * as i0 from "@angular/core";
/**
 * Breadcrumb trail for the current URL, from the tree the app registers with
 * `provideUiBreadcrumbs`. Renders nothing with fewer than two crumbs. The last crumb is the
 * current page: its node label, or `currentLabel` (the page title) when the node has none.
 * `<ui-shared-page-header>` renders it above the title, so pages need not place it themselves.
 */
export declare class UiSharedBreadcrumbComponent {
    /** Label of the current page when its node has none (the page title). */
    currentLabel: import("@angular/core").InputSignal<string>;
    private router;
    private tree;
    private url;
    protected crumbs: import("@angular/core").Signal<import("@borassoft/ui-components/layout").UiBreadcrumb[]>;
    /** Whether a trail renders (two crumbs or more); the page header reads it. */
    readonly visible: import("@angular/core").Signal<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UiSharedBreadcrumbComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UiSharedBreadcrumbComponent, "ui-shared-breadcrumb", never, { "currentLabel": { "alias": "currentLabel"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=ui-shared-breadcrumb.component.d.ts.map