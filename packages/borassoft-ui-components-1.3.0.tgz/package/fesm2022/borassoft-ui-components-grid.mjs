import * as i0 from '@angular/core';
import { signal, inject, ElementRef, afterRender, Directive, input, output, computed, effect, DestroyRef, Component, contentChild, booleanAttribute, contentChildren, TemplateRef, NgZone, untracked } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { Subject, of, map } from 'rxjs';
import { switchMap, catchError } from 'rxjs/operators';
import * as i1$1 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i1 from '@angular/material/button';
import { MatButtonModule } from '@angular/material/button';
import * as i2 from '@angular/material/icon';
import { MatIconModule } from '@angular/material/icon';
import * as i4 from '@angular/material/menu';
import { MatMenuModule } from '@angular/material/menu';
import * as i5 from '@angular/material/tooltip';
import { MatTooltipModule } from '@angular/material/tooltip';
import * as i6 from '@angular/material/checkbox';
import { MatCheckboxModule } from '@angular/material/checkbox';
import * as i7 from '@angular/material/slide-toggle';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import * as i8 from '@angular/material/divider';
import { MatDividerModule } from '@angular/material/divider';
import * as i9 from '@angular/material/progress-spinner';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { UiTranslatePipe, UI_GRID_FILTER, UI_REFRESH, trackPointerDrag, uiStorage, andClauses } from '@borassoft/ui-components';
import { FormControl } from '@angular/forms';
import { UiSharedSelectComponent } from '@borassoft/ui-components/inputs';

/**
 * Tells whether the host rendered any element at all. Lets a template hide a
 * control whose projected content ended up empty (a row-actions menu with no
 * items for that row) without knowing what the content decides.
 *
 *   <div hidden uiEmpty #probe="uiEmpty"><ng-container [ngTemplateOutlet]="actions" /></div>
 *   @if (!probe.empty()) { ...trigger... }
 */
class UiEmptyDirective {
    empty = signal(true);
    el = inject(ElementRef);
    constructor() {
        afterRender({ read: () => this.empty.set(this.el.nativeElement.childElementCount === 0) });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiEmptyDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.25", type: UiEmptyDirective, isStandalone: true, selector: "[uiEmpty]", exportAs: ["uiEmpty"], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiEmptyDirective, decorators: [{
            type: Directive,
            args: [{ selector: '[uiEmpty]', standalone: true, exportAs: 'uiEmpty' }]
        }], ctorParameters: () => [] });

/**
 * Kendo-style pager: first / prev / page numbers (with ellipsis) / next /
 * last, plus a page-size dropdown and a "showing N–M of T" summary.
 *
 * Inputs are reactive (signals); navigation triggers <c>pageChange</c> /
 * <c>pageSizeChange</c> outputs — the parent (CoreGrid) owns the source of
 * truth and re-renders as the bound signals update.
 *
 * Page numbers are 1-based (matches OData $skip semantics and reads
 * naturally in the UI).
 */
class UiSharedPagerComponent {
    /** Current page (1-based). */
    page = input.required();
    /** Rows per page. */
    pageSize = input.required();
    /** Total rows in the unfiltered dataset (reported by the server). */
    total = input.required();
    /** Page-size options. Defaults to a common spread. */
    pageSizeOptions = input([10, 20, 50, 100]);
    pageChange = output();
    pageSizeChange = output();
    /** Total number of pages (at least 1, so the pager always renders). */
    totalPages = computed(() => Math.max(1, Math.ceil(this.total() / this.pageSize())));
    /** 1-based start index of the visible window for the summary line. */
    from = computed(() => this.total() === 0 ? 0 : (this.page() - 1) * this.pageSize() + 1);
    /** 1-based end index of the visible window for the summary line. */
    to = computed(() => Math.min(this.total(), this.page() * this.pageSize()));
    /**
     * The page-number buttons to render between Prev and Next.
     * `null` represents an ellipsis gap. Algorithm:
     *   - Always show first + last
     *   - Show current ± 1
     *   - Insert "…" wherever gaps appear
     */
    visiblePages = computed(() => {
        const current = this.page();
        const last = this.totalPages();
        if (last <= 7) {
            // Small set: show everything.
            return Array.from({ length: last }, (_, i) => i + 1);
        }
        const set = new Set([1, last, current, current - 1, current + 1]);
        const pages = [...set].filter(p => p >= 1 && p <= last).sort((a, b) => a - b);
        const out = [];
        for (let i = 0; i < pages.length; i++) {
            if (i > 0 && pages[i] - pages[i - 1] > 1)
                out.push(null); // ellipsis
            out.push(pages[i]);
        }
        return out;
    });
    goTo(p) {
        const clamped = Math.min(Math.max(1, p), this.totalPages());
        if (clamped !== this.page())
            this.pageChange.emit(clamped);
    }
    /** The page-size dropdown is the shared select, so it matches every other dropdown. */
    sizeControl = new FormControl(null);
    sizeOptions = computed(() => this.pageSizeOptions().map(n => ({ value: n, label: String(n) })));
    constructor() {
        effect(() => this.sizeControl.setValue(this.pageSize(), { emitEvent: false }));
        this.sizeControl.valueChanges
            .pipe(takeUntilDestroyed(inject(DestroyRef)))
            .subscribe(size => {
            if (size !== null && size !== this.pageSize())
                this.pageSizeChange.emit(size);
        });
    }
    canPrev = computed(() => this.page() > 1);
    canNext = computed(() => this.page() < this.totalPages());
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedPagerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: UiSharedPagerComponent, isStandalone: true, selector: "ui-shared-pager", inputs: { page: { classPropertyName: "page", publicName: "page", isSignal: true, isRequired: true, transformFunction: null }, pageSize: { classPropertyName: "pageSize", publicName: "pageSize", isSignal: true, isRequired: true, transformFunction: null }, total: { classPropertyName: "total", publicName: "total", isSignal: true, isRequired: true, transformFunction: null }, pageSizeOptions: { classPropertyName: "pageSizeOptions", publicName: "pageSizeOptions", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { pageChange: "pageChange", pageSizeChange: "pageSizeChange" }, ngImport: i0, template: "<nav class=\"ui-shared-pager\" [attr.aria-label]=\"'pager.label' | uiTranslate\">\n  <div class=\"ui-shared-pager__nav\">\n    <button mat-icon-button type=\"button\"\n            (click)=\"goTo(1)\" [disabled]=\"!canPrev()\"\n            [attr.aria-label]=\"'pager.first' | uiTranslate\">\n      <mat-icon>first_page</mat-icon>\n    </button>\n    <button mat-icon-button type=\"button\"\n            (click)=\"goTo(page() - 1)\" [disabled]=\"!canPrev()\"\n            [attr.aria-label]=\"'pager.prev' | uiTranslate\">\n      <mat-icon>chevron_left</mat-icon>\n    </button>\n\n    @for (p of visiblePages(); track $index) {\n      @if (p === null) {\n        <span class=\"ui-shared-pager__ellipsis\">\u2026</span>\n      } @else {\n        <button mat-button type=\"button\"\n                class=\"ui-shared-pager__page\"\n                [class.ui-shared-pager__page--current]=\"p === page()\"\n                [attr.aria-current]=\"p === page() ? 'page' : null\"\n                (click)=\"goTo(p)\">\n          {{ p }}\n        </button>\n      }\n    }\n\n    <button mat-icon-button type=\"button\"\n            (click)=\"goTo(page() + 1)\" [disabled]=\"!canNext()\"\n            [attr.aria-label]=\"'pager.next' | uiTranslate\">\n      <mat-icon>chevron_right</mat-icon>\n    </button>\n    <button mat-icon-button type=\"button\"\n            (click)=\"goTo(totalPages())\" [disabled]=\"!canNext()\"\n            [attr.aria-label]=\"'pager.last' | uiTranslate\">\n      <mat-icon>last_page</mat-icon>\n    </button>\n  </div>\n\n  <div class=\"ui-shared-pager__meta\">\n    <ui-shared-select class=\"ui-shared-pager__size\"\n                      labelKey=\"pager.pageSize\"\n                      [control]=\"sizeControl\"\n                      [options]=\"sizeOptions()\" />\n\n    <span class=\"ui-shared-pager__summary\">\n      {{ from() }}\u2013{{ to() }}\n      <span class=\"ui-shared-pager__of\">{{ 'pager.of' | uiTranslate }}</span>\n      {{ total() }}\n    </span>\n  </div>\n</nav>\n", styles: [":host{display:block;box-sizing:border-box;min-width:0;max-width:100%}.ui-shared-pager{display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between}.ui-shared-pager__nav,.ui-shared-pager__meta{display:flex;flex-wrap:wrap;align-items:center}.ui-shared-pager__ellipsis{display:inline-flex;align-items:center;justify-content:center}.ui-shared-pager__summary{white-space:nowrap}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i1.MatButton, selector: "    button[mat-button], button[mat-raised-button], button[mat-flat-button],    button[mat-stroked-button]  ", exportAs: ["matButton"] }, { kind: "component", type: i1.MatIconButton, selector: "button[mat-icon-button]", exportAs: ["matButton"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "component", type: UiSharedSelectComponent, selector: "ui-shared-select", inputs: ["control", "labelKey", "options", "freeText", "nullable", "nullLabelKey", "hintKey", "hintText", "emptyHintKey", "disableWhenEmpty", "inputMode", "field", "clauseBuilder", "initial", "storageKey"] }, { kind: "pipe", type: UiTranslatePipe, name: "uiTranslate" }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedPagerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ui-shared-pager', standalone: true, imports: [
                        CommonModule,
                        MatButtonModule, MatIconModule, UiSharedSelectComponent,
                        UiTranslatePipe,
                    ], template: "<nav class=\"ui-shared-pager\" [attr.aria-label]=\"'pager.label' | uiTranslate\">\n  <div class=\"ui-shared-pager__nav\">\n    <button mat-icon-button type=\"button\"\n            (click)=\"goTo(1)\" [disabled]=\"!canPrev()\"\n            [attr.aria-label]=\"'pager.first' | uiTranslate\">\n      <mat-icon>first_page</mat-icon>\n    </button>\n    <button mat-icon-button type=\"button\"\n            (click)=\"goTo(page() - 1)\" [disabled]=\"!canPrev()\"\n            [attr.aria-label]=\"'pager.prev' | uiTranslate\">\n      <mat-icon>chevron_left</mat-icon>\n    </button>\n\n    @for (p of visiblePages(); track $index) {\n      @if (p === null) {\n        <span class=\"ui-shared-pager__ellipsis\">\u2026</span>\n      } @else {\n        <button mat-button type=\"button\"\n                class=\"ui-shared-pager__page\"\n                [class.ui-shared-pager__page--current]=\"p === page()\"\n                [attr.aria-current]=\"p === page() ? 'page' : null\"\n                (click)=\"goTo(p)\">\n          {{ p }}\n        </button>\n      }\n    }\n\n    <button mat-icon-button type=\"button\"\n            (click)=\"goTo(page() + 1)\" [disabled]=\"!canNext()\"\n            [attr.aria-label]=\"'pager.next' | uiTranslate\">\n      <mat-icon>chevron_right</mat-icon>\n    </button>\n    <button mat-icon-button type=\"button\"\n            (click)=\"goTo(totalPages())\" [disabled]=\"!canNext()\"\n            [attr.aria-label]=\"'pager.last' | uiTranslate\">\n      <mat-icon>last_page</mat-icon>\n    </button>\n  </div>\n\n  <div class=\"ui-shared-pager__meta\">\n    <ui-shared-select class=\"ui-shared-pager__size\"\n                      labelKey=\"pager.pageSize\"\n                      [control]=\"sizeControl\"\n                      [options]=\"sizeOptions()\" />\n\n    <span class=\"ui-shared-pager__summary\">\n      {{ from() }}\u2013{{ to() }}\n      <span class=\"ui-shared-pager__of\">{{ 'pager.of' | uiTranslate }}</span>\n      {{ total() }}\n    </span>\n  </div>\n</nav>\n", styles: [":host{display:block;box-sizing:border-box;min-width:0;max-width:100%}.ui-shared-pager{display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between}.ui-shared-pager__nav,.ui-shared-pager__meta{display:flex;flex-wrap:wrap;align-items:center}.ui-shared-pager__ellipsis{display:inline-flex;align-items:center;justify-content:center}.ui-shared-pager__summary{white-space:nowrap}\n"] }]
        }], ctorParameters: () => [] });

/**
 * Column descriptor projected as a child of <ui-shared-grid>. Carries:
 *   - <c>key</c>: short identifier (used by ngFor + as a debug aid).
 *   - <c>labelKey</c>: translation key for the table header cell.
 *   - <c>sortField</c>: OData PascalCase field name for <c>$orderby</c>.
 *                       Omit to make the column non-sortable.
 *   - <c>align</c>: optional cell alignment hint (default left).
 *   - A single projected <c>#cell</c> ng-template that receives the row
 *     via <c>let-row</c> and renders the cell body.
 *
 * Example:
 * <pre>
 *   &lt;ui-shared-grid-column key="email"
 *                          labelKey="users.email"
 *                          sortField="Email"&gt;
 *     &lt;ng-template #cell let-u&gt;{{ u.email }}&lt;/ng-template&gt;
 *   &lt;/ui-shared-grid-column&gt;
 * </pre>
 */
class UiSharedGridColumnComponent {
    key = input.required();
    labelKey = input.required();
    sortField = input(undefined);
    align = input('left');
    /** Body cell template. Required — receives the row via <c>$implicit</c>. */
    cell = contentChild.required('cell');
    /** Whether this column participates in sorting (has a sortField). */
    get sortable() { return !!this.sortField(); }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedGridColumnComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.2.0", version: "19.2.25", type: UiSharedGridColumnComponent, isStandalone: true, selector: "ui-shared-grid-column", inputs: { key: { classPropertyName: "key", publicName: "key", isSignal: true, isRequired: true, transformFunction: null }, labelKey: { classPropertyName: "labelKey", publicName: "labelKey", isSignal: true, isRequired: true, transformFunction: null }, sortField: { classPropertyName: "sortField", publicName: "sortField", isSignal: true, isRequired: false, transformFunction: null }, align: { classPropertyName: "align", publicName: "align", isSignal: true, isRequired: false, transformFunction: null } }, queries: [{ propertyName: "cell", first: true, predicate: ["cell"], descendants: true, isSignal: true }], ngImport: i0, template: "", styles: [":host{display:none;box-sizing:border-box;min-width:0;max-width:100%}\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedGridColumnComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ui-shared-grid-column', standalone: true, template: "", styles: [":host{display:none;box-sizing:border-box;min-width:0;max-width:100%}\n"] }]
        }] });

/**
 * Reusable table view. Columns are declared by projecting
 * <ui-shared-grid-column> children.
 *
 * USER STATE PERSISTED IN LOCALSTORAGE (when [storageKey] is set):
 *   - column WIDTH  per column key (px), set by dragging the right edge
 *     of each header.
 *   - column ORDER, set by dragging a header onto another.
 *   - the current VIEW: applied filter values, page and page size, so a reload
 *     (or coming back to the page) lands on what the user was looking at.
 * All three are restored on init so a logged-in user gets their layout and
 * their view back across sessions. State lives at:
 *     app.coreGrid.<storageKey>.widths   ->  { [key]: number }
 *     app.coreGrid.<storageKey>.order    ->  string[]   (column keys)
 *     app.coreGrid.<storageKey>.view     ->  { page, pageSize, filters: unknown[] }
 *     app.coreGrid.<storageKey>.settings ->  { hidden: string[], pagerTop: boolean }
 *   (hidden columns + "pager above the table", picked in the header gear menu).
 *
 * Sort: clicking a sortable header label cycles none -> asc -> desc -> none.
 * Sort or page-size changes reset to page 1.
 */
class UiSharedGridComponent {
    source = input.required();
    emptyKey = input('core.grid.empty');
    initialPageSize = input(20);
    pageSizeOptions = input([10, 20, 50, 100]);
    /** Default sort applied on first load. Matches an OData PascalCase field name. */
    initialSortField = input(undefined);
    /** Default sort direction. Defaults to 'asc' when initialSortField is set. */
    initialSortDir = input('asc');
    /**
     * Optional storage key — when set, the grid persists per-column widths and
     * order to localStorage so the user's layout is restored across sessions.
     * Pick something unique-per-grid like "admin-companies" / "tenant-contracted".
     */
    storageKey = input(undefined);
    /**
     * When true, the grid renders a leading checkbox column (header = select-all
     * on the current page, per-row = select that row) and a bulk-action bar above
     * the table. Project a <ng-template #bulkActions let-rows> to fill the bar;
     * `rows` is the array of currently-selected rows. Selection is per-page and
     * clears on every fetch (page / filter / sort change or refresh()).
     */
    selectable = input(false, { transform: booleanAttribute });
    /**
     * Rows a fetched page starts with ticked (only with `selectable`): every row the predicate
     * accepts is selected as soon as the page arrives. `[preselect]="r => r.status === 'Valid'"`.
     */
    preselect = input(null);
    /**
     * When set, the grid reloads its CURRENT page (filters/sort/paging untouched)
     * every time a SignalR `gridRefresh` signal with a matching key arrives — e.g.
     * "Invoices" so the documents grid updates when a background submit completes.
     */
    refreshKey = input(undefined);
    /** Min / max column width in px when the user drags the resize handle. */
    minColWidth = 60;
    maxColWidth = 800;
    columns = contentChildren(UiSharedGridColumnComponent);
    /** Projected inputs acting as filters (ui-shared-text-input / -select / -segmented). */
    filters = contentChildren(UI_GRID_FILTER);
    hasFilters = computed(() => this.filters().length > 0);
    /** Any filter currently applied — shows the Clear button. */
    hasActiveFilters = computed(() => this.filters().some(f => f.isApplied()));
    actionsTemplate = contentChild('actions', { read: TemplateRef });
    bulkActionsTemplate = contentChild('bulkActions', { read: TemplateRef });
    /**
     * Master-detail: project `<ng-template #detail let-row>` and every row gets a leading
     * expand arrow that opens the template under it (one row's detail at a time per click,
     * several may stay open). Expansion clears on every fetch.
     */
    detailTemplate = contentChild('detail', { read: TemplateRef });
    expanded = signal(new Set());
    isExpanded(row) { return this.expanded().has(row); }
    toggleExpanded(row) {
        this.expanded.update(s => { const n = new Set(s); n.has(row) ? n.delete(row) : n.add(row); return n; });
    }
    /** Columns a detail row spans: arrow + checkbox + visible + actions. */
    detailSpan = computed(() => 1 + (this.selectable() ? 1 : 0) + this.visibleColumns().length + 1);
    /** Rows are clickable (→ {@link rowClick}) only when the grid declares a per-row
     *  action menu (open/edit). Clicks on the checkbox or actions cell don't count. */
    interactive = computed(() => !!this.actionsTemplate());
    /** Emitted when an interactive row is clicked — wire it to open the detail
     *  page / side panel for that row. */
    rowClick = output();
    /** Enter on the focused ROW opens it; Enter inside a cell control (checkbox, ⋮ menu) must not. */
    onRowKeyEnter(ev, row) {
        if (this.interactive() && ev.target === ev.currentTarget)
            this.rowClick.emit(row);
    }
    rows = signal([]);
    total = signal(0);
    loading = signal(false);
    /** False until the first fetch resolves — the only time the spinner replaces the table. */
    loaded = signal(false);
    selected = signal([]);
    page = signal(1);
    pageSize = signal(20);
    sortField = signal(null);
    sortDir = signal(null);
    widths = signal({});
    order = signal(null);
    /** Column keys the user hid from the settings menu. */
    hidden = signal([]);
    /** Pager rendered above the table (as well as below) so paging needs no scroll. */
    pagerTop = signal(false);
    /** Rendered columns: the user's order minus the hidden ones (the last visible column can't be hidden). */
    visibleColumns = computed(() => {
        const hidden = new Set(this.hidden());
        const shown = this.orderedColumns().filter(c => !hidden.has(c.key()));
        return shown.length ? shown : this.orderedColumns().slice(0, 1);
    });
    isHidden(col) { return this.hidden().includes(col.key()); }
    toggleColumn(col, visible) {
        const key = col.key();
        this.hidden.update(h => visible ? h.filter(k => k !== key) : (h.includes(key) ? h : [...h, key]));
        this.persistSettings();
    }
    setPagerTop(on) {
        this.pagerTop.set(on);
        this.persistSettings();
    }
    /** Columns in the (possibly user-reordered) order to render. */
    orderedColumns = computed(() => {
        const cols = this.columns();
        const ord = this.order();
        if (!ord || ord.length === 0)
            return [...cols];
        const byKey = new Map(cols.map(c => [c.key(), c]));
        const fromStored = ord.map(k => byKey.get(k)).filter((c) => !!c);
        // Append any column that exists today but wasn't in the stored order
        // (newly-added columns appear at the end so persisted order doesn't hide them).
        const seen = new Set(fromStored.map(c => c.key()));
        const tail = cols.filter(c => !seen.has(c.key()));
        return [...fromStored, ...tail];
    });
    zone = inject(NgZone);
    stopResize = null;
    refreshSignals = inject(UI_REFRESH);
    /** Every fetch goes through here so a newer request cancels the in-flight one
     *  (switchMap) — a slow earlier page can never overwrite a later one. */
    queries$ = new Subject();
    constructor() {
        this.queries$.pipe(switchMap(q => this.source().get(q).pipe(catchError(() => of(null)))), takeUntilDestroyed()).subscribe(res => {
            if (res) {
                // The page emptied under us (rows deleted on the last page): jump to the new last page.
                const lastPage = Math.max(1, Math.ceil(res.total / this.pageSize()));
                if (!res.items.length && this.page() > lastPage) {
                    this.page.set(lastPage);
                    this.fetch();
                    return;
                }
                this.rows.set(res.items);
                this.expanded.set(new Set());
                const pre = this.preselect();
                if (pre && this.selectable())
                    this.selected.set(res.items.filter(pre));
                this.total.set(res.total);
            }
            this.loading.set(false);
            this.loaded.set(true);
        });
        // Re-fetch whenever the [source] input ref changes. Pages that need to
        // force a reload after a mutation (e.g. tenant contracted-companies bumps
        // a refreshTick signal so its `source` computed returns a fresh
        // OdataSource instance) rely on this. The first effect run is consumed
        // during initial wiring — ngAfterContentInit owns the very first fetch.
        // Only source() may be tracked: page/sort/filter reads inside fetch() must
        // not become dependencies, or every paging change would reset to page 1.
        let initialSourceConsumed = false;
        effect(() => {
            this.source();
            untracked(() => {
                if (!initialSourceConsumed) {
                    initialSourceConsumed = true;
                    return;
                }
                this.fetchFirstPage();
            });
        });
        // Reload (data only — filters/sort/paging kept) when a matching gridRefresh
        // SignalR signal arrives (e.g. after a background invoice submit completes).
        this.refreshSignals.pipe(takeUntilDestroyed()).subscribe(s => {
            if (s.grid === this.refreshKey())
                this.refresh();
        });
        inject(DestroyRef).onDestroy(() => this.stopResize?.());
    }
    ngOnInit() {
        this.pageSize.set(this.initialPageSize());
        if (this.initialSortField()) {
            this.sortField.set(this.initialSortField());
            this.sortDir.set(this.initialSortDir());
        }
    }
    ngAfterContentInit() {
        // Restore persisted layout (after columns are available) and the view
        // (after the projected filters are available).
        this.restoreLayout();
        this.restoreView();
        this.fetch();
    }
    refresh() { this.fetch(); }
    // ---- Row selection (per-page; cleared on every fetch) -------------------
    anySelected = computed(() => this.selected().length > 0);
    allOnPageSelected = computed(() => {
        const rows = this.rows();
        const sel = this.selected();
        return rows.length > 0 && rows.every(r => sel.includes(r));
    });
    isSelected(row) { return this.selected().includes(row); }
    toggleRow(row, checked) {
        this.selected.update(s => checked ? [...s, row] : s.filter(r => r !== row));
    }
    toggleAll(checked) {
        this.selected.set(checked ? [...this.rows()] : []);
    }
    /** Public so consumers can drop the selection after a bulk action. */
    clearSelection() { this.selected.set([]); }
    reset() { this.fetchFirstPage(); }
    onPage(p) {
        this.page.set(p);
        this.fetch();
    }
    onPageSize(size) {
        this.pageSize.set(size);
        this.fetchFirstPage();
    }
    onHeaderClick(col) {
        const field = col.sortField();
        if (!field)
            return;
        if (this.sortField() !== field) {
            this.sortField.set(field);
            this.sortDir.set('asc');
        }
        else if (this.sortDir() === 'asc') {
            this.sortDir.set('desc');
        }
        else if (this.sortDir() === 'desc') {
            this.sortField.set(null);
            this.sortDir.set(null);
        }
        else {
            this.sortDir.set('asc');
        }
        this.fetchFirstPage();
    }
    sortIconFor(col) {
        if (!col.sortable)
            return '';
        if (this.sortField() !== col.sortField())
            return 'unfold_more';
        return this.sortDir() === 'desc' ? 'arrow_downward' : 'arrow_upward';
    }
    ariaSortFor(col) {
        if (!col.sortable)
            return null;
        if (this.sortField() !== col.sortField())
            return 'none';
        return this.sortDir() === 'desc' ? 'descending' : 'ascending';
    }
    onSearch() {
        for (const f of this.filters())
            f.applyPending();
        this.fetchFirstPage();
    }
    onClearFilters() {
        for (const f of this.filters())
            f.clearAll();
        this.fetchFirstPage();
    }
    widthFor(col) {
        const w = this.widths()[col.key()];
        return w ? `${w}px` : null;
    }
    /** Pointer down on a column's resize handle. */
    startResize(ev, col, thEl) {
        ev.preventDefault();
        ev.stopPropagation();
        const startX = ev.clientX;
        const startW = thEl.getBoundingClientRect().width;
        const key = col.key();
        this.stopResize = trackPointerDrag(this.zone, e => this.setWidth(key, this.clampWidth(startW + (e.clientX - startX))), () => { this.stopResize = null; this.persistLayout(); });
    }
    setWidth(key, w) {
        this.widths.update(prev => ({ ...prev, [key]: w }));
    }
    clampWidth(w) {
        return Math.max(this.minColWidth, Math.min(this.maxColWidth, Math.round(w)));
    }
    onDragStart(ev, col) {
        if (!ev.dataTransfer)
            return;
        ev.dataTransfer.effectAllowed = 'move';
        ev.dataTransfer.setData('text/plain', col.key());
    }
    onDragOver(ev) {
        ev.preventDefault();
        if (ev.dataTransfer)
            ev.dataTransfer.dropEffect = 'move';
    }
    onDrop(ev, target) {
        ev.preventDefault();
        const fromKey = ev.dataTransfer?.getData('text/plain');
        const toKey = target.key();
        if (!fromKey || fromKey === toKey)
            return;
        // Build the current order list, move fromKey to where toKey is.
        const current = this.orderedColumns().map(c => c.key());
        const fi = current.indexOf(fromKey);
        const ti = current.indexOf(toKey);
        if (fi < 0 || ti < 0)
            return;
        const next = [...current];
        next.splice(fi, 1);
        next.splice(ti, 0, fromKey);
        this.order.set(next);
        this.persistLayout();
    }
    settingsKey(k) { return `app.coreGrid.${k}.settings`; }
    widthsKey(k) { return `app.coreGrid.${k}.widths`; }
    orderKey(k) { return `app.coreGrid.${k}.order`; }
    viewKey(k) { return `app.coreGrid.${k}.view`; }
    /** The view the user is looking at — written on every fetch, with the clause that fetch used. */
    persistView(clause) {
        const k = this.storageKey();
        if (!k)
            return;
        uiStorage.setJson(this.viewKey(k), {
            page: this.page(),
            pageSize: this.pageSize(),
            filters: this.filters().map(f => f.value()),
            // The CLAUSE as well as the values: a filter whose options load async (a
            // select over an OData lookup) answers `null` until they arrive, so
            // replaying values alone would send the first request unfiltered and need
            // a second one to correct it — see `restoredClause`.
            clause: clause ?? null,
        });
    }
    /**
     * Puts the remembered filters + paging back before the first fetch. Filters
     * are matched BY POSITION, so a template that has since gained or lost one is
     * treated as a different view and its values are dropped rather than landing
     * on the wrong input. A page past the end self-heals: the fetch falls back to
     * the last page.
     */
    restoreView() {
        const k = this.storageKey();
        if (!k)
            return;
        const view = uiStorage.getJson(this.viewKey(k));
        if (!view || typeof view !== 'object')
            return;
        const filters = this.filters();
        if (Array.isArray(view.filters) && view.filters.length === filters.length) {
            filters.forEach((f, i) => {
                const value = view.filters[i];
                if (value !== null && value !== undefined && value !== '')
                    f.restore(value);
            });
        }
        if (typeof view.pageSize === 'number' && this.pageSizeOptions().includes(view.pageSize)) {
            this.pageSize.set(view.pageSize);
        }
        if (typeof view.page === 'number' && Number.isInteger(view.page) && view.page >= 1) {
            this.page.set(view.page);
        }
        if (typeof view.clause === 'string' && view.clause)
            this.restoredClause = view.clause;
    }
    /**
     * The remembered OData clause, used for the FIRST fetch only. A restored
     * filter cannot always build its own clause yet — a select compares the value
     * against its options, which may still be loading — so without this the grid
     * would load unfiltered and then correct itself with a second request. Cleared
     * once used; every later fetch reads the live filters.
     */
    restoredClause = null;
    persistSettings() {
        const k = this.storageKey();
        if (!k)
            return;
        uiStorage.setJson(this.settingsKey(k), { hidden: this.hidden(), pagerTop: this.pagerTop() });
    }
    restoreLayout() {
        const k = this.storageKey();
        if (!k)
            return;
        const settings = uiStorage.getJson(this.settingsKey(k));
        if (settings && typeof settings === 'object') {
            if (Array.isArray(settings.hidden) && settings.hidden.every(x => typeof x === 'string'))
                this.hidden.set(settings.hidden);
            if (typeof settings.pagerTop === 'boolean')
                this.pagerTop.set(settings.pagerTop);
        }
        const widths = uiStorage.getJson(this.widthsKey(k));
        if (widths && typeof widths === 'object') {
            const clean = {};
            for (const [key, val] of Object.entries(widths)) {
                const n = Number(val);
                if (Number.isFinite(n))
                    clean[key] = this.clampWidth(n);
            }
            this.widths.set(clean);
        }
        const order = uiStorage.getJson(this.orderKey(k));
        if (Array.isArray(order) && order.every(x => typeof x === 'string'))
            this.order.set(order);
    }
    persistLayout() {
        const k = this.storageKey();
        if (!k)
            return;
        uiStorage.setJson(this.widthsKey(k), this.widths());
        const ord = this.order();
        if (ord?.length)
            uiStorage.setJson(this.orderKey(k), ord);
    }
    /**
     * Settings menu -> "Reset to default". Wipes any user-driven column
     * customisation (widths from drag-resize + order from drag-reorder) AND the
     * persisted localStorage entries, so the grid renders with its declared
     * columns at their default widths.
     */
    resetLayout() {
        this.widths.set({});
        this.order.set(null);
        this.hidden.set([]);
        this.pagerTop.set(false);
        const k = this.storageKey();
        if (k) {
            uiStorage.remove(this.widthsKey(k));
            uiStorage.remove(this.orderKey(k));
            uiStorage.remove(this.viewKey(k));
            uiStorage.remove(this.settingsKey(k));
        }
    }
    /** True when the user has any persisted/in-memory layout customisation. */
    hasLayoutChanges = computed(() => {
        const w = this.widths();
        const o = this.order();
        return Object.keys(w).length > 0 || (o !== null && o.length > 0) || this.hidden().length > 0 || this.pagerTop();
    });
    fetchFirstPage() {
        this.page.set(1);
        this.fetch();
    }
    fetch() {
        // The remembered clause wins for the FIRST fetch after a restore, then the
        // live filters take over — one request, already filtered.
        const filter = this.restoredClause ?? andClauses(this.filters().map(f => f.clause()));
        this.restoredClause = null;
        this.persistView(filter);
        this.loading.set(true);
        this.selected.set([]);
        this.queries$.next({
            page: this.page(),
            pageSize: this.pageSize(),
            sortField: this.sortField() ?? undefined,
            sortDir: this.sortDir() ?? undefined,
            filter,
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedGridComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: UiSharedGridComponent, isStandalone: true, selector: "ui-shared-grid", inputs: { source: { classPropertyName: "source", publicName: "source", isSignal: true, isRequired: true, transformFunction: null }, emptyKey: { classPropertyName: "emptyKey", publicName: "emptyKey", isSignal: true, isRequired: false, transformFunction: null }, initialPageSize: { classPropertyName: "initialPageSize", publicName: "initialPageSize", isSignal: true, isRequired: false, transformFunction: null }, pageSizeOptions: { classPropertyName: "pageSizeOptions", publicName: "pageSizeOptions", isSignal: true, isRequired: false, transformFunction: null }, initialSortField: { classPropertyName: "initialSortField", publicName: "initialSortField", isSignal: true, isRequired: false, transformFunction: null }, initialSortDir: { classPropertyName: "initialSortDir", publicName: "initialSortDir", isSignal: true, isRequired: false, transformFunction: null }, storageKey: { classPropertyName: "storageKey", publicName: "storageKey", isSignal: true, isRequired: false, transformFunction: null }, selectable: { classPropertyName: "selectable", publicName: "selectable", isSignal: true, isRequired: false, transformFunction: null }, preselect: { classPropertyName: "preselect", publicName: "preselect", isSignal: true, isRequired: false, transformFunction: null }, refreshKey: { classPropertyName: "refreshKey", publicName: "refreshKey", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { rowClick: "rowClick" }, queries: [{ propertyName: "columns", predicate: UiSharedGridColumnComponent, isSignal: true }, { propertyName: "filters", predicate: UI_GRID_FILTER, isSignal: true }, { propertyName: "actionsTemplate", first: true, predicate: ["actions"], descendants: true, read: TemplateRef, isSignal: true }, { propertyName: "bulkActionsTemplate", first: true, predicate: ["bulkActions"], descendants: true, read: TemplateRef, isSignal: true }, { propertyName: "detailTemplate", first: true, predicate: ["detail"], descendants: true, read: TemplateRef, isSignal: true }], ngImport: i0, template: "@if (hasFilters()) {\n  <div class=\"ui-shared-grid__filters\">\n    <!-- Enter in any filter runs Search (a dropdown pick lands before keyup). -->\n    <div class=\"ui-shared-grid__filter-inputs\" (keyup.enter)=\"onSearch()\">\n      <ng-content select=\"ui-shared-text-input, ui-shared-select, ui-shared-segmented\"></ng-content>\n    </div>\n    <div class=\"ui-shared-grid__filter-actions\">\n      @if (hasActiveFilters()) {\n        <button mat-button type=\"button\" (click)=\"onClearFilters()\">\n          {{ 'core.grid.filter.clear' | uiTranslate }}\n        </button>\n      }\n      <button mat-stroked-button type=\"button\" (click)=\"onSearch()\">\n        <mat-icon>search</mat-icon>\n        <span>{{ 'core.grid.filter.search' | uiTranslate }}</span>\n      </button>\n    </div>\n  </div>\n}\n\n@if (pagerTop() && total() > 0) {\n  <ui-shared-pager class=\"ui-shared-grid__pager--top\"\n    [page]=\"page()\"\n    [pageSize]=\"pageSize()\"\n    [total]=\"total()\"\n    [pageSizeOptions]=\"pageSizeOptions()\"\n    (pageChange)=\"onPage($event)\"\n    (pageSizeChange)=\"onPageSize($event)\">\n  </ui-shared-pager>\n}\n\n@if (selectable() && anySelected()) {\n  <div class=\"ui-shared-grid__bulk-bar\">\n    <span class=\"ui-shared-grid__bulk-count\">\n      {{ selected().length }} {{ 'core.grid.selected' | uiTranslate }}\n    </span>\n    <div class=\"ui-shared-grid__bulk-actions\">\n      @if (bulkActionsTemplate(); as bulk) {\n        <ng-container [ngTemplateOutlet]=\"bulk\"\n                      [ngTemplateOutletContext]=\"{ $implicit: selected() }\">\n        </ng-container>\n      }\n      <button mat-button type=\"button\" (click)=\"clearSelection()\">\n        {{ 'core.grid.clearSelection' | uiTranslate }}\n      </button>\n    </div>\n  </div>\n}\n\n@if (!loaded()) {\n  <div class=\"ui-shared-grid__state ui-shared-grid__state--loading\">\n    <mat-progress-spinner mode=\"indeterminate\" diameter=\"28\" />\n    <span>{{ 'core.grid.loading' | uiTranslate }}</span>\n  </div>\n} @else if (rows().length === 0 && !loading()) {\n  <div class=\"ui-shared-grid__state\">\n    <mat-icon>inbox</mat-icon>\n    <p class=\"ui-shared-grid__state-title\">{{ emptyKey() | uiTranslate }}</p>\n    <div class=\"ui-shared-grid__state-actions\">\n      <ng-content select=\"[slot=empty-actions]\"></ng-content>\n    </div>\n  </div>\n} @else {\n  <div class=\"ui-shared-grid__wrap\" [class.ui-shared-grid__wrap--loading]=\"loading()\" [attr.aria-busy]=\"loading()\">\n    <table class=\"ui-shared-grid\">\n      <thead>\n        <tr>\n          @if (detailTemplate()) {\n            <th class=\"ui-shared-grid__th ui-shared-grid__th--expand\"></th>\n          }\n          @if (selectable()) {\n            <th class=\"ui-shared-grid__th ui-shared-grid__th--check\">\n              <mat-checkbox\n                  [checked]=\"allOnPageSelected()\"\n                  [indeterminate]=\"anySelected() && !allOnPageSelected()\"\n                  (change)=\"toggleAll($event.checked)\">\n              </mat-checkbox>\n            </th>\n          }\n          @for (col of visibleColumns(); track col.key()) {\n            <th #thEl class=\"ui-shared-grid__th\"\n                [class.ui-shared-grid__th--sortable]=\"col.sortable\"\n                [class.ui-shared-grid__th--sorted]=\"sortField() === col.sortField()\"\n                [class.ui-shared-grid__th--right]=\"col.align() === 'right'\"\n                [class.ui-shared-grid__th--center]=\"col.align() === 'center'\"\n                [attr.data-col-key]=\"col.key()\"\n                [style.width]=\"widthFor(col)\"\n                draggable=\"true\"\n                [attr.tabindex]=\"col.sortable ? 0 : null\"\n                [attr.role]=\"col.sortable ? 'button' : null\"\n                [attr.aria-sort]=\"ariaSortFor(col)\"\n                (dragstart)=\"onDragStart($event, col)\"\n                (dragover)=\"onDragOver($event)\"\n                (drop)=\"onDrop($event, col)\"\n                (click)=\"col.sortable && onHeaderClick(col)\"\n                (keydown.enter)=\"col.sortable && onHeaderClick(col)\"\n                (keydown.space)=\"col.sortable && onHeaderClick(col); $event.preventDefault()\">\n              <span class=\"ui-shared-grid__th-label\">{{ col.labelKey() | uiTranslate }}</span>\n              @if (col.sortable) {\n                <mat-icon class=\"ui-shared-grid__th-sort\">{{ sortIconFor(col) }}</mat-icon>\n              }\n              <!-- Resize handle: own pointer events, don't propagate to the\n                   sort-click handler on the header. -->\n              <span class=\"ui-shared-grid__th-resizer\"\n                    (pointerdown)=\"startResize($event, col, thEl)\"\n                    (click)=\"$event.stopPropagation()\"\n                    (dragstart)=\"$event.preventDefault(); $event.stopPropagation()\"\n                    aria-hidden=\"true\"></span>\n            </th>\n          }\n          <!-- Always-present rightmost utility column: hosts the grid settings\n               gear in the header, and the per-row actions menu in the body\n               (if an [#actions] template was projected). 48px wide. -->\n          <th class=\"ui-shared-grid__th ui-shared-grid__th--actions\">\n            <button mat-icon-button\n                    type=\"button\"\n                    class=\"ui-shared-grid__icon-btn ui-shared-grid__settings-trigger\"\n                    [matMenuTriggerFor]=\"gridSettingsMenu\"\n                    [matTooltip]=\"'core.grid.settings' | uiTranslate\"\n                    [attr.aria-label]=\"'core.grid.settings' | uiTranslate\"\n                    aria-haspopup=\"menu\">\n              <mat-icon>settings</mat-icon>\n            </button>\n            <mat-menu #gridSettingsMenu=\"matMenu\" xPosition=\"before\" class=\"ui-shared-grid__settings-menu\">\n              <!-- Clicks inside the menu must not close it: the user toggles several columns in a row. -->\n              <div class=\"ui-shared-grid__settings\" (click)=\"$event.stopPropagation()\" (keydown.tab)=\"$event.stopPropagation()\">\n                <mat-slide-toggle class=\"ui-shared-grid__settings-toggle\"\n                    [checked]=\"pagerTop()\"\n                    (change)=\"setPagerTop($event.checked)\">\n                  {{ 'core.grid.pagerTop' | uiTranslate }}\n                </mat-slide-toggle>\n                <mat-divider />\n                <div class=\"ui-shared-grid__settings-title\">{{ 'core.grid.columns' | uiTranslate }}</div>\n                @for (col of orderedColumns(); track col.key()) {\n                  <mat-checkbox class=\"ui-shared-grid__settings-column\"\n                      [checked]=\"!isHidden(col)\"\n                      [disabled]=\"!isHidden(col) && visibleColumns().length === 1\"\n                      (change)=\"toggleColumn(col, $event.checked)\">\n                    {{ col.labelKey() | uiTranslate }}\n                  </mat-checkbox>\n                }\n                <mat-divider />\n              </div>\n              <button mat-menu-item type=\"button\"\n                      [disabled]=\"!hasLayoutChanges()\"\n                      (click)=\"resetLayout()\">\n                <mat-icon>restart_alt</mat-icon>\n                <span>{{ 'core.grid.resetLayout' | uiTranslate }}</span>\n              </button>\n            </mat-menu>\n          </th>\n        </tr>\n      </thead>\n      <tbody>\n        @for (row of rows(); track $index) {\n          <tr class=\"ui-shared-grid__row\"\n              [class.ui-shared-grid__row--selected]=\"isSelected(row)\"\n              [class.ui-shared-grid__row--clickable]=\"interactive()\"\n              [attr.tabindex]=\"interactive() ? 0 : null\"\n              (click)=\"interactive() && rowClick.emit(row)\"\n              (keydown.enter)=\"onRowKeyEnter($event, row)\">\n            @if (detailTemplate()) {\n              <td class=\"ui-shared-grid__td ui-shared-grid__td--expand\" (click)=\"$event.stopPropagation()\">\n                <button mat-icon-button type=\"button\" class=\"ui-shared-grid__icon-btn ui-shared-grid__expand\"\n                        [class.ui-shared-grid__expand--open]=\"isExpanded(row)\"\n                        [attr.aria-expanded]=\"isExpanded(row)\"\n                        [attr.aria-label]=\"'core.grid.detail' | uiTranslate\"\n                        (click)=\"toggleExpanded(row)\">\n                  <mat-icon>chevron_right</mat-icon>\n                </button>\n              </td>\n            }\n            @if (selectable()) {\n              <td class=\"ui-shared-grid__td ui-shared-grid__td--check\" (click)=\"$event.stopPropagation()\">\n                <mat-checkbox\n                    [checked]=\"isSelected(row)\"\n                    (change)=\"toggleRow(row, $event.checked)\">\n                </mat-checkbox>\n              </td>\n            }\n            @for (col of visibleColumns(); track col.key()) {\n              <td class=\"ui-shared-grid__td\"\n                  [class.ui-shared-grid__td--right]=\"col.align() === 'right'\"\n                  [class.ui-shared-grid__td--center]=\"col.align() === 'center'\"\n                  [style.width]=\"widthFor(col)\">\n                <ng-container [ngTemplateOutlet]=\"col.cell()\"\n                              [ngTemplateOutletContext]=\"{ $implicit: row }\">\n                </ng-container>\n              </td>\n            }\n            <td class=\"ui-shared-grid__td ui-shared-grid__td--actions\" (click)=\"$event.stopPropagation()\">\n              @if (actionsTemplate(); as actions) {\n                <!-- The template decides per row what it shows; no items = no trigger. -->\n                <div hidden uiEmpty #probe=\"uiEmpty\">\n                  <ng-container [ngTemplateOutlet]=\"actions\" [ngTemplateOutletContext]=\"{ $implicit: row }\"></ng-container>\n                </div>\n                @if (!probe.empty()) {\n                <button mat-icon-button\n                        [matMenuTriggerFor]=\"rowMenu\"\n                        [matTooltip]=\"'core.grid.rowActions' | uiTranslate\"\n                        [attr.aria-label]=\"'core.grid.rowActions' | uiTranslate\"\n                        aria-haspopup=\"menu\"\n                        type=\"button\"\n                        class=\"ui-shared-grid__icon-btn ui-shared-grid__row-menu-trigger\">\n                  <mat-icon>more_vert</mat-icon>\n                </button>\n                <mat-menu #rowMenu=\"matMenu\" xPosition=\"before\">\n                  <ng-container [ngTemplateOutlet]=\"actions\"\n                                [ngTemplateOutletContext]=\"{ $implicit: row }\">\n                  </ng-container>\n                </mat-menu>\n                }\n              }\n            </td>\n          </tr>\n          @if (detailTemplate(); as detail) {\n            @if (isExpanded(row)) {\n              <tr class=\"ui-shared-grid__detail\">\n                <td class=\"ui-shared-grid__detail-cell\" [attr.colspan]=\"detailSpan()\">\n                  <ng-container [ngTemplateOutlet]=\"detail\" [ngTemplateOutletContext]=\"{ $implicit: row }\"></ng-container>\n                </td>\n              </tr>\n            }\n          }\n        }\n      </tbody>\n    </table>\n  </div>\n}\n\n@if (total() > 0) {\n  <!-- Pager stays mounted across loads so the page-change click is never\n       lost to an unmount/remount cycle. Buttons disable themselves via\n       canPrev / canNext; loading state is shown above. -->\n  <ui-shared-pager\n    [page]=\"page()\"\n    [pageSize]=\"pageSize()\"\n    [total]=\"total()\"\n    [pageSizeOptions]=\"pageSizeOptions()\"\n    (pageChange)=\"onPage($event)\"\n    (pageSizeChange)=\"onPageSize($event)\">\n  </ui-shared-pager>\n}\n", styles: [":host{display:block;box-sizing:border-box;min-width:0;max-width:100%}.ui-shared-grid__wrap{position:relative;overflow-x:clip}.ui-shared-grid__wrap--loading{pointer-events:none}.ui-shared-grid{width:100%;border-collapse:collapse;table-layout:fixed}.ui-shared-grid__th{position:relative;z-index:2;white-space:nowrap;-webkit-user-select:none;user-select:none;cursor:grab}.ui-shared-grid__th:active{cursor:grabbing}.ui-shared-grid__th--sortable{cursor:pointer}.ui-shared-grid__th-label{display:inline-block;max-width:100%;vertical-align:middle;overflow:hidden;text-overflow:ellipsis}.ui-shared-grid__th-sort{vertical-align:middle}.ui-shared-grid__th-resizer{position:absolute;top:0;right:0;z-index:1;width:6px;height:100%;cursor:col-resize}.ui-shared-grid__td{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;vertical-align:middle}.ui-shared-grid__th--right,.ui-shared-grid__td--right{text-align:right}.ui-shared-grid__th--center,.ui-shared-grid__td--center{text-align:center}.ui-shared-grid__th--actions,.ui-shared-grid__td--actions{width:48px}.ui-shared-grid__th--check,.ui-shared-grid__td--check,.ui-shared-grid__th--expand,.ui-shared-grid__td--expand{width:44px}.ui-shared-grid__th--expand,.ui-shared-grid__td--expand{cursor:default;overflow:visible}.ui-shared-grid__expand .mat-icon{transition:transform var(--ui-motion-fast)}.ui-shared-grid__expand--open .mat-icon{transform:rotate(90deg)}.ui-shared-grid__th--actions,.ui-shared-grid__th--check,.ui-shared-grid__td--check{cursor:default}.ui-shared-grid__td--actions,.ui-shared-grid__th--check,.ui-shared-grid__td--check{overflow:visible}.ui-shared-grid__row--clickable{cursor:pointer}.ui-shared-grid__icon-btn{display:inline-grid;place-items:center}.ui-shared-grid__filters,.ui-shared-grid__bulk-bar{display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between}.ui-shared-grid__filter-inputs{display:flex;flex-wrap:wrap;align-items:center;flex:1;min-width:0}.ui-shared-grid__filter-actions,.ui-shared-grid__bulk-actions{display:flex;align-items:center;margin-left:auto}.ui-shared-grid__state{display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center}.ui-shared-grid__state--loading{flex-direction:row}.ui-shared-grid__state-actions{display:flex}.ui-shared-grid__state-actions:empty{display:none}.ui-shared-grid__settings{display:flex;flex-direction:column}.ui-shared-grid__pager--top{display:block}\n"], dependencies: [{ kind: "directive", type: UiEmptyDirective, selector: "[uiEmpty]", exportAs: ["uiEmpty"] }, { kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1$1.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i1.MatButton, selector: "    button[mat-button], button[mat-raised-button], button[mat-flat-button],    button[mat-stroked-button]  ", exportAs: ["matButton"] }, { kind: "component", type: i1.MatIconButton, selector: "button[mat-icon-button]", exportAs: ["matButton"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatMenuModule }, { kind: "component", type: i4.MatMenu, selector: "mat-menu", inputs: ["backdropClass", "aria-label", "aria-labelledby", "aria-describedby", "xPosition", "yPosition", "overlapTrigger", "hasBackdrop", "class", "classList"], outputs: ["closed", "close"], exportAs: ["matMenu"] }, { kind: "component", type: i4.MatMenuItem, selector: "[mat-menu-item]", inputs: ["role", "disabled", "disableRipple"], exportAs: ["matMenuItem"] }, { kind: "directive", type: i4.MatMenuTrigger, selector: "[mat-menu-trigger-for], [matMenuTriggerFor]", inputs: ["mat-menu-trigger-for", "matMenuTriggerFor", "matMenuTriggerData", "matMenuTriggerRestoreFocus"], outputs: ["menuOpened", "onMenuOpen", "menuClosed", "onMenuClose"], exportAs: ["matMenuTrigger"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "directive", type: i5.MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }, { kind: "ngmodule", type: MatCheckboxModule }, { kind: "component", type: i6.MatCheckbox, selector: "mat-checkbox", inputs: ["aria-label", "aria-labelledby", "aria-describedby", "aria-expanded", "aria-controls", "aria-owns", "id", "required", "labelPosition", "name", "value", "disableRipple", "tabIndex", "color", "disabledInteractive", "checked", "disabled", "indeterminate"], outputs: ["change", "indeterminateChange"], exportAs: ["matCheckbox"] }, { kind: "ngmodule", type: MatSlideToggleModule }, { kind: "component", type: i7.MatSlideToggle, selector: "mat-slide-toggle", inputs: ["name", "id", "labelPosition", "aria-label", "aria-labelledby", "aria-describedby", "required", "color", "disabled", "disableRipple", "tabIndex", "checked", "hideIcon", "disabledInteractive"], outputs: ["change", "toggleChange"], exportAs: ["matSlideToggle"] }, { kind: "ngmodule", type: MatDividerModule }, { kind: "component", type: i8.MatDivider, selector: "mat-divider", inputs: ["vertical", "inset"] }, { kind: "ngmodule", type: MatProgressSpinnerModule }, { kind: "component", type: i9.MatProgressSpinner, selector: "mat-progress-spinner, mat-spinner", inputs: ["color", "mode", "value", "diameter", "strokeWidth"], exportAs: ["matProgressSpinner"] }, { kind: "pipe", type: UiTranslatePipe, name: "uiTranslate" }, { kind: "component", type: UiSharedPagerComponent, selector: "ui-shared-pager", inputs: ["page", "pageSize", "total", "pageSizeOptions"], outputs: ["pageChange", "pageSizeChange"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedGridComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ui-shared-grid', standalone: true, imports: [
                        UiEmptyDirective,
                        CommonModule,
                        MatButtonModule, MatIconModule, MatMenuModule, MatTooltipModule, MatCheckboxModule,
                        MatSlideToggleModule, MatDividerModule, MatProgressSpinnerModule, UiTranslatePipe, UiSharedPagerComponent,
                    ], template: "@if (hasFilters()) {\n  <div class=\"ui-shared-grid__filters\">\n    <!-- Enter in any filter runs Search (a dropdown pick lands before keyup). -->\n    <div class=\"ui-shared-grid__filter-inputs\" (keyup.enter)=\"onSearch()\">\n      <ng-content select=\"ui-shared-text-input, ui-shared-select, ui-shared-segmented\"></ng-content>\n    </div>\n    <div class=\"ui-shared-grid__filter-actions\">\n      @if (hasActiveFilters()) {\n        <button mat-button type=\"button\" (click)=\"onClearFilters()\">\n          {{ 'core.grid.filter.clear' | uiTranslate }}\n        </button>\n      }\n      <button mat-stroked-button type=\"button\" (click)=\"onSearch()\">\n        <mat-icon>search</mat-icon>\n        <span>{{ 'core.grid.filter.search' | uiTranslate }}</span>\n      </button>\n    </div>\n  </div>\n}\n\n@if (pagerTop() && total() > 0) {\n  <ui-shared-pager class=\"ui-shared-grid__pager--top\"\n    [page]=\"page()\"\n    [pageSize]=\"pageSize()\"\n    [total]=\"total()\"\n    [pageSizeOptions]=\"pageSizeOptions()\"\n    (pageChange)=\"onPage($event)\"\n    (pageSizeChange)=\"onPageSize($event)\">\n  </ui-shared-pager>\n}\n\n@if (selectable() && anySelected()) {\n  <div class=\"ui-shared-grid__bulk-bar\">\n    <span class=\"ui-shared-grid__bulk-count\">\n      {{ selected().length }} {{ 'core.grid.selected' | uiTranslate }}\n    </span>\n    <div class=\"ui-shared-grid__bulk-actions\">\n      @if (bulkActionsTemplate(); as bulk) {\n        <ng-container [ngTemplateOutlet]=\"bulk\"\n                      [ngTemplateOutletContext]=\"{ $implicit: selected() }\">\n        </ng-container>\n      }\n      <button mat-button type=\"button\" (click)=\"clearSelection()\">\n        {{ 'core.grid.clearSelection' | uiTranslate }}\n      </button>\n    </div>\n  </div>\n}\n\n@if (!loaded()) {\n  <div class=\"ui-shared-grid__state ui-shared-grid__state--loading\">\n    <mat-progress-spinner mode=\"indeterminate\" diameter=\"28\" />\n    <span>{{ 'core.grid.loading' | uiTranslate }}</span>\n  </div>\n} @else if (rows().length === 0 && !loading()) {\n  <div class=\"ui-shared-grid__state\">\n    <mat-icon>inbox</mat-icon>\n    <p class=\"ui-shared-grid__state-title\">{{ emptyKey() | uiTranslate }}</p>\n    <div class=\"ui-shared-grid__state-actions\">\n      <ng-content select=\"[slot=empty-actions]\"></ng-content>\n    </div>\n  </div>\n} @else {\n  <div class=\"ui-shared-grid__wrap\" [class.ui-shared-grid__wrap--loading]=\"loading()\" [attr.aria-busy]=\"loading()\">\n    <table class=\"ui-shared-grid\">\n      <thead>\n        <tr>\n          @if (detailTemplate()) {\n            <th class=\"ui-shared-grid__th ui-shared-grid__th--expand\"></th>\n          }\n          @if (selectable()) {\n            <th class=\"ui-shared-grid__th ui-shared-grid__th--check\">\n              <mat-checkbox\n                  [checked]=\"allOnPageSelected()\"\n                  [indeterminate]=\"anySelected() && !allOnPageSelected()\"\n                  (change)=\"toggleAll($event.checked)\">\n              </mat-checkbox>\n            </th>\n          }\n          @for (col of visibleColumns(); track col.key()) {\n            <th #thEl class=\"ui-shared-grid__th\"\n                [class.ui-shared-grid__th--sortable]=\"col.sortable\"\n                [class.ui-shared-grid__th--sorted]=\"sortField() === col.sortField()\"\n                [class.ui-shared-grid__th--right]=\"col.align() === 'right'\"\n                [class.ui-shared-grid__th--center]=\"col.align() === 'center'\"\n                [attr.data-col-key]=\"col.key()\"\n                [style.width]=\"widthFor(col)\"\n                draggable=\"true\"\n                [attr.tabindex]=\"col.sortable ? 0 : null\"\n                [attr.role]=\"col.sortable ? 'button' : null\"\n                [attr.aria-sort]=\"ariaSortFor(col)\"\n                (dragstart)=\"onDragStart($event, col)\"\n                (dragover)=\"onDragOver($event)\"\n                (drop)=\"onDrop($event, col)\"\n                (click)=\"col.sortable && onHeaderClick(col)\"\n                (keydown.enter)=\"col.sortable && onHeaderClick(col)\"\n                (keydown.space)=\"col.sortable && onHeaderClick(col); $event.preventDefault()\">\n              <span class=\"ui-shared-grid__th-label\">{{ col.labelKey() | uiTranslate }}</span>\n              @if (col.sortable) {\n                <mat-icon class=\"ui-shared-grid__th-sort\">{{ sortIconFor(col) }}</mat-icon>\n              }\n              <!-- Resize handle: own pointer events, don't propagate to the\n                   sort-click handler on the header. -->\n              <span class=\"ui-shared-grid__th-resizer\"\n                    (pointerdown)=\"startResize($event, col, thEl)\"\n                    (click)=\"$event.stopPropagation()\"\n                    (dragstart)=\"$event.preventDefault(); $event.stopPropagation()\"\n                    aria-hidden=\"true\"></span>\n            </th>\n          }\n          <!-- Always-present rightmost utility column: hosts the grid settings\n               gear in the header, and the per-row actions menu in the body\n               (if an [#actions] template was projected). 48px wide. -->\n          <th class=\"ui-shared-grid__th ui-shared-grid__th--actions\">\n            <button mat-icon-button\n                    type=\"button\"\n                    class=\"ui-shared-grid__icon-btn ui-shared-grid__settings-trigger\"\n                    [matMenuTriggerFor]=\"gridSettingsMenu\"\n                    [matTooltip]=\"'core.grid.settings' | uiTranslate\"\n                    [attr.aria-label]=\"'core.grid.settings' | uiTranslate\"\n                    aria-haspopup=\"menu\">\n              <mat-icon>settings</mat-icon>\n            </button>\n            <mat-menu #gridSettingsMenu=\"matMenu\" xPosition=\"before\" class=\"ui-shared-grid__settings-menu\">\n              <!-- Clicks inside the menu must not close it: the user toggles several columns in a row. -->\n              <div class=\"ui-shared-grid__settings\" (click)=\"$event.stopPropagation()\" (keydown.tab)=\"$event.stopPropagation()\">\n                <mat-slide-toggle class=\"ui-shared-grid__settings-toggle\"\n                    [checked]=\"pagerTop()\"\n                    (change)=\"setPagerTop($event.checked)\">\n                  {{ 'core.grid.pagerTop' | uiTranslate }}\n                </mat-slide-toggle>\n                <mat-divider />\n                <div class=\"ui-shared-grid__settings-title\">{{ 'core.grid.columns' | uiTranslate }}</div>\n                @for (col of orderedColumns(); track col.key()) {\n                  <mat-checkbox class=\"ui-shared-grid__settings-column\"\n                      [checked]=\"!isHidden(col)\"\n                      [disabled]=\"!isHidden(col) && visibleColumns().length === 1\"\n                      (change)=\"toggleColumn(col, $event.checked)\">\n                    {{ col.labelKey() | uiTranslate }}\n                  </mat-checkbox>\n                }\n                <mat-divider />\n              </div>\n              <button mat-menu-item type=\"button\"\n                      [disabled]=\"!hasLayoutChanges()\"\n                      (click)=\"resetLayout()\">\n                <mat-icon>restart_alt</mat-icon>\n                <span>{{ 'core.grid.resetLayout' | uiTranslate }}</span>\n              </button>\n            </mat-menu>\n          </th>\n        </tr>\n      </thead>\n      <tbody>\n        @for (row of rows(); track $index) {\n          <tr class=\"ui-shared-grid__row\"\n              [class.ui-shared-grid__row--selected]=\"isSelected(row)\"\n              [class.ui-shared-grid__row--clickable]=\"interactive()\"\n              [attr.tabindex]=\"interactive() ? 0 : null\"\n              (click)=\"interactive() && rowClick.emit(row)\"\n              (keydown.enter)=\"onRowKeyEnter($event, row)\">\n            @if (detailTemplate()) {\n              <td class=\"ui-shared-grid__td ui-shared-grid__td--expand\" (click)=\"$event.stopPropagation()\">\n                <button mat-icon-button type=\"button\" class=\"ui-shared-grid__icon-btn ui-shared-grid__expand\"\n                        [class.ui-shared-grid__expand--open]=\"isExpanded(row)\"\n                        [attr.aria-expanded]=\"isExpanded(row)\"\n                        [attr.aria-label]=\"'core.grid.detail' | uiTranslate\"\n                        (click)=\"toggleExpanded(row)\">\n                  <mat-icon>chevron_right</mat-icon>\n                </button>\n              </td>\n            }\n            @if (selectable()) {\n              <td class=\"ui-shared-grid__td ui-shared-grid__td--check\" (click)=\"$event.stopPropagation()\">\n                <mat-checkbox\n                    [checked]=\"isSelected(row)\"\n                    (change)=\"toggleRow(row, $event.checked)\">\n                </mat-checkbox>\n              </td>\n            }\n            @for (col of visibleColumns(); track col.key()) {\n              <td class=\"ui-shared-grid__td\"\n                  [class.ui-shared-grid__td--right]=\"col.align() === 'right'\"\n                  [class.ui-shared-grid__td--center]=\"col.align() === 'center'\"\n                  [style.width]=\"widthFor(col)\">\n                <ng-container [ngTemplateOutlet]=\"col.cell()\"\n                              [ngTemplateOutletContext]=\"{ $implicit: row }\">\n                </ng-container>\n              </td>\n            }\n            <td class=\"ui-shared-grid__td ui-shared-grid__td--actions\" (click)=\"$event.stopPropagation()\">\n              @if (actionsTemplate(); as actions) {\n                <!-- The template decides per row what it shows; no items = no trigger. -->\n                <div hidden uiEmpty #probe=\"uiEmpty\">\n                  <ng-container [ngTemplateOutlet]=\"actions\" [ngTemplateOutletContext]=\"{ $implicit: row }\"></ng-container>\n                </div>\n                @if (!probe.empty()) {\n                <button mat-icon-button\n                        [matMenuTriggerFor]=\"rowMenu\"\n                        [matTooltip]=\"'core.grid.rowActions' | uiTranslate\"\n                        [attr.aria-label]=\"'core.grid.rowActions' | uiTranslate\"\n                        aria-haspopup=\"menu\"\n                        type=\"button\"\n                        class=\"ui-shared-grid__icon-btn ui-shared-grid__row-menu-trigger\">\n                  <mat-icon>more_vert</mat-icon>\n                </button>\n                <mat-menu #rowMenu=\"matMenu\" xPosition=\"before\">\n                  <ng-container [ngTemplateOutlet]=\"actions\"\n                                [ngTemplateOutletContext]=\"{ $implicit: row }\">\n                  </ng-container>\n                </mat-menu>\n                }\n              }\n            </td>\n          </tr>\n          @if (detailTemplate(); as detail) {\n            @if (isExpanded(row)) {\n              <tr class=\"ui-shared-grid__detail\">\n                <td class=\"ui-shared-grid__detail-cell\" [attr.colspan]=\"detailSpan()\">\n                  <ng-container [ngTemplateOutlet]=\"detail\" [ngTemplateOutletContext]=\"{ $implicit: row }\"></ng-container>\n                </td>\n              </tr>\n            }\n          }\n        }\n      </tbody>\n    </table>\n  </div>\n}\n\n@if (total() > 0) {\n  <!-- Pager stays mounted across loads so the page-change click is never\n       lost to an unmount/remount cycle. Buttons disable themselves via\n       canPrev / canNext; loading state is shown above. -->\n  <ui-shared-pager\n    [page]=\"page()\"\n    [pageSize]=\"pageSize()\"\n    [total]=\"total()\"\n    [pageSizeOptions]=\"pageSizeOptions()\"\n    (pageChange)=\"onPage($event)\"\n    (pageSizeChange)=\"onPageSize($event)\">\n  </ui-shared-pager>\n}\n", styles: [":host{display:block;box-sizing:border-box;min-width:0;max-width:100%}.ui-shared-grid__wrap{position:relative;overflow-x:clip}.ui-shared-grid__wrap--loading{pointer-events:none}.ui-shared-grid{width:100%;border-collapse:collapse;table-layout:fixed}.ui-shared-grid__th{position:relative;z-index:2;white-space:nowrap;-webkit-user-select:none;user-select:none;cursor:grab}.ui-shared-grid__th:active{cursor:grabbing}.ui-shared-grid__th--sortable{cursor:pointer}.ui-shared-grid__th-label{display:inline-block;max-width:100%;vertical-align:middle;overflow:hidden;text-overflow:ellipsis}.ui-shared-grid__th-sort{vertical-align:middle}.ui-shared-grid__th-resizer{position:absolute;top:0;right:0;z-index:1;width:6px;height:100%;cursor:col-resize}.ui-shared-grid__td{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;vertical-align:middle}.ui-shared-grid__th--right,.ui-shared-grid__td--right{text-align:right}.ui-shared-grid__th--center,.ui-shared-grid__td--center{text-align:center}.ui-shared-grid__th--actions,.ui-shared-grid__td--actions{width:48px}.ui-shared-grid__th--check,.ui-shared-grid__td--check,.ui-shared-grid__th--expand,.ui-shared-grid__td--expand{width:44px}.ui-shared-grid__th--expand,.ui-shared-grid__td--expand{cursor:default;overflow:visible}.ui-shared-grid__expand .mat-icon{transition:transform var(--ui-motion-fast)}.ui-shared-grid__expand--open .mat-icon{transform:rotate(90deg)}.ui-shared-grid__th--actions,.ui-shared-grid__th--check,.ui-shared-grid__td--check{cursor:default}.ui-shared-grid__td--actions,.ui-shared-grid__th--check,.ui-shared-grid__td--check{overflow:visible}.ui-shared-grid__row--clickable{cursor:pointer}.ui-shared-grid__icon-btn{display:inline-grid;place-items:center}.ui-shared-grid__filters,.ui-shared-grid__bulk-bar{display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between}.ui-shared-grid__filter-inputs{display:flex;flex-wrap:wrap;align-items:center;flex:1;min-width:0}.ui-shared-grid__filter-actions,.ui-shared-grid__bulk-actions{display:flex;align-items:center;margin-left:auto}.ui-shared-grid__state{display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center}.ui-shared-grid__state--loading{flex-direction:row}.ui-shared-grid__state-actions{display:flex}.ui-shared-grid__state-actions:empty{display:none}.ui-shared-grid__settings{display:flex;flex-direction:column}.ui-shared-grid__pager--top{display:block}\n"] }]
        }], ctorParameters: () => [] });

/**
 * Fetch one page of OData rows and map them to view-model T. Every service
 * backing a grid goes through this helper, so $top/$skip/$count/$orderby/
 * $filter/$expand and OData envelope unwrapping live in exactly one place.
 * Filters compose: `opts.filter` (service scope) AND `query.filter` (grid filters).
 */
function fetchOdataPage(http, baseUrl, query, opts, toView) {
    const parts = [
        `$top=${query.pageSize}`,
        `$skip=${(Math.max(1, query.page) - 1) * query.pageSize}`,
        `$count=true`,
    ];
    if (opts.expand)
        parts.push(`$expand=${encodeURIComponent(opts.expand)}`);
    const filter = andClauses([opts.filter, query.filter]);
    if (filter)
        parts.push(`$filter=${encodeURIComponent(filter)}`);
    const sortField = query.sortField ?? opts.defaultSort;
    if (sortField)
        parts.push(`$orderby=${encodeURIComponent(`${sortField} ${query.sortDir === 'desc' ? 'desc' : 'asc'}`)}`);
    return http.get(`${baseUrl}?${parts.join('&')}`).pipe(map(res => ({
        items: (res.value ?? []).map(toView),
        total: res['@odata.count'] ?? res.value?.length ?? 0,
    })));
}

/**
 * The standard Active / Deleted / All filter every soft-deletable management
 * grid projects, as a `<ui-shared-segmented>`. Pair with `softDeleteClauseBuilder`.
 */
const SOFT_DELETE_STATUS_OPTIONS = [
    { value: 'active', labelKey: 'common.filter.active' },
    { value: 'deleted', labelKey: 'common.filter.deleted' },
    { value: 'all', labelKey: 'common.filter.all' },
];
/** OData clause for `SOFT_DELETE_STATUS_OPTIONS` against the row's `IsDeleted` flag. */
function softDeleteClauseBuilder(v) {
    if (v === 'active')
        return 'IsDeleted eq false';
    if (v === 'deleted')
        return 'IsDeleted eq true';
    return null;
}

/**
 * Generated bundle index. Do not edit.
 */

export { SOFT_DELETE_STATUS_OPTIONS, UiEmptyDirective, UiSharedGridColumnComponent, UiSharedGridComponent, UiSharedPagerComponent, fetchOdataPage, softDeleteClauseBuilder };
//# sourceMappingURL=borassoft-ui-components-grid.mjs.map
