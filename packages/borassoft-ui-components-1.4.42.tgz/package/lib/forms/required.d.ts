import { Signal } from '@angular/core';
import { AbstractControl } from '@angular/forms';
/**
 * Whether the control is required, as a signal that follows the control's validators: a caller that adds or removes
 * `Validators.required` later (and calls `updateValueAndValidity`) flips the field's marker at once.
 * Call it in a field initialiser or constructor (injection context).
 */
export declare function requiredSignal(ctrl: Signal<AbstractControl>): Signal<boolean>;
//# sourceMappingURL=required.d.ts.map