import * as i0 from '@angular/core';
import { InjectionToken, inject, Pipe, signal, effect, Injectable } from '@angular/core';
import { EMPTY } from 'rxjs';
import { MAT_NATIVE_DATE_FORMATS, NativeDateAdapter, DateAdapter, MAT_DATE_FORMATS } from '@angular/material/core';

/** English fallback for every key the library renders; used when the app provides no translator. */
const UI_DEFAULT_TEXTS = {
    'core.grid.loading': 'Loading…',
    'core.color.none': 'No own colour',
    'core.grid.empty': 'No items to display.',
    'core.grid.rowActions': 'Row actions',
    'core.grid.settings': 'Grid settings',
    'core.grid.resetLayout': 'Reset to default',
    'core.grid.pagerTop': 'Pagination above the table',
    'core.grid.columns': 'Columns',
    'core.grid.selected': 'selected',
    'core.grid.clearSelection': 'Clear',
    'core.grid.filter.search': 'Search',
    'core.grid.filter.clear': 'Clear',
    'common.filter.active': 'Active',
    'common.filter.deleted': 'Deleted',
    'common.filter.all': 'All',
    'pager.first': 'First page',
    'pager.prev': 'Previous page',
    'pager.next': 'Next page',
    'pager.last': 'Last page',
    'pager.pageSize': 'Per page',
    'pager.of': 'of',
    'pager.label': 'Pagination',
    'common.none': '—',
    'common.back': 'Back',
    'common.close': 'Close',
    'common.expand': 'Expand',
    'common.collapse': 'Collapse',
    'common.yes': 'Yes',
    'common.no': 'No',
    'common.ok': 'OK',
    'common.loading': 'Loading…',
    'sidePanel.show': 'Show side panel',
    'sidePanel.hide': 'Hide side panel',
    'sidePanel.resize': 'Resize side panel',
    'htmlEditor.source': 'Source',
    'htmlEditor.preview': 'Preview',
    'form.password.show': 'Show password',
    'form.password.hide': 'Hide password',
    'form.errors.required': 'This field is required.',
    'form.errors.email': 'Enter a valid email address.',
    'form.errors.minlength': 'Too short.',
    'form.errors.maxlength': 'Too long.',
    'form.errors.pattern': 'Invalid format.',
    'form.errors.min': 'Value is too small.',
    'form.errors.max': 'Value is too large.',
    'form.errors.matDatepickerParse': 'Enter a valid date.',
    'form.errors.matDatepickerMin': 'Date is too early.',
    'form.errors.matDatepickerMax': 'Date is too late.',
};
/**
 * Key -> text resolver. Apps plug their own i18n in:
 * `{ provide: UI_TRANSLATE, useFactory: () => { const i = inject(I18nService); return (k: string) => i.t(k); } }`
 * If the resolver reads a signal (active locale), labels update on locale change (the pipe is impure).
 */
const UI_TRANSLATE = new InjectionToken('UI_TRANSLATE', {
    providedIn: 'root',
    factory: () => (key) => UI_DEFAULT_TEXTS[key] ?? key,
});
/** Stream of "reload grid X" signals (e.g. from SignalR). Defaults to none. */
const UI_REFRESH = new InjectionToken('UI_REFRESH', {
    providedIn: 'root',
    factory: () => EMPTY,
});
/**
 * Active locale for date formatting (`<ui-shared-display-date>`). A host returns its
 * locale signal's value so the display re-evaluates on language change:
 * `{ provide: UI_LOCALE, useFactory: () => { const i = inject(I18nService); return () => i.locale(); } }`
 */
const UI_LOCALE = new InjectionToken('UI_LOCALE', {
    providedIn: 'root',
    factory: () => () => 'en-US',
});
/** The one Angular date format `<ui-shared-display-date>` renders with. */
const UI_DATE_FORMAT = new InjectionToken('UI_DATE_FORMAT', {
    providedIn: 'root',
    factory: () => 'dd/MM/yyyy, HH:mm',
});
class UiTranslatePipe {
    translate = inject(UI_TRANSLATE);
    transform(key) {
        return this.translate(key);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiTranslatePipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe });
    static ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "19.2.25", ngImport: i0, type: UiTranslatePipe, isStandalone: true, name: "uiTranslate", pure: false });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiTranslatePipe, decorators: [{
            type: Pipe,
            args: [{ name: 'uiTranslate', standalone: true, pure: false }]
        }] });

/**
 * localStorage that never throws (private mode, quota, no storage): reads fall
 * back to null, writes are best-effort. Every persisted UI preference goes through it.
 */
const uiStorage = {
    get(key) {
        try {
            return localStorage.getItem(key);
        }
        catch {
            return null;
        }
    },
    set(key, value) {
        try {
            localStorage.setItem(key, value);
        }
        catch { /* best-effort */ }
    },
    remove(key) {
        try {
            localStorage.removeItem(key);
        }
        catch { /* best-effort */ }
    },
    /** Parsed JSON, or null when missing or corrupt. */
    getJson(key) {
        const raw = uiStorage.get(key);
        if (!raw)
            return null;
        try {
            return JSON.parse(raw);
        }
        catch {
            return null;
        }
    },
    setJson(key, value) {
        uiStorage.set(key, JSON.stringify(value));
    },
};
const choiceKey = (key) => `ui.choice.${key}`;
/** The choice remembered under `key`, or null when missing or no longer one of `allowed`. */
function storedChoice(key, allowed) {
    const saved = uiStorage.getJson(choiceKey(key));
    return saved !== null && allowed.includes(saved) ? saved : null;
}
function storeChoice(key, value) {
    uiStorage.setJson(choiceKey(key), value);
}

/**
 * Follows a pointer drag (column / panel resize): `onMove` runs inside the zone
 * for every move, `onEnd` once when the pointer is released or cancelled. While
 * dragging, `body` carries `ui-resizing` so the host can force the resize cursor.
 * Returns a stop function — call it on destroy so a drag never outlives its component.
 */
function trackPointerDrag(zone, onMove, onEnd = () => { }) {
    let done = false;
    const move = (e) => zone.run(() => onMove(e));
    const stop = () => {
        if (done)
            return;
        done = true;
        window.removeEventListener('pointermove', move);
        window.removeEventListener('pointerup', stop);
        window.removeEventListener('pointercancel', stop);
        document.body.classList.remove('ui-resizing');
        zone.run(onEnd);
    };
    zone.runOutsideAngular(() => {
        window.addEventListener('pointermove', move);
        window.addEventListener('pointerup', stop);
        window.addEventListener('pointercancel', stop);
        document.body.classList.add('ui-resizing');
    });
    return stop;
}

/**
 * The translation key of the first error on a touched/dirty control, as
 * `form.errors.<validatorKey>` — the built-in validators and any custom one
 * (`{ greekAfm: true }` → `form.errors.greekAfm`). Pair with `uiTranslate`
 * (or the host's own pipe): `@if (firstError(ctrl); as key) { <mat-error>{{ key | uiTranslate }}</mat-error> }`
 */
function firstError(control) {
    if (!control || !control.errors || !(control.touched || control.dirty))
        return null;
    const key = Object.keys(control.errors)[0];
    return key ? `form.errors.${key}` : null;
}

/** The text an option shows. */
function optionText(o, translate) {
    return o.labelKey ? translate(o.labelKey) : o.label ?? String(o.value ?? '');
}
/** `{{ option | uiOptionText }}` — impure so labels follow a locale change, like `uiTranslate`. */
class UiOptionTextPipe {
    translate = inject(UI_TRANSLATE);
    transform(option) {
        return optionText(option, this.translate);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiOptionTextPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe });
    static ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "19.2.25", ngImport: i0, type: UiOptionTextPipe, isStandalone: true, name: "uiOptionText", pure: false });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiOptionTextPipe, decorators: [{
            type: Pipe,
            args: [{ name: 'uiOptionText', standalone: true, pure: false }]
        }] });

const UI_GRID_FILTER = new InjectionToken('UI_GRID_FILTER');
/** Registers a component's `filter` state under `UI_GRID_FILTER` so the grid finds it. */
function provideGridFilter(component) {
    return { provide: UI_GRID_FILTER, useFactory: () => inject(component()).filter };
}
/** An OData string literal: `O'Brien` → `'O''Brien'`. */
function odataString(value) {
    return `'${value.replace(/'/g, "''")}'`;
}
/** ANDs the non-empty clauses (each parenthesised when there is more than one); undefined when none. */
function andClauses(clauses) {
    const parts = clauses.filter((c) => !!c?.trim());
    if (parts.length <= 1)
        return parts[0];
    return parts.map(c => `(${c})`).join(' and ');
}
const GUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
/**
 * OData v4 literal for a filter value: numbers, booleans and GUIDs are written
 * bare (`Id eq 5`, `TypeId eq e059…`), everything else as a quoted string. A
 * string column holding GUID-shaped text needs its own `clauseBuilder`.
 */
function odataLiteral(value) {
    if (typeof value === 'number' || typeof value === 'boolean')
        return String(value);
    const s = String(value);
    return GUID.test(s) ? s : odataString(s);
}
/** `field eq <literal>`; null without a field. */
function eqClause(field) {
    return field ? v => `${field} eq ${odataLiteral(v)}` : null;
}
const blank = (v) => v === null || v === undefined || (typeof v === 'string' && !v.trim());
/**
 * Pending vs applied value of an input used as a grid filter: the control holds
 * what the user typed/picked, the grid filters by the applied value, which only
 * moves on Search / Clear. Without a clause builder the input is not a filter
 * and every method is a no-op.
 */
class GridFilterState {
    control;
    builder;
    initial;
    /** `undefined` = still at the initial value. */
    applied = signal(undefined);
    constructor(control, builder, initial = () => null) {
        this.control = control;
        this.builder = builder;
        this.initial = initial;
    }
    isFilter() { return !!this.builder(); }
    /** Seeds the control with the initial value (e.g. the "active" pill). Call from ngOnInit. */
    init() {
        const i = this.initial();
        if (this.isFilter() && i !== null && blank(this.control().value))
            this.control().setValue(i);
    }
    /** Puts a remembered value in place as both pending and applied (no Search needed). */
    restore(value) {
        this.control().setValue(value);
        if (this.isFilter())
            this.applied.set(value);
    }
    clause() {
        const build = this.builder();
        const v = this.value();
        return build && !blank(v) ? build(v) : null;
    }
    isApplied() { return this.isFilter() && this.value() !== this.initial(); }
    applyPending() {
        if (!this.isFilter())
            return;
        const v = this.control().value;
        this.applied.set(blank(v) ? null : typeof v === 'string' ? v.trim() : v);
    }
    clearAll() {
        if (!this.isFilter())
            return;
        this.control().setValue(this.initial());
        this.applied.set(undefined);
    }
    /** The value the grid filters by: what Search applied, else the initial one. */
    value() {
        const a = this.applied();
        return a === undefined ? this.initial() : a;
    }
}

/** localStorage key the theme is remembered under. Override to keep an existing key. */
const UI_THEME_STORAGE_KEY = new InjectionToken('UI_THEME_STORAGE_KEY', {
    providedIn: 'root',
    factory: () => 'ui.theme',
});
/**
 * Light / dark theme state. Mirrors the active theme to
 * `<html data-theme="light|dark">` (the host's stylesheet keys its dark tokens
 * off that attribute) and persists it; the first value comes from storage,
 * then from `prefers-color-scheme`.
 */
class UiThemeService {
    key = inject(UI_THEME_STORAGE_KEY);
    _theme = signal(this.initial());
    theme = this._theme.asReadonly();
    isDark = () => this._theme() === 'dark';
    constructor() {
        effect(() => {
            const t = this._theme();
            document.documentElement.setAttribute('data-theme', t);
            uiStorage.set(this.key, t);
        });
    }
    toggle() {
        this._theme.update(t => (t === 'dark' ? 'light' : 'dark'));
    }
    set(theme) {
        this._theme.set(theme);
    }
    initial() {
        const saved = uiStorage.get(this.key);
        if (saved === 'light' || saved === 'dark')
            return saved;
        return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiThemeService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiThemeService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiThemeService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: () => [] });

/** Sentinel format the adapter recognises as "the text-input format". */
const UI_DATE_INPUT_FORMAT = 'dd/MM/yyyy';
/**
 * Datepicker formats: every date INPUT renders and parses as dd/MM/yyyy
 * (day-first, matching <ui-shared-display-date>), the calendar popup keeps
 * the native month/year labels.
 */
const UI_DATE_FORMATS = {
    ...MAT_NATIVE_DATE_FORMATS,
    parse: { dateInput: UI_DATE_INPUT_FORMAT },
    display: { ...MAT_NATIVE_DATE_FORMATS.display, dateInput: UI_DATE_INPUT_FORMAT },
};
/**
 * NativeDateAdapter with a fixed day-first text format. The stock adapter goes
 * through the browser's Intl locale (US builds show M/D/YYYY and parse "05/07"
 * as May 7); this pins dd/MM/yyyy for typing AND display, whatever the locale.
 */
class UiDateAdapter extends NativeDateAdapter {
    format(date, displayFormat) {
        if (displayFormat === UI_DATE_INPUT_FORMAT) {
            const dd = `${date.getDate()}`.padStart(2, '0');
            const mm = `${date.getMonth() + 1}`.padStart(2, '0');
            return `${dd}/${mm}/${date.getFullYear()}`;
        }
        return super.format(date, displayFormat);
    }
    parse(value) {
        if (typeof value === 'string') {
            const text = value.trim();
            if (!text)
                return null;
            const m = text.match(/^(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{2,4})$/);
            if (!m)
                return this.invalid();
            const day = +m[1];
            const month = +m[2] - 1;
            const year = +m[3] < 100 ? 2000 + +m[3] : +m[3];
            const parsed = new Date(year, month, day);
            // Reject rollovers like 31/02 -> 03/03: the parts must survive intact.
            return parsed.getFullYear() === year && parsed.getMonth() === month && parsed.getDate() === day
                ? parsed
                : this.invalid();
        }
        return super.parse(value);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiDateAdapter, deps: null, target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiDateAdapter });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiDateAdapter, decorators: [{
            type: Injectable
        }] });
/** Wires the day-first date adapter + formats into the app (`providers: [provideUiDates()]`). */
function provideUiDates() {
    return [
        { provide: DateAdapter, useClass: UiDateAdapter },
        { provide: MAT_DATE_FORMATS, useValue: UI_DATE_FORMATS },
    ];
}

/**
 * Generated bundle index. Do not edit.
 */

export { GridFilterState, UI_DATE_FORMAT, UI_DATE_FORMATS, UI_DATE_INPUT_FORMAT, UI_DEFAULT_TEXTS, UI_GRID_FILTER, UI_LOCALE, UI_REFRESH, UI_THEME_STORAGE_KEY, UI_TRANSLATE, UiDateAdapter, UiOptionTextPipe, UiThemeService, UiTranslatePipe, andClauses, eqClause, firstError, odataLiteral, odataString, optionText, provideGridFilter, provideUiDates, storeChoice, storedChoice, trackPointerDrag, uiStorage };
//# sourceMappingURL=borassoft-ui-components.mjs.map
