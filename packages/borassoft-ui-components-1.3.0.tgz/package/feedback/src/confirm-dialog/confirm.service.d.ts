import { Observable } from 'rxjs';
import { ConfirmDialogData } from './ui-shared-confirm-dialog.component';
import * as i0 from "@angular/core";
/**
 * The ONE way to ask the user "Yes / No" before an action. Every confirmation
 * opens the same dialog with the same size and focus behaviour; the returned
 * stream emits only on explicit confirm, so callers subscribe to the "yes"
 * branch and never check the result.
 */
export declare class UiConfirmService {
    private dialog;
    confirm(data: ConfirmDialogData): Observable<true>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UiConfirmService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UiConfirmService>;
}
//# sourceMappingURL=confirm.service.d.ts.map