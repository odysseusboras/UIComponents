import * as i0 from '@angular/core';
import { input, booleanAttribute, ChangeDetectionStrategy, Component, inject, computed, signal, effect, linkedSignal } from '@angular/core';
import * as i1 from '@angular/material/icon';
import { MatIconModule } from '@angular/material/icon';
import * as i2 from '@angular/material/tooltip';
import { MatTooltipModule } from '@angular/material/tooltip';
import { NgTemplateOutlet, DatePipe } from '@angular/common';
import { RouterLink } from '@angular/router';
import * as i2$1 from '@angular/material/progress-spinner';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { UI_LOCALE, UI_DATE_FORMAT, UiTranslatePipe, UI_TRANSLATE } from '@borassoft/ui-components';
import { DomSanitizer } from '@angular/platform-browser';
import qrcode from 'qrcode-generator';
import * as i2$2 from '@angular/material/badge';
import { MatBadgeModule } from '@angular/material/badge';

/**
 * The one status/state pill, so every grid, detail page and drawer renders
 * state identically.
 *
 *   <ui-shared-status-chip [tone]="activeTone(row.isDeleted)" icon="check_circle">
 *     {{ 'documents.status.submitted' | uiTranslate }}
 *   </ui-shared-status-chip>
 *
 *   <ui-shared-status-chip tone="bad" dot size="lg" [tooltip]="row.errorMessage">…</ui-shared-status-chip>
 */
class UiSharedStatusChipComponent {
    tone = input('muted');
    /** Optional leading Material icon name. */
    icon = input('');
    /** Leading state dot instead of an icon. */
    dot = input(false, { transform: booleanAttribute });
    size = input('sm');
    /** Tooltip text (already translated). Adds `cursor: help`. */
    tooltip = input('');
    /** Transparent fill with a tinted border. */
    outline = input(false, { transform: booleanAttribute });
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedStatusChipComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: UiSharedStatusChipComponent, isStandalone: true, selector: "ui-shared-status-chip", inputs: { tone: { classPropertyName: "tone", publicName: "tone", isSignal: true, isRequired: false, transformFunction: null }, icon: { classPropertyName: "icon", publicName: "icon", isSignal: true, isRequired: false, transformFunction: null }, dot: { classPropertyName: "dot", publicName: "dot", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, tooltip: { classPropertyName: "tooltip", publicName: "tooltip", isSignal: true, isRequired: false, transformFunction: null }, outline: { classPropertyName: "outline", publicName: "outline", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: "<span class=\"ui-shared-status-chip\"\n      [class.ui-shared-status-chip--ok]=\"tone() === 'ok'\"\n      [class.ui-shared-status-chip--warn]=\"tone() === 'warn'\"\n      [class.ui-shared-status-chip--bad]=\"tone() === 'bad'\"\n      [class.ui-shared-status-chip--info]=\"tone() === 'info'\"\n      [class.ui-shared-status-chip--muted]=\"tone() === 'muted'\"\n      [class.ui-shared-status-chip--lg]=\"size() === 'lg'\"\n      [class.ui-shared-status-chip--outline]=\"outline()\"\n      [class.ui-shared-status-chip--help]=\"!!tooltip()\"\n      [matTooltip]=\"tooltip()\"\n      [matTooltipDisabled]=\"!tooltip()\">\n  @if (dot()) {\n    <span class=\"ui-shared-status-chip__dot\" aria-hidden=\"true\"></span>\n  } @else if (icon()) {\n    <mat-icon aria-hidden=\"true\">{{ icon() }}</mat-icon>\n  }\n  <ng-content></ng-content>\n</span>\n", styles: [":host{display:inline-flex;box-sizing:border-box;min-width:0;max-width:100%}:host{vertical-align:middle}.ui-shared-status-chip{display:inline-flex;align-items:center;white-space:nowrap;vertical-align:middle}.ui-shared-status-chip--help{cursor:help}\n"], dependencies: [{ kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i1.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "directive", type: i2.MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedStatusChipComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ui-shared-status-chip', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, imports: [MatIconModule, MatTooltipModule], template: "<span class=\"ui-shared-status-chip\"\n      [class.ui-shared-status-chip--ok]=\"tone() === 'ok'\"\n      [class.ui-shared-status-chip--warn]=\"tone() === 'warn'\"\n      [class.ui-shared-status-chip--bad]=\"tone() === 'bad'\"\n      [class.ui-shared-status-chip--info]=\"tone() === 'info'\"\n      [class.ui-shared-status-chip--muted]=\"tone() === 'muted'\"\n      [class.ui-shared-status-chip--lg]=\"size() === 'lg'\"\n      [class.ui-shared-status-chip--outline]=\"outline()\"\n      [class.ui-shared-status-chip--help]=\"!!tooltip()\"\n      [matTooltip]=\"tooltip()\"\n      [matTooltipDisabled]=\"!tooltip()\">\n  @if (dot()) {\n    <span class=\"ui-shared-status-chip__dot\" aria-hidden=\"true\"></span>\n  } @else if (icon()) {\n    <mat-icon aria-hidden=\"true\">{{ icon() }}</mat-icon>\n  }\n  <ng-content></ng-content>\n</span>\n", styles: [":host{display:inline-flex;box-sizing:border-box;min-width:0;max-width:100%}:host{vertical-align:middle}.ui-shared-status-chip{display:inline-flex;align-items:center;white-space:nowrap;vertical-align:middle}.ui-shared-status-chip--help{cursor:help}\n"] }]
        }] });

/** Soft-delete flag → chip tone (Active → ok, Deleted → bad). */
function activeTone(isDeleted) {
    return isDeleted ? 'bad' : 'ok';
}

/**
 * The one KPI tile (overview stats, summaries): icon + label + value, optional
 * tinted tone, optional link. Project extra lines as content; they render
 * under the value in the muted sub style.
 *
 *   <ui-shared-stat-tile icon="trending_up" [label]="'dashboard.income' | uiTranslate"
 *                 [value]="(d.income.totalGross | number:'1.2-2') + ' €'" [link]="documentsLink()">
 *     {{ 'dashboard.net' | uiTranslate }} {{ d.income.totalNet | number:'1.2-2' }}
 *   </ui-shared-stat-tile>
 */
class UiSharedStatTileComponent {
    icon = input.required();
    /** Already translated. */
    label = input.required();
    /** Already formatted; ignored while `loading`, shows an em dash when empty. */
    value = input(null);
    loading = input(false, { transform: booleanAttribute });
    /** Tints the icon and the value. */
    tone = input('');
    link = input(null);
    queryParams = input(null);
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedStatTileComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: UiSharedStatTileComponent, isStandalone: true, selector: "ui-shared-stat-tile", inputs: { icon: { classPropertyName: "icon", publicName: "icon", isSignal: true, isRequired: true, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: true, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, loading: { classPropertyName: "loading", publicName: "loading", isSignal: true, isRequired: false, transformFunction: null }, tone: { classPropertyName: "tone", publicName: "tone", isSignal: true, isRequired: false, transformFunction: null }, link: { classPropertyName: "link", publicName: "link", isSignal: true, isRequired: false, transformFunction: null }, queryParams: { classPropertyName: "queryParams", publicName: "queryParams", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: "<ng-template #body>\n  <div class=\"ui-shared-stat-tile__icon\" [attr.data-tone]=\"tone() || null\"><mat-icon>{{ icon() }}</mat-icon></div>\n  <div class=\"ui-shared-stat-tile__body\">\n    <div class=\"ui-shared-stat-tile__label\">{{ label() }}</div>\n    <div class=\"ui-shared-stat-tile__value\" [attr.data-tone]=\"tone() || null\">\n      @if (loading()) {\n        <mat-progress-spinner mode=\"indeterminate\" diameter=\"20\" />\n      } @else if (value() !== null && value() !== undefined && value() !== '') {\n        {{ value() }}\n      } @else {\n        <span class=\"ui-shared-stat-tile__empty\">\u2014</span>\n      }\n    </div>\n    @if (!loading()) {\n      <div class=\"ui-shared-stat-tile__sub\"><ng-content /></div>\n    }\n  </div>\n  @if (link()) {\n    <mat-icon class=\"ui-shared-stat-tile__arrow\">chevron_right</mat-icon>\n  }\n</ng-template>\n\n@if (link(); as l) {\n  <a class=\"ui-shared-stat-tile\" [routerLink]=\"l\" [queryParams]=\"queryParams()\">\n    <ng-container [ngTemplateOutlet]=\"body\" />\n  </a>\n} @else {\n  <div class=\"ui-shared-stat-tile ui-shared-stat-tile--static\">\n    <ng-container [ngTemplateOutlet]=\"body\" />\n  </div>\n}\n", styles: [":host{display:block;box-sizing:border-box;min-width:0;max-width:100%}.ui-shared-stat-tile{display:grid;grid-template-columns:auto 1fr auto;align-items:center;height:100%;box-sizing:border-box;text-decoration:none;color:inherit}.ui-shared-stat-tile__icon{display:grid;place-items:center}.ui-shared-stat-tile__body{display:flex;flex-direction:column;min-width:0}.ui-shared-stat-tile__value{display:flex;align-items:center}.ui-shared-stat-tile__sub:empty{display:none}\n"], dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i1.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatProgressSpinnerModule }, { kind: "component", type: i2$1.MatProgressSpinner, selector: "mat-progress-spinner, mat-spinner", inputs: ["color", "mode", "value", "diameter", "strokeWidth"], exportAs: ["matProgressSpinner"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedStatTileComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ui-shared-stat-tile', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, imports: [NgTemplateOutlet, RouterLink, MatIconModule, MatProgressSpinnerModule], template: "<ng-template #body>\n  <div class=\"ui-shared-stat-tile__icon\" [attr.data-tone]=\"tone() || null\"><mat-icon>{{ icon() }}</mat-icon></div>\n  <div class=\"ui-shared-stat-tile__body\">\n    <div class=\"ui-shared-stat-tile__label\">{{ label() }}</div>\n    <div class=\"ui-shared-stat-tile__value\" [attr.data-tone]=\"tone() || null\">\n      @if (loading()) {\n        <mat-progress-spinner mode=\"indeterminate\" diameter=\"20\" />\n      } @else if (value() !== null && value() !== undefined && value() !== '') {\n        {{ value() }}\n      } @else {\n        <span class=\"ui-shared-stat-tile__empty\">\u2014</span>\n      }\n    </div>\n    @if (!loading()) {\n      <div class=\"ui-shared-stat-tile__sub\"><ng-content /></div>\n    }\n  </div>\n  @if (link()) {\n    <mat-icon class=\"ui-shared-stat-tile__arrow\">chevron_right</mat-icon>\n  }\n</ng-template>\n\n@if (link(); as l) {\n  <a class=\"ui-shared-stat-tile\" [routerLink]=\"l\" [queryParams]=\"queryParams()\">\n    <ng-container [ngTemplateOutlet]=\"body\" />\n  </a>\n} @else {\n  <div class=\"ui-shared-stat-tile ui-shared-stat-tile--static\">\n    <ng-container [ngTemplateOutlet]=\"body\" />\n  </div>\n}\n", styles: [":host{display:block;box-sizing:border-box;min-width:0;max-width:100%}.ui-shared-stat-tile{display:grid;grid-template-columns:auto 1fr auto;align-items:center;height:100%;box-sizing:border-box;text-decoration:none;color:inherit}.ui-shared-stat-tile__icon{display:grid;place-items:center}.ui-shared-stat-tile__body{display:flex;flex-direction:column;min-width:0}.ui-shared-stat-tile__value{display:flex;align-items:center}.ui-shared-stat-tile__sub:empty{display:none}\n"] }]
        }] });

/**
 * Single source of truth for rendering ANY date.
 *
 *   <ui-shared-display-date [value]="row.dateCreated" />
 *   <ui-shared-display-date [value]="row.dateCreated" empty="never" />
 *
 * ONE format app-wide, from `UI_DATE_FORMAT` (default `dd/MM/yyyy, HH:mm`),
 * rendered in the locale `UI_LOCALE` returns. The `mode` input is accepted
 * but IGNORED so existing `mode="date"` call sites keep working. Because the
 * locale is read inside a computed, a host whose `UI_LOCALE` reads a signal
 * gets a re-render on language change.
 */
class UiSharedDisplayDateComponent {
    /** The date to render. Accepts ISO-8601 strings (the wire format), Date, number, null, undefined. */
    value = input(null);
    /** Accepted but IGNORED — there is one format (date + time). Kept so existing call sites don't break. */
    mode = input('datetime');
    /** What to render when the value is null/empty. Defaults to an em-dash. */
    empty = input('—');
    locale = inject(UI_LOCALE);
    format = inject(UI_DATE_FORMAT);
    /** NULL when the value can't be rendered — the template branches to the [empty] rendering. */
    formatted = computed(() => {
        const v = this.value();
        if (v === null || v === undefined || v === '')
            return null;
        // DatePipe throws on text it can't parse; a bad value shows as empty, not a broken page.
        try {
            return new DatePipe(this.locale()).transform(v, this.format);
        }
        catch {
            return null;
        }
    });
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedDisplayDateComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: UiSharedDisplayDateComponent, isStandalone: true, selector: "ui-shared-display-date", inputs: { value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, mode: { classPropertyName: "mode", publicName: "mode", isSignal: true, isRequired: false, transformFunction: null }, empty: { classPropertyName: "empty", publicName: "empty", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: "@if (formatted(); as text) {\n  <span class=\"ui-shared-display-date\">{{ text }}</span>\n} @else {\n  <span class=\"ui-shared-display-date ui-shared-display-date--empty\">{{ empty() }}</span>\n}\n", styles: [":host{display:inline;box-sizing:border-box;min-width:0;max-width:100%}.ui-shared-display-date{white-space:nowrap}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedDisplayDateComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ui-shared-display-date', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: "@if (formatted(); as text) {\n  <span class=\"ui-shared-display-date\">{{ text }}</span>\n} @else {\n  <span class=\"ui-shared-display-date ui-shared-display-date--empty\">{{ empty() }}</span>\n}\n", styles: [":host{display:inline;box-sizing:border-box;min-width:0;max-width:100%}.ui-shared-display-date{white-space:nowrap}\n"] }]
        }] });

/**
 * Renders a string (e.g. a verification URL) as an actual QR code. Pure
 * client-side, zero network: qrcode-generator builds a scalable SVG that fills
 * the host box (size it from the parent).
 */
class UiSharedQrCodeComponent {
    /** The payload to encode. */
    value = input.required();
    sanitizer = inject(DomSanitizer);
    svg = computed(() => {
        const v = this.value();
        if (!v)
            return '';
        const qr = qrcode(0, 'M');
        qr.addData(v);
        qr.make();
        return this.sanitizer.bypassSecurityTrustHtml(qr.createSvgTag({ scalable: true, margin: 0 }));
    });
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedQrCodeComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "19.2.25", type: UiSharedQrCodeComponent, isStandalone: true, selector: "ui-shared-qr-code", inputs: { value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: true, transformFunction: null } }, ngImport: i0, template: "<div class=\"ui-shared-qr-code\" [innerHTML]=\"svg()\"></div>\n", styles: [":host{display:inline-block;box-sizing:border-box;min-width:0;max-width:100%}:host{line-height:0}.ui-shared-qr-code{width:100%;height:100%}\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedQrCodeComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ui-shared-qr-code', standalone: true, template: "<div class=\"ui-shared-qr-code\" [innerHTML]=\"svg()\"></div>\n", styles: [":host{display:inline-block;box-sizing:border-box;min-width:0;max-width:100%}:host{line-height:0}.ui-shared-qr-code{width:100%;height:100%}\n"] }]
        }] });

/**
 * A Material Symbols icon by name. `size` sm 18px / md 24px / lg 32px,
 * `tone` colours it, `badge` shows a count (hidden when empty or 0).
 *
 *   <ui-shared-icon name="receipt_long" />
 *   <ui-shared-icon name="notifications" [badge]="unread()" />
 */
class UiSharedIconComponent {
    name = input.required();
    size = input('md');
    tone = input('inherit');
    badge = input(null);
    hostClass = computed(() => `ui-shared-icon ui-shared-icon--${this.size()} ui-shared-icon--${this.tone()}`);
    badgeHidden = computed(() => { const b = this.badge(); return b == null || b === '' || b === 0; });
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "19.2.25", type: UiSharedIconComponent, isStandalone: true, selector: "ui-shared-icon", inputs: { name: { classPropertyName: "name", publicName: "name", isSignal: true, isRequired: true, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, tone: { classPropertyName: "tone", publicName: "tone", isSignal: true, isRequired: false, transformFunction: null }, badge: { classPropertyName: "badge", publicName: "badge", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "hostClass()" } }, ngImport: i0, template: "<mat-icon aria-hidden=\"true\" [matBadge]=\"badge()\" [matBadgeHidden]=\"badgeHidden()\" matBadgeColor=\"warn\" matBadgeSize=\"medium\">{{ name() }}</mat-icon>\n", styles: [":host{display:inline-flex;box-sizing:border-box;min-width:0;max-width:100%}:host{vertical-align:middle;align-items:center;justify-content:center}mat-icon{flex:none}\n"], dependencies: [{ kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i1.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatBadgeModule }, { kind: "directive", type: i2$2.MatBadge, selector: "[matBadge]", inputs: ["matBadgeColor", "matBadgeOverlap", "matBadgeDisabled", "matBadgePosition", "matBadge", "matBadgeDescription", "matBadgeSize", "matBadgeHidden"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ui-shared-icon', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, imports: [MatIconModule, MatBadgeModule], host: { '[class]': 'hostClass()' }, template: "<mat-icon aria-hidden=\"true\" [matBadge]=\"badge()\" [matBadgeHidden]=\"badgeHidden()\" matBadgeColor=\"warn\" matBadgeSize=\"medium\">{{ name() }}</mat-icon>\n", styles: [":host{display:inline-flex;box-sizing:border-box;min-width:0;max-width:100%}:host{vertical-align:middle;align-items:center;justify-content:center}mat-icon{flex:none}\n"] }]
        }] });

/** Initials disc for a person: `<ui-shared-avatar [name]="user.name" />`. Up to two initials, from the first two words. */
class UiSharedAvatarComponent {
    name = input.required();
    size = input('md');
    initials = computed(() => this.name().trim().split(/\s+/).slice(0, 2).map(w => w[0] ?? '').join('').toUpperCase());
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedAvatarComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "19.2.25", type: UiSharedAvatarComponent, isStandalone: true, selector: "ui-shared-avatar", inputs: { name: { classPropertyName: "name", publicName: "name", isSignal: true, isRequired: true, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null } }, host: { attributes: { "aria-hidden": "true" }, properties: { "class.ui-shared-avatar--lg": "size() === \"lg\"" }, classAttribute: "ui-shared-avatar" }, ngImport: i0, template: "{{ initials() }}\n", styles: [":host{display:inline-flex;box-sizing:border-box;min-width:0;max-width:100%}:host{align-items:center;justify-content:center;flex-shrink:0}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedAvatarComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ui-shared-avatar', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, host: { class: 'ui-shared-avatar', '[class.ui-shared-avatar--lg]': 'size() === "lg"', 'aria-hidden': 'true' }, template: "{{ initials() }}\n", styles: [":host{display:inline-flex;box-sizing:border-box;min-width:0;max-width:100%}:host{align-items:center;justify-content:center;flex-shrink:0}\n"] }]
        }] });

/**
 * A stored reference to a lookup / organisation row, marked when that row has since been
 * soft-deleted: the label is struck through and a small "inactive" mark follows it. Use it in
 * grids and read-only views wherever old data may point to a value that is no longer offered.
 *
 *   <ui-shared-inactive-value [label]="a.regionName" [inactive]="a.regionIsDeleted" />
 */
class UiSharedInactiveValueComponent {
    label = input('');
    inactive = input(false, { transform: booleanAttribute });
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedInactiveValueComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: UiSharedInactiveValueComponent, isStandalone: true, selector: "ui-shared-inactive-value", inputs: { label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, inactive: { classPropertyName: "inactive", publicName: "inactive", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    @if (inactive()) {
      <s class="ui-shared-inactive-value__label">{{ label() }}</s>
      <span class="ui-shared-inactive-mark" [matTooltip]="'common.inactiveHint' | uiTranslate">{{ 'common.inactive' | uiTranslate }}</span>
    } @else {
      <span class="ui-shared-inactive-value__label">{{ label() }}</span>
    }
  `, isInline: true, styles: [":host{display:flex;align-items:center;gap:.4rem;min-width:0;max-width:100%}.ui-shared-inactive-value__label{flex:0 1 auto;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.ui-shared-inactive-mark{flex:0 0 auto}\n"], dependencies: [{ kind: "ngmodule", type: MatTooltipModule }, { kind: "directive", type: i2.MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }, { kind: "pipe", type: UiTranslatePipe, name: "uiTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedInactiveValueComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ui-shared-inactive-value', standalone: true, imports: [MatTooltipModule, UiTranslatePipe], changeDetection: ChangeDetectionStrategy.OnPush, template: `
    @if (inactive()) {
      <s class="ui-shared-inactive-value__label">{{ label() }}</s>
      <span class="ui-shared-inactive-mark" [matTooltip]="'common.inactiveHint' | uiTranslate">{{ 'common.inactive' | uiTranslate }}</span>
    } @else {
      <span class="ui-shared-inactive-value__label">{{ label() }}</span>
    }
  `, styles: [":host{display:flex;align-items:center;gap:.4rem;min-width:0;max-width:100%}.ui-shared-inactive-value__label{flex:0 1 auto;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.ui-shared-inactive-mark{flex:0 0 auto}\n"] }]
        }] });

/**
 * Image carousel: the images crossfade one after the other; arrows and a dot per image pick one by hand.
 * Projected content sits on top of the images (a hero's title and buttons) and the host styles
 * any veil it wants between the two through `--ui-carousel-veil`.
 *
 *   <ui-shared-carousel [images]="['/images/home-1.jpg', '/images/home-2.jpg']" [interval]="7000">
 *     <h1>…</h1>
 *   </ui-shared-carousel>
 */
class UiSharedCarouselComponent {
    images = input.required();
    /** Milliseconds between two images; 0 = no auto-play. */
    interval = input(7000);
    current = signal(0);
    step(by) { this.current.update(i => (i + by + this.images().length) % this.images().length); }
    constructor() {
        // Restarts when the images or the interval change; the cleanup also runs on destroy.
        effect(onCleanup => {
            const n = this.images().length;
            const ms = this.interval();
            if (ms <= 0 || n < 2)
                return;
            const timer = setInterval(() => this.current.update(i => (i + 1) % n), ms);
            onCleanup(() => clearInterval(timer));
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedCarouselComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: UiSharedCarouselComponent, isStandalone: true, selector: "ui-shared-carousel", inputs: { images: { classPropertyName: "images", publicName: "images", isSignal: true, isRequired: true, transformFunction: null }, interval: { classPropertyName: "interval", publicName: "interval", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: "<div class=\"ui-shared-carousel\" [class.ui-shared-carousel--arrows]=\"images().length > 1\">\n  @for (src of images(); track src; let i = $index) {\n    <img class=\"ui-shared-carousel__image\" [class.ui-shared-carousel__image--on]=\"i === current()\" [src]=\"src\" alt=\"\"\n         [attr.loading]=\"i ? 'lazy' : null\" />\n  }\n  <div class=\"ui-shared-carousel__veil\"></div>\n  <div class=\"ui-shared-carousel__content\">\n    <ng-content />\n    @if (images().length > 1) {\n      <button type=\"button\" class=\"ui-shared-carousel__arrow ui-shared-carousel__arrow--prev\" [attr.aria-label]=\"'core.carousel.previous' | uiTranslate\" (click)=\"step(-1)\">\n        <ui-shared-icon name=\"chevron_left\" />\n      </button>\n      <button type=\"button\" class=\"ui-shared-carousel__arrow ui-shared-carousel__arrow--next\" [attr.aria-label]=\"'core.carousel.next' | uiTranslate\" (click)=\"step(1)\">\n        <ui-shared-icon name=\"chevron_right\" />\n      </button>\n      <div class=\"ui-shared-carousel__dots\">\n        @for (src of images(); track src; let i = $index) {\n          <button type=\"button\" class=\"ui-shared-carousel__dot\" [class.ui-shared-carousel__dot--on]=\"i === current()\"\n                  [attr.aria-label]=\"('core.carousel.image' | uiTranslate) + ' ' + (i + 1)\" [attr.aria-pressed]=\"i === current()\"\n                  (click)=\"current.set(i)\"></button>\n        }\n      </div>\n    }\n  </div>\n</div>\n", styles: [":host{display:grid;box-sizing:border-box;min-width:0;max-width:100%}.ui-shared-carousel{position:relative;display:grid;overflow:hidden}.ui-shared-carousel__image,.ui-shared-carousel__veil{position:absolute;inset:0}.ui-shared-carousel__image{width:100%;height:100%;object-fit:cover}.ui-shared-carousel__content{position:relative;display:grid;align-content:end}.ui-shared-carousel__dots{display:flex;justify-content:center}.ui-shared-carousel__dot{padding:0;cursor:pointer}.ui-shared-carousel__arrow{position:absolute;top:50%;display:grid;place-items:center;padding:0;cursor:pointer;transform:translateY(-50%)}.ui-shared-carousel__arrow--prev{left:0}.ui-shared-carousel__arrow--next{right:0}\n"], dependencies: [{ kind: "pipe", type: UiTranslatePipe, name: "uiTranslate" }, { kind: "component", type: UiSharedIconComponent, selector: "ui-shared-icon", inputs: ["name", "size", "tone", "badge"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedCarouselComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ui-shared-carousel', standalone: true, imports: [UiTranslatePipe, UiSharedIconComponent], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div class=\"ui-shared-carousel\" [class.ui-shared-carousel--arrows]=\"images().length > 1\">\n  @for (src of images(); track src; let i = $index) {\n    <img class=\"ui-shared-carousel__image\" [class.ui-shared-carousel__image--on]=\"i === current()\" [src]=\"src\" alt=\"\"\n         [attr.loading]=\"i ? 'lazy' : null\" />\n  }\n  <div class=\"ui-shared-carousel__veil\"></div>\n  <div class=\"ui-shared-carousel__content\">\n    <ng-content />\n    @if (images().length > 1) {\n      <button type=\"button\" class=\"ui-shared-carousel__arrow ui-shared-carousel__arrow--prev\" [attr.aria-label]=\"'core.carousel.previous' | uiTranslate\" (click)=\"step(-1)\">\n        <ui-shared-icon name=\"chevron_left\" />\n      </button>\n      <button type=\"button\" class=\"ui-shared-carousel__arrow ui-shared-carousel__arrow--next\" [attr.aria-label]=\"'core.carousel.next' | uiTranslate\" (click)=\"step(1)\">\n        <ui-shared-icon name=\"chevron_right\" />\n      </button>\n      <div class=\"ui-shared-carousel__dots\">\n        @for (src of images(); track src; let i = $index) {\n          <button type=\"button\" class=\"ui-shared-carousel__dot\" [class.ui-shared-carousel__dot--on]=\"i === current()\"\n                  [attr.aria-label]=\"('core.carousel.image' | uiTranslate) + ' ' + (i + 1)\" [attr.aria-pressed]=\"i === current()\"\n                  (click)=\"current.set(i)\"></button>\n        }\n      </div>\n    }\n  </div>\n</div>\n", styles: [":host{display:grid;box-sizing:border-box;min-width:0;max-width:100%}.ui-shared-carousel{position:relative;display:grid;overflow:hidden}.ui-shared-carousel__image,.ui-shared-carousel__veil{position:absolute;inset:0}.ui-shared-carousel__image{width:100%;height:100%;object-fit:cover}.ui-shared-carousel__content{position:relative;display:grid;align-content:end}.ui-shared-carousel__dots{display:flex;justify-content:center}.ui-shared-carousel__dot{padding:0;cursor:pointer}.ui-shared-carousel__arrow{position:absolute;top:50%;display:grid;place-items:center;padding:0;cursor:pointer;transform:translateY(-50%)}.ui-shared-carousel__arrow--prev{left:0}.ui-shared-carousel__arrow--next{right:0}\n"] }]
        }], ctorParameters: () => [] });

/**
 * An image shown as it is (a logo, a brand mark, a preview): scaled to fit `height` x `maxWidth`
 * with its aspect ratio kept, no frame, padding or background of its own. `fullWidth` fills its
 * container's width instead, `height` then being the most it may grow. Without a `src`, or when it
 * fails to load, it shows `fallback` (or nothing).
 *
 *   <ui-shared-image [src]="logoUrl" [fallback]="company.name" [height]="32" />
 */
class UiSharedImageComponent {
    src = input(null);
    alt = input('');
    /** Text shown instead of a missing or broken image; empty shows nothing. */
    fallback = input(null);
    height = input(40);
    /** Defaults to four times the height. */
    maxWidth = input(null);
    /** Fill the container's width (aspect ratio kept, at most `height` tall). */
    fullWidth = input(false);
    /** Reset whenever the source changes, so a new image gets its own chance to load. */
    failed = linkedSignal({ source: this.src, computation: () => false });
    shown = computed(() => this.failed() ? null : this.src() || null);
    onError() {
        this.failed.set(true);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedImageComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: UiSharedImageComponent, isStandalone: true, selector: "ui-shared-image", inputs: { src: { classPropertyName: "src", publicName: "src", isSignal: true, isRequired: false, transformFunction: null }, alt: { classPropertyName: "alt", publicName: "alt", isSignal: true, isRequired: false, transformFunction: null }, fallback: { classPropertyName: "fallback", publicName: "fallback", isSignal: true, isRequired: false, transformFunction: null }, height: { classPropertyName: "height", publicName: "height", isSignal: true, isRequired: false, transformFunction: null }, maxWidth: { classPropertyName: "maxWidth", publicName: "maxWidth", isSignal: true, isRequired: false, transformFunction: null }, fullWidth: { classPropertyName: "fullWidth", publicName: "fullWidth", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class.ui-shared-image--full": "fullWidth()", "style.--ui-image-height.px": "height()", "style.--ui-image-max-width.px": "maxWidth() ?? height() * 4" }, classAttribute: "ui-shared-image" }, ngImport: i0, template: "@if (shown(); as url) {\n  <img class=\"ui-shared-image__img\" [src]=\"url\" [alt]=\"alt()\" (error)=\"onError()\" />\n} @else if (fallback()) {\n  <span class=\"ui-shared-image__fallback\">{{ fallback() }}</span>\n}\n", styles: [":host{display:inline-flex;box-sizing:border-box;min-width:0;max-width:100%}:host{align-items:center;flex-shrink:0}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedImageComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ui-shared-image', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, host: {
                        class: 'ui-shared-image',
                        '[class.ui-shared-image--full]': 'fullWidth()',
                        '[style.--ui-image-height.px]': 'height()',
                        '[style.--ui-image-max-width.px]': 'maxWidth() ?? height() * 4',
                    }, template: "@if (shown(); as url) {\n  <img class=\"ui-shared-image__img\" [src]=\"url\" [alt]=\"alt()\" (error)=\"onError()\" />\n} @else if (fallback()) {\n  <span class=\"ui-shared-image__fallback\">{{ fallback() }}</span>\n}\n", styles: [":host{display:inline-flex;box-sizing:border-box;min-width:0;max-width:100%}:host{align-items:center;flex-shrink:0}\n"] }]
        }] });

/**
 * The one explanation: an "i" icon with the text.
 *  - `iconOnly`: just the icon, the text as its hover tooltip - the form inputs put it at the end of the
 *    field (`matSuffix`) and the checkbox / toggle / radio group / segmented after their label;
 *  - otherwise the icon and the text on one line, cut with an ellipsis when it is longer than its box
 *    and shown whole on hover (`clamp`, the default for a lede); an error (`tone="danger"`) wraps instead.
 *
 *   <ui-shared-hint textKey="settings.logo.hint" />
 *   <ui-shared-hint iconOnly [text]="hint" />
 */
class UiSharedHintComponent {
    translate = inject(UI_TRANSLATE);
    textKey = input('');
    text = input('');
    tone = input('muted');
    iconOnly = input(false, { transform: booleanAttribute });
    /** One line with an ellipsis, the whole text on hover (off for an error, which must stay readable). */
    clamp = input(true, { transform: booleanAttribute });
    resolved = computed(() => this.textKey() ? this.translate(this.textKey()) : this.text());
    icon = computed(() => (this.tone() === 'muted' ? 'info' : 'error'));
    clamped = computed(() => this.clamp() && this.tone() === 'muted');
    hostClass = computed(() => `ui-shared-hint ui-shared-hint--${this.tone()}${this.iconOnly() ? ' ui-shared-hint--icon' : ''}${this.clamped() ? ' ui-shared-hint--clamp' : ''}`);
    /** Inside a checkbox / toggle label a click would flip the control: the icon is for reading only. */
    onClick(e) {
        if (this.iconOnly()) {
            e.preventDefault();
            e.stopPropagation();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedHintComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: UiSharedHintComponent, isStandalone: true, selector: "ui-shared-hint", inputs: { textKey: { classPropertyName: "textKey", publicName: "textKey", isSignal: true, isRequired: false, transformFunction: null }, text: { classPropertyName: "text", publicName: "text", isSignal: true, isRequired: false, transformFunction: null }, tone: { classPropertyName: "tone", publicName: "tone", isSignal: true, isRequired: false, transformFunction: null }, iconOnly: { classPropertyName: "iconOnly", publicName: "iconOnly", isSignal: true, isRequired: false, transformFunction: null }, clamp: { classPropertyName: "clamp", publicName: "clamp", isSignal: true, isRequired: false, transformFunction: null } }, host: { listeners: { "click": "onClick($event)" }, properties: { "class": "hostClass()", "attr.aria-label": "iconOnly() ? resolved() : null" } }, ngImport: i0, template: "@if (iconOnly()) {\n  <mat-icon class=\"ui-shared-hint__icon\" [matTooltip]=\"resolved()\" matTooltipPosition=\"above\">{{ icon() }}</mat-icon>\n} @else {\n  <mat-icon class=\"ui-shared-hint__icon\" aria-hidden=\"true\">{{ icon() }}</mat-icon>\n  <span class=\"ui-shared-hint__text\" [matTooltip]=\"clamped() ? resolved() : ''\" matTooltipPosition=\"above\"\n        [matTooltipDisabled]=\"!clamped()\">@if (textKey() || text()) { {{ resolved() }} } @else { <ng-content /> }</span>\n}\n", styles: [":host{display:inline-flex;box-sizing:border-box;min-width:0;max-width:100%}:host{align-items:flex-start}:host(.ui-shared-hint--icon){align-items:center;cursor:help}mat-icon{flex:none}.ui-shared-hint__text{min-width:0}:host(.ui-shared-hint--clamp) .ui-shared-hint__text{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}\n"], dependencies: [{ kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i1.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "directive", type: i2.MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedHintComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ui-shared-hint', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, imports: [MatIconModule, MatTooltipModule, UiTranslatePipe], host: {
                        '[class]': 'hostClass()',
                        '[attr.aria-label]': 'iconOnly() ? resolved() : null',
                        '(click)': 'onClick($event)',
                    }, template: "@if (iconOnly()) {\n  <mat-icon class=\"ui-shared-hint__icon\" [matTooltip]=\"resolved()\" matTooltipPosition=\"above\">{{ icon() }}</mat-icon>\n} @else {\n  <mat-icon class=\"ui-shared-hint__icon\" aria-hidden=\"true\">{{ icon() }}</mat-icon>\n  <span class=\"ui-shared-hint__text\" [matTooltip]=\"clamped() ? resolved() : ''\" matTooltipPosition=\"above\"\n        [matTooltipDisabled]=\"!clamped()\">@if (textKey() || text()) { {{ resolved() }} } @else { <ng-content /> }</span>\n}\n", styles: [":host{display:inline-flex;box-sizing:border-box;min-width:0;max-width:100%}:host{align-items:flex-start}:host(.ui-shared-hint--icon){align-items:center;cursor:help}mat-icon{flex:none}.ui-shared-hint__text{min-width:0}:host(.ui-shared-hint--clamp) .ui-shared-hint__text{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}\n"] }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { UiSharedAvatarComponent, UiSharedCarouselComponent, UiSharedDisplayDateComponent, UiSharedHintComponent, UiSharedIconComponent, UiSharedImageComponent, UiSharedInactiveValueComponent, UiSharedQrCodeComponent, UiSharedStatTileComponent, UiSharedStatusChipComponent, activeTone };
//# sourceMappingURL=borassoft-ui-components-display.mjs.map
