/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@borassoft/ui-components/display" />
export * from './public-api';
//# sourceMappingURL=borassoft-ui-components-display.d.ts.map