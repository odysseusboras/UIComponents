import { AbstractControl } from '@angular/forms';
/**
 * The translation key of the first error on a touched/dirty control, as
 * `form.errors.<validatorKey>` — the built-in validators and any custom one
 * (`{ greekAfm: true }` → `form.errors.greekAfm`). Pair with `uiTranslate`
 * (or the host's own pipe): `@if (firstError(ctrl); as key) { <mat-error>{{ key | uiTranslate }}</mat-error> }`
 */
export declare function firstError(control: AbstractControl | null): string | null;
//# sourceMappingURL=first-error.d.ts.map