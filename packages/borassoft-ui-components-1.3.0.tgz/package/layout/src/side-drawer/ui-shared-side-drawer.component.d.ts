import { OnDestroy, OnInit } from '@angular/core';
import * as i0 from "@angular/core";
/**
 * Generic slide-in side drawer — the replacement for edit/detail popup dialogs.
 * Distinct from <ui-shared-side-panel>, which is the collapsible LEFT shell nav.
 * Project the body as default content and the footer buttons into
 * <code>[slot=actions]</code> (right-aligned). Controlled by the parent via
 * <code>[open]</code> + <code>(close)</code>; closes on backdrop click or Escape.
 *
 * The host element is re-parented to <body> on init so its fixed-position overlay
 * is viewport-relative — otherwise a transformed/stacking-context ancestor (the
 * Material sidenav content) traps it BELOW the sticky app header and hides the
 * drawer's own header. Keep this; removing it re-introduces that bug everywhere.
 *
 * Typical use from a grid's row-click (`<ui-shared-grid (rowClick)>`):
 *
 *   <ui-shared-side-drawer [open]="!!editing()" titleKey="admin.companies.edit"
 *                   (close)="editing.set(null)">
 *     <!-- per-case edit form here -->
 *     <button slot="actions" mat-stroked-button (click)="editing.set(null)">{{ 'common.cancel' | uiTranslate }}</button>
 *     <button slot="actions" mat-flat-button color="primary" (click)="save()">{{ 'common.save' | uiTranslate }}</button>
 *   </ui-shared-side-drawer>
 */
export declare class UiSharedSideDrawerComponent implements OnInit, OnDestroy {
    open: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    titleKey: import("@angular/core").InputSignal<string>;
    /** Explicit drawer width on wide screens (overrides `size`); goes full-width on narrow ones via CSS. */
    width: import("@angular/core").InputSignal<string | null>;
    /** md = standard edit form (default); lg = wide forms / multi-column detail. */
    size: import("@angular/core").InputSignal<"md" | "lg">;
    protected widthVar: import("@angular/core").Signal<string>;
    close: import("@angular/core").OutputEmitterRef<void>;
    private host;
    ngOnInit(): void;
    ngOnDestroy(): void;
    /** An overlay opened from inside the drawer (menu, select, dialog) that handled Escape itself keeps the drawer open. */
    protected onEscape(event: KeyboardEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<UiSharedSideDrawerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UiSharedSideDrawerComponent, "ui-shared-side-drawer", never, { "open": { "alias": "open"; "required": false; "isSignal": true; }; "titleKey": { "alias": "titleKey"; "required": false; "isSignal": true; }; "width": { "alias": "width"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; }, { "close": "close"; }, never, ["*", "[slot=actions]"], true, never>;
}
//# sourceMappingURL=ui-shared-side-drawer.component.d.ts.map