/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@borassoft/ui-components" />
export * from './public-api';
//# sourceMappingURL=borassoft-ui-components.d.ts.map