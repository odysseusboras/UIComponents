import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { PageQuery, PageResult } from './odata-source';
export interface OdataFetchOptions {
    /** Built-in scope filter (e.g. CompanyId eq X). ANDed with query.filter. */
    filter?: string;
    /** $expand clause. */
    expand?: string;
    /** Fallback sort field if PageQuery.sortField is not set. */
    defaultSort?: string;
}
/**
 * Fetch one page of OData rows and map them to view-model T. Every service
 * backing a grid goes through this helper, so $top/$skip/$count/$orderby/
 * $filter/$expand and OData envelope unwrapping live in exactly one place.
 * Filters compose: `opts.filter` (service scope) AND `query.filter` (grid filters).
 */
export declare function fetchOdataPage<TRaw, T>(http: HttpClient, baseUrl: string, query: PageQuery, opts: OdataFetchOptions, toView: (raw: TRaw) => T): Observable<PageResult<T>>;
//# sourceMappingURL=odata-fetch.d.ts.map