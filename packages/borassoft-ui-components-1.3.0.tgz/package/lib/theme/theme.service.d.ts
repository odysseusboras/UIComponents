import { InjectionToken } from '@angular/core';
import * as i0 from "@angular/core";
export type UiTheme = 'light' | 'dark';
/** localStorage key the theme is remembered under. Override to keep an existing key. */
export declare const UI_THEME_STORAGE_KEY: InjectionToken<string>;
/**
 * Light / dark theme state. Mirrors the active theme to
 * `<html data-theme="light|dark">` (the host's stylesheet keys its dark tokens
 * off that attribute) and persists it; the first value comes from storage,
 * then from `prefers-color-scheme`.
 */
export declare class UiThemeService {
    private key;
    private _theme;
    theme: import("@angular/core").Signal<UiTheme>;
    isDark: () => boolean;
    constructor();
    toggle(): void;
    set(theme: UiTheme): void;
    private initial;
    static ɵfac: i0.ɵɵFactoryDeclaration<UiThemeService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UiThemeService>;
}
//# sourceMappingURL=theme.service.d.ts.map