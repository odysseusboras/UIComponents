/**
 * localStorage that never throws (private mode, quota, no storage): reads fall
 * back to null, writes are best-effort. Every persisted UI preference goes through it.
 */
export declare const uiStorage: {
    get(key: string): string | null;
    set(key: string, value: string): void;
    remove(key: string): void;
    /** Parsed JSON, or null when missing or corrupt. */
    getJson(key: string): unknown;
    setJson(key: string, value: unknown): void;
};
/** The choice remembered under `key`, or null when missing or no longer one of `allowed`. */
export declare function storedChoice<T>(key: string, allowed: readonly T[]): T | null;
export declare function storeChoice(key: string, value: unknown): void;
//# sourceMappingURL=storage.d.ts.map