import * as i0 from "@angular/core";
/**
 * An image shown as it is (a logo, a brand mark, a preview): scaled to fit `height` x `maxWidth`
 * with its aspect ratio kept, no frame, padding or background of its own. `fullWidth` fills its
 * container's width instead, `height` then being the most it may grow. Without a `src`, or when it
 * fails to load, it shows `fallback` (or nothing).
 *
 *   <ui-shared-image [src]="logoUrl" [fallback]="company.name" [height]="32" />
 */
export declare class UiSharedImageComponent {
    src: import("@angular/core").InputSignal<string | null | undefined>;
    alt: import("@angular/core").InputSignal<string>;
    /** Text shown instead of a missing or broken image; empty shows nothing. */
    fallback: import("@angular/core").InputSignal<string | null | undefined>;
    height: import("@angular/core").InputSignal<number>;
    /** Defaults to four times the height. */
    maxWidth: import("@angular/core").InputSignal<number | null>;
    /** Fill the container's width (aspect ratio kept, at most `height` tall). */
    fullWidth: import("@angular/core").InputSignal<boolean>;
    /** Reset whenever the source changes, so a new image gets its own chance to load. */
    private failed;
    protected shown: import("@angular/core").Signal<string | null>;
    protected onError(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<UiSharedImageComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UiSharedImageComponent, "ui-shared-image", never, { "src": { "alias": "src"; "required": false; "isSignal": true; }; "alt": { "alias": "alt"; "required": false; "isSignal": true; }; "fallback": { "alias": "fallback"; "required": false; "isSignal": true; }; "height": { "alias": "height"; "required": false; "isSignal": true; }; "maxWidth": { "alias": "maxWidth"; "required": false; "isSignal": true; }; "fullWidth": { "alias": "fullWidth"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=ui-shared-image.component.d.ts.map