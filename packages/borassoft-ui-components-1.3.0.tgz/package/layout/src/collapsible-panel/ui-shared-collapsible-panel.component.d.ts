import * as i0 from "@angular/core";
/**
 * A card panel whose body can be collapsed to its header. The state is
 * remembered per `storageKey` in localStorage (`ui.collapsible.<storageKey>`),
 * so a user who hides a stats block keeps it hidden across visits.
 *
 *   <ui-shared-collapsible-panel titleKey="stats.title" storageKey="stats">…</ui-shared-collapsible-panel>
 */
export declare class UiSharedCollapsiblePanelComponent {
    titleKey: import("@angular/core").InputSignal<string>;
    ledeKey: import("@angular/core").InputSignal<string>;
    storageKey: import("@angular/core").InputSignal<string>;
    private toggled;
    protected collapsed: import("@angular/core").Signal<boolean>;
    protected toggle(): void;
    private key;
    private read;
    static ɵfac: i0.ɵɵFactoryDeclaration<UiSharedCollapsiblePanelComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UiSharedCollapsiblePanelComponent, "ui-shared-collapsible-panel", never, { "titleKey": { "alias": "titleKey"; "required": true; "isSignal": true; }; "ledeKey": { "alias": "ledeKey"; "required": false; "isSignal": true; }; "storageKey": { "alias": "storageKey"; "required": true; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}
//# sourceMappingURL=ui-shared-collapsible-panel.component.d.ts.map