import * as i0 from "@angular/core";
/**
 * Window scroll position as signals. `pastHeader` is true once the app header (`--header-h`,
 * 56px when unset) has scrolled out of view, so a shell can show the brand in its side-panel
 * head instead of the header (ATLAS / EINV shells).
 */
export declare class UiScrollService {
    readonly y: import("@angular/core").WritableSignal<number>;
    readonly pastHeader: import("@angular/core").WritableSignal<boolean>;
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<UiScrollService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UiScrollService>;
}
//# sourceMappingURL=scroll.service.d.ts.map