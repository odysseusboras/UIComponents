import { FormControl } from '@angular/forms';
import * as i0 from "@angular/core";
/**
 * The one checkbox. Two modes:
 *  - form mode: `[control]` is a boolean FormControl;
 *  - selection mode (no control): `[checked]` / `[disabled]` in, `(changed)` out —
 *    for table row / select-all toggles that live in component state, not a form.
 * Label is a translation key or projected content.
 */
export declare class UiSharedCheckboxComponent {
    control: import("@angular/core").InputSignal<FormControl<boolean> | null>;
    labelKey: import("@angular/core").InputSignal<string>;
    /** A sentence of help under the control. */
    hintKey: import("@angular/core").InputSignal<string>;
    ariaLabelKey: import("@angular/core").InputSignal<string>;
    /** Hover hint on the whole checkbox. */
    tooltipKey: import("@angular/core").InputSignal<string>;
    checked: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    indeterminate: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    disabled: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    changed: import("@angular/core").OutputEmitterRef<boolean>;
    private own;
    protected required: import("@angular/core").Signal<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UiSharedCheckboxComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UiSharedCheckboxComponent, "ui-shared-checkbox", never, { "control": { "alias": "control"; "required": false; "isSignal": true; }; "labelKey": { "alias": "labelKey"; "required": false; "isSignal": true; }; "hintKey": { "alias": "hintKey"; "required": false; "isSignal": true; }; "ariaLabelKey": { "alias": "ariaLabelKey"; "required": false; "isSignal": true; }; "tooltipKey": { "alias": "tooltipKey"; "required": false; "isSignal": true; }; "checked": { "alias": "checked"; "required": false; "isSignal": true; }; "indeterminate": { "alias": "indeterminate"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, { "changed": "changed"; }, never, ["*"], true, never>;
}
//# sourceMappingURL=ui-shared-checkbox.component.d.ts.map