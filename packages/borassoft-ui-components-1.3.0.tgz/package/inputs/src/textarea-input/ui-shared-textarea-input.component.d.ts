import { FormControl } from '@angular/forms';
import { SubscriptSizing } from '@angular/material/form-field';
import { firstError } from '@borassoft/ui-components';
import * as i0 from "@angular/core";
/** The one multi-line input. Same contract as ui-shared-text-input, plus `rows`. */
export declare class UiSharedTextareaInputComponent {
    control: import("@angular/core").InputSignal<FormControl<any>>;
    labelKey: import("@angular/core").InputSignal<string>;
    rows: import("@angular/core").InputSignalWithTransform<number, unknown>;
    hintKey: import("@angular/core").InputSignal<string>;
    hintText: import("@angular/core").InputSignal<string>;
    maxlength: import("@angular/core").InputSignal<string | number | null>;
    readonly: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    subscriptSizing: import("@angular/core").InputSignal<SubscriptSizing>;
    protected readonly firstError: typeof firstError;
    protected required: import("@angular/core").Signal<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UiSharedTextareaInputComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UiSharedTextareaInputComponent, "ui-shared-textarea-input", never, { "control": { "alias": "control"; "required": true; "isSignal": true; }; "labelKey": { "alias": "labelKey"; "required": true; "isSignal": true; }; "rows": { "alias": "rows"; "required": false; "isSignal": true; }; "hintKey": { "alias": "hintKey"; "required": false; "isSignal": true; }; "hintText": { "alias": "hintText"; "required": false; "isSignal": true; }; "maxlength": { "alias": "maxlength"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "subscriptSizing": { "alias": "subscriptSizing"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=ui-shared-textarea-input.component.d.ts.map