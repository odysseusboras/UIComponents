import { MatSnackBarConfig } from '@angular/material/snack-bar';
import * as i0 from "@angular/core";
/**
 * Single entry point for transient user feedback. Wraps {@link MatSnackBar}
 * so callers don't need to know about durations, panel classes or positioning.
 *
 * Defaults (all top-center): success / info 3s, warn 5s, error 6s.
 *
 * Snackbar panels render in the CDK overlay, outside any component scope, so
 * their colours come from the global theme (`ui-shared-toast--success|info|warn|error`).
 */
export declare class UiNotificationService {
    private snack;
    private translate;
    success(message: string, opts?: Partial<MatSnackBarConfig>): void;
    info(message: string, opts?: Partial<MatSnackBarConfig>): void;
    warn(message: string, opts?: Partial<MatSnackBarConfig>): void;
    error(message: string, opts?: Partial<MatSnackBarConfig>): void;
    private show;
    static ɵfac: i0.ɵɵFactoryDeclaration<UiNotificationService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UiNotificationService>;
}
//# sourceMappingURL=notification.service.d.ts.map