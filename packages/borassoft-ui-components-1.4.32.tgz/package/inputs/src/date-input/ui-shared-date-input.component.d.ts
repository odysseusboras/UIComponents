import { FormControl } from '@angular/forms';
import { SubscriptSizing } from '@angular/material/form-field';
import { ClauseBuilder, GridFilterState, firstError } from '@borassoft/ui-components';
import * as i0 from "@angular/core";
/**
 * The one date picker. Day-first typing/display comes from `provideUiDates()` in the app config.
 *
 * Inside `<ui-shared-grid>` with `[clauseBuilder]` it is a grid filter; the builder gets the picked day as an
 * OData date literal (`2026-10-06`):
 *
 *   <ui-shared-date-input labelKey="orders.from" [clauseBuilder]="from" />     from = (d: string) => `OrderDate ge ${d}`
 */
export declare class UiSharedDateInputComponent {
    /** Optional when used as a grid filter. */
    control: import("@angular/core").InputSignal<FormControl<any> | null>;
    labelKey: import("@angular/core").InputSignal<string>;
    hintKey: import("@angular/core").InputSignal<string>;
    hintText: import("@angular/core").InputSignal<string>;
    min: import("@angular/core").InputSignal<Date | null>;
    max: import("@angular/core").InputSignal<Date | null>;
    subscriptSizing: import("@angular/core").InputSignal<SubscriptSizing>;
    /** Grid filter: clause for the picked day, given as `YYYY-MM-DD`. */
    clauseBuilder: import("@angular/core").InputSignal<ClauseBuilder<string> | null>;
    private own;
    protected ctrl: import("@angular/core").Signal<FormControl<any>>;
    readonly filter: GridFilterState<string | Date>;
    protected readonly firstError: typeof firstError;
    protected required: import("@angular/core").Signal<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UiSharedDateInputComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UiSharedDateInputComponent, "ui-shared-date-input", never, { "control": { "alias": "control"; "required": false; "isSignal": true; }; "labelKey": { "alias": "labelKey"; "required": true; "isSignal": true; }; "hintKey": { "alias": "hintKey"; "required": false; "isSignal": true; }; "hintText": { "alias": "hintText"; "required": false; "isSignal": true; }; "min": { "alias": "min"; "required": false; "isSignal": true; }; "max": { "alias": "max"; "required": false; "isSignal": true; }; "subscriptSizing": { "alias": "subscriptSizing"; "required": false; "isSignal": true; }; "clauseBuilder": { "alias": "clauseBuilder"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=ui-shared-date-input.component.d.ts.map