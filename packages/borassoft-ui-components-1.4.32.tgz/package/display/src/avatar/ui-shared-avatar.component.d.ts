import * as i0 from "@angular/core";
/** Initials disc for a person: `<ui-shared-avatar [name]="user.name" />`. Up to two initials, from the first two words. */
export declare class UiSharedAvatarComponent {
    name: import("@angular/core").InputSignal<string>;
    size: import("@angular/core").InputSignal<"lg" | "md">;
    initials: import("@angular/core").Signal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UiSharedAvatarComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UiSharedAvatarComponent, "ui-shared-avatar", never, { "name": { "alias": "name"; "required": true; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=ui-shared-avatar.component.d.ts.map