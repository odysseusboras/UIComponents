import * as i0 from "@angular/core";
/**
 * Image carousel: the images crossfade one after the other; arrows and a dot per image pick one by hand.
 * Projected content sits on top of the images (a hero's title and buttons) and the host styles
 * any veil it wants between the two through `--ui-carousel-veil`.
 *
 *   <ui-shared-carousel [images]="['/images/home-1.jpg', '/images/home-2.jpg']" [interval]="7000">
 *     <h1>…</h1>
 *   </ui-shared-carousel>
 */
export declare class UiSharedCarouselComponent {
    images: import("@angular/core").InputSignal<string[]>;
    /** Milliseconds between two images; 0 = no auto-play. */
    interval: import("@angular/core").InputSignal<number>;
    readonly current: import("@angular/core").WritableSignal<number>;
    step(by: number): void;
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<UiSharedCarouselComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UiSharedCarouselComponent, "ui-shared-carousel", never, { "images": { "alias": "images"; "required": true; "isSignal": true; }; "interval": { "alias": "interval"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}
//# sourceMappingURL=ui-shared-carousel.component.d.ts.map