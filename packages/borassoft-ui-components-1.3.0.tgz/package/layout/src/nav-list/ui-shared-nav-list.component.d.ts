import * as i0 from "@angular/core";
/** Vertical shell navigation: a column of <ui-shared-nav-item> and <ui-shared-nav-group> labels. */
export declare class UiSharedNavListComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<UiSharedNavListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UiSharedNavListComponent, "ui-shared-nav-list", never, {}, {}, never, ["*"], true, never>;
}
//# sourceMappingURL=ui-shared-nav-list.component.d.ts.map