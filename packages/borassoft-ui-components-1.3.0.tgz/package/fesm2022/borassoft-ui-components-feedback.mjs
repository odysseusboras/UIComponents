import * as i0 from '@angular/core';
import { inject, Component, Injectable, signal, input, numberAttribute, ChangeDetectionStrategy } from '@angular/core';
import * as i1 from '@angular/material/dialog';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialogModule, MatDialog } from '@angular/material/dialog';
import * as i2 from '@angular/material/button';
import { MatButtonModule } from '@angular/material/button';
import * as i3 from '@angular/material/icon';
import { MatIconModule } from '@angular/material/icon';
import { UiTranslatePipe, UI_TRANSLATE } from '@borassoft/ui-components';
import { filter } from 'rxjs';
import { MatSnackBar } from '@angular/material/snack-bar';
import * as i1$1 from '@angular/material/progress-spinner';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import * as i1$2 from '@angular/material/progress-bar';
import { MatProgressBarModule } from '@angular/material/progress-bar';

/**
 * Generic Yes / No dialog. Never open it directly — go through
 * `UiConfirmService.confirm(data)` so every confirmation looks and behaves
 * identically.
 */
class UiSharedConfirmDialogComponent {
    ref = inject(MatDialogRef);
    data = inject(MAT_DIALOG_DATA);
    get confirmKey() { return this.data.confirmKey ?? 'common.yes'; }
    get cancelKey() { return this.data.cancelKey ?? 'common.no'; }
    get variant() { return this.data.variant ?? 'warn'; }
    confirm() { this.ref.close(true); }
    cancel() { this.ref.close(false); }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedConfirmDialogComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: UiSharedConfirmDialogComponent, isStandalone: true, selector: "ui-shared-confirm-dialog", ngImport: i0, template: "<div class=\"ui-shared-confirm-dialog__icon\" [class.ui-shared-confirm-dialog__icon--warn]=\"variant === 'warn'\" [class.ui-shared-confirm-dialog__icon--primary]=\"variant === 'primary'\" aria-hidden=\"true\">\n  <mat-icon>{{ variant === 'warn' ? 'warning' : 'help_outline' }}</mat-icon>\n</div>\n\n<h2 mat-dialog-title>\n  @if (data.titleKey) { {{ data.titleKey | uiTranslate }} }\n  @else                { {{ data.titleText }} }\n</h2>\n\n<mat-dialog-content>\n  <p class=\"ui-shared-confirm-dialog__message\">\n    @if (data.messageKey) { {{ data.messageKey | uiTranslate }} }\n    @else                  { {{ data.messageText }} }\n  </p>\n</mat-dialog-content>\n\n<mat-dialog-actions align=\"end\">\n  <button mat-stroked-button type=\"button\" (click)=\"cancel()\">\n    {{ cancelKey | uiTranslate }}\n  </button>\n  <button mat-flat-button type=\"button\"\n          color=\"primary\"\n          (click)=\"confirm()\">\n    {{ confirmKey | uiTranslate }}\n  </button>\n</mat-dialog-actions>\n", styles: [":host{display:block;box-sizing:border-box;min-width:0;max-width:100%}.ui-shared-confirm-dialog__icon{display:inline-flex;align-items:center;justify-content:center}mat-dialog-content{overflow-x:hidden}.ui-shared-confirm-dialog__message{overflow-wrap:anywhere;white-space:pre-line}\n"], dependencies: [{ kind: "ngmodule", type: MatDialogModule }, { kind: "directive", type: i1.MatDialogTitle, selector: "[mat-dialog-title], [matDialogTitle]", inputs: ["id"], exportAs: ["matDialogTitle"] }, { kind: "directive", type: i1.MatDialogActions, selector: "[mat-dialog-actions], mat-dialog-actions, [matDialogActions]", inputs: ["align"] }, { kind: "directive", type: i1.MatDialogContent, selector: "[mat-dialog-content], mat-dialog-content, [matDialogContent]" }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i2.MatButton, selector: "    button[mat-button], button[mat-raised-button], button[mat-flat-button],    button[mat-stroked-button]  ", exportAs: ["matButton"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i3.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "pipe", type: UiTranslatePipe, name: "uiTranslate" }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedConfirmDialogComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ui-shared-confirm-dialog', standalone: true, imports: [MatDialogModule, MatButtonModule, MatIconModule, UiTranslatePipe], template: "<div class=\"ui-shared-confirm-dialog__icon\" [class.ui-shared-confirm-dialog__icon--warn]=\"variant === 'warn'\" [class.ui-shared-confirm-dialog__icon--primary]=\"variant === 'primary'\" aria-hidden=\"true\">\n  <mat-icon>{{ variant === 'warn' ? 'warning' : 'help_outline' }}</mat-icon>\n</div>\n\n<h2 mat-dialog-title>\n  @if (data.titleKey) { {{ data.titleKey | uiTranslate }} }\n  @else                { {{ data.titleText }} }\n</h2>\n\n<mat-dialog-content>\n  <p class=\"ui-shared-confirm-dialog__message\">\n    @if (data.messageKey) { {{ data.messageKey | uiTranslate }} }\n    @else                  { {{ data.messageText }} }\n  </p>\n</mat-dialog-content>\n\n<mat-dialog-actions align=\"end\">\n  <button mat-stroked-button type=\"button\" (click)=\"cancel()\">\n    {{ cancelKey | uiTranslate }}\n  </button>\n  <button mat-flat-button type=\"button\"\n          color=\"primary\"\n          (click)=\"confirm()\">\n    {{ confirmKey | uiTranslate }}\n  </button>\n</mat-dialog-actions>\n", styles: [":host{display:block;box-sizing:border-box;min-width:0;max-width:100%}.ui-shared-confirm-dialog__icon{display:inline-flex;align-items:center;justify-content:center}mat-dialog-content{overflow-x:hidden}.ui-shared-confirm-dialog__message{overflow-wrap:anywhere;white-space:pre-line}\n"] }]
        }] });

/**
 * The ONE way to ask the user "Yes / No" before an action. Every confirmation
 * opens the same dialog with the same size and focus behaviour; the returned
 * stream emits only on explicit confirm, so callers subscribe to the "yes"
 * branch and never check the result.
 */
class UiConfirmService {
    dialog = inject(MatDialog);
    confirm(data) {
        return this.dialog
            .open(UiSharedConfirmDialogComponent, {
            data,
            width: '440px',
            maxWidth: '92vw',
            autoFocus: 'dialog',
            restoreFocus: true,
        })
            .afterClosed()
            .pipe(filter((ok) => ok === true));
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiConfirmService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiConfirmService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiConfirmService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

/**
 * Tracks in-flight work for `<ui-shared-loading-overlay>`. The host calls
 * start()/stop() around every request (e.g. from an HTTP interceptor); the
 * overlay reads `visible`.
 *
 * `visible` is debounced: it only turns on if work stays pending past a short
 * grace period (so fast calls don't flash the overlay), and turns off the
 * moment the last call settles.
 */
class UiLoadingService {
    active = 0;
    timer = null;
    static GRACE_MS = 250;
    /** True while a request has been pending longer than the grace period. */
    visible = signal(false);
    start() {
        this.active++;
        if (this.active === 1 && this.timer === null) {
            this.timer = setTimeout(() => {
                this.timer = null;
                if (this.active > 0)
                    this.visible.set(true);
            }, UiLoadingService.GRACE_MS);
        }
    }
    stop() {
        this.active = Math.max(0, this.active - 1);
        if (this.active === 0) {
            if (this.timer !== null) {
                clearTimeout(this.timer);
                this.timer = null;
            }
            this.visible.set(false);
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiLoadingService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiLoadingService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiLoadingService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

/**
 * App-wide loading overlay shown while `UiLoadingService` reports pending work.
 * A slim progress bar slides across the top and a small floating card holds an
 * animated ring; pointer input is blocked so the user can't fire conflicting
 * actions until the request settles. Mount it once, in the root component.
 */
class UiSharedLoadingOverlayComponent {
    loading = inject(UiLoadingService);
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedLoadingOverlayComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: UiSharedLoadingOverlayComponent, isStandalone: true, selector: "ui-shared-loading-overlay", ngImport: i0, template: "@if (loading.visible()) {\n  <div class=\"ui-shared-loading-overlay\" role=\"status\" aria-busy=\"true\" aria-live=\"polite\">\n    <div class=\"ui-shared-loading-overlay__bar\" aria-hidden=\"true\"></div>\n    <div class=\"ui-shared-loading-overlay__card\">\n      <span class=\"ui-shared-loading-overlay__ring\" aria-hidden=\"true\"></span>\n      <span class=\"ui-shared-loading-overlay__label\">{{ 'common.loading' | uiTranslate }}</span>\n    </div>\n  </div>\n}\n", styles: [":host{display:contents;box-sizing:border-box;min-width:0;max-width:100%}.ui-shared-loading-overlay{position:fixed;inset:0;z-index:var(--ui-z-overlay, 2000);display:grid;place-items:center;cursor:progress}.ui-shared-loading-overlay__bar{position:fixed;top:0;left:0;right:0;overflow:hidden}.ui-shared-loading-overlay__bar:before{content:\"\";position:absolute;top:0;bottom:0;left:0}.ui-shared-loading-overlay__card{display:flex;flex-direction:column;align-items:center}\n"], dependencies: [{ kind: "pipe", type: UiTranslatePipe, name: "uiTranslate" }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedLoadingOverlayComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ui-shared-loading-overlay', standalone: true, imports: [UiTranslatePipe], template: "@if (loading.visible()) {\n  <div class=\"ui-shared-loading-overlay\" role=\"status\" aria-busy=\"true\" aria-live=\"polite\">\n    <div class=\"ui-shared-loading-overlay__bar\" aria-hidden=\"true\"></div>\n    <div class=\"ui-shared-loading-overlay__card\">\n      <span class=\"ui-shared-loading-overlay__ring\" aria-hidden=\"true\"></span>\n      <span class=\"ui-shared-loading-overlay__label\">{{ 'common.loading' | uiTranslate }}</span>\n    </div>\n  </div>\n}\n", styles: [":host{display:contents;box-sizing:border-box;min-width:0;max-width:100%}.ui-shared-loading-overlay{position:fixed;inset:0;z-index:var(--ui-z-overlay, 2000);display:grid;place-items:center;cursor:progress}.ui-shared-loading-overlay__bar{position:fixed;top:0;left:0;right:0;overflow:hidden}.ui-shared-loading-overlay__bar:before{content:\"\";position:absolute;top:0;bottom:0;left:0}.ui-shared-loading-overlay__card{display:flex;flex-direction:column;align-items:center}\n"] }]
        }] });

/**
 * Single entry point for transient user feedback. Wraps {@link MatSnackBar}
 * so callers don't need to know about durations, panel classes or positioning.
 *
 * Defaults (all top-center): success / info 3s, warn 5s, error 6s.
 *
 * Snackbar panels render in the CDK overlay, outside any component scope, so
 * their colours come from the global theme (`ui-shared-toast--success|info|warn|error`).
 */
class UiNotificationService {
    snack = inject(MatSnackBar);
    translate = inject(UI_TRANSLATE);
    success(message, opts) {
        this.show(message, { duration: 3000, panelClass: ['ui-shared-toast', 'ui-shared-toast--success'], ...opts });
    }
    info(message, opts) {
        this.show(message, { duration: 3000, panelClass: ['ui-shared-toast', 'ui-shared-toast--info'], ...opts });
    }
    warn(message, opts) {
        this.show(message, { duration: 5000, panelClass: ['ui-shared-toast', 'ui-shared-toast--warn'], ...opts });
    }
    error(message, opts) {
        this.show(message, { duration: 6000, panelClass: ['ui-shared-toast', 'ui-shared-toast--error'], ...opts });
    }
    show(message, config) {
        this.snack.open(message, this.translate('common.ok'), {
            horizontalPosition: 'center',
            verticalPosition: 'top',
            ...config,
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiNotificationService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiNotificationService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiNotificationService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

/** Indeterminate spinner for inline loading states; `size` in px (default 24). */
class UiSharedSpinnerComponent {
    size = input(24, { transform: numberAttribute });
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedSpinnerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "19.2.25", type: UiSharedSpinnerComponent, isStandalone: true, selector: "ui-shared-spinner", inputs: { size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: "<mat-progress-spinner mode=\"indeterminate\" [diameter]=\"size()\" />\n", styles: [":host{display:inline-flex;box-sizing:border-box;min-width:0;max-width:100%}:host{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: MatProgressSpinnerModule }, { kind: "component", type: i1$1.MatProgressSpinner, selector: "mat-progress-spinner, mat-spinner", inputs: ["color", "mode", "value", "diameter", "strokeWidth"], exportAs: ["matProgressSpinner"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedSpinnerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ui-shared-spinner', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, imports: [MatProgressSpinnerModule], template: "<mat-progress-spinner mode=\"indeterminate\" [diameter]=\"size()\" />\n", styles: [":host{display:inline-flex;box-sizing:border-box;min-width:0;max-width:100%}:host{vertical-align:middle}\n"] }]
        }] });

/** Thin loading bar: indeterminate by default, determinate when `value` (0-100) is set. */
class UiSharedProgressBarComponent {
    value = input(null, { transform: v => (v == null || v === '' ? null : numberAttribute(v)) });
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedProgressBarComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "19.2.25", type: UiSharedProgressBarComponent, isStandalone: true, selector: "ui-shared-progress-bar", inputs: { value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: "<mat-progress-bar [mode]=\"value() == null ? 'indeterminate' : 'determinate'\" [value]=\"value() ?? 0\" />\n", styles: [":host{display:block;box-sizing:border-box;min-width:0;max-width:100%}mat-progress-bar{display:block}\n"], dependencies: [{ kind: "ngmodule", type: MatProgressBarModule }, { kind: "component", type: i1$2.MatProgressBar, selector: "mat-progress-bar", inputs: ["color", "value", "bufferValue", "mode"], outputs: ["animationEnd"], exportAs: ["matProgressBar"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedProgressBarComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ui-shared-progress-bar', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, imports: [MatProgressBarModule], template: "<mat-progress-bar [mode]=\"value() == null ? 'indeterminate' : 'determinate'\" [value]=\"value() ?? 0\" />\n", styles: [":host{display:block;box-sizing:border-box;min-width:0;max-width:100%}mat-progress-bar{display:block}\n"] }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { UiConfirmService, UiLoadingService, UiNotificationService, UiSharedConfirmDialogComponent, UiSharedLoadingOverlayComponent, UiSharedProgressBarComponent, UiSharedSpinnerComponent };
//# sourceMappingURL=borassoft-ui-components-feedback.mjs.map
