import * as i0 from "@angular/core";
export type UiIconButtonTone = 'default' | 'danger' | 'accent' | 'warning';
/**
 * Square icon-only button; `tooltipKey` doubles as the accessible name.
 * `size="sm"` (32px) is the inline row action (remove line, open row);
 * `size="md"` (40px) the toolbar one. `tone="danger"` turns red on hover,
 * `tone="accent"` is always accent (favourite on).
 *
 *   <ui-shared-icon-button icon="delete" tone="danger" tooltipKey="common.delete" (click)="remove(i)" />
 *   <ui-shared-icon-button slot="trigger" icon="more_vert" tooltipKey="core.grid.rowActions" />  (inside <ui-shared-menu>)
 */
export declare class UiSharedIconButtonComponent {
    icon: import("@angular/core").InputSignal<string>;
    tooltipKey: import("@angular/core").InputSignal<string>;
    tone: import("@angular/core").InputSignal<UiIconButtonTone>;
    size: import("@angular/core").InputSignal<"sm" | "md">;
    type: import("@angular/core").InputSignal<"button" | "submit">;
    disabled: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    /** Count bubble on the icon (notifications); hidden when null / 0. */
    badge: import("@angular/core").InputSignal<string | number | null | undefined>;
    protected get classes(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<UiSharedIconButtonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UiSharedIconButtonComponent, "ui-shared-icon-button", never, { "icon": { "alias": "icon"; "required": true; "isSignal": true; }; "tooltipKey": { "alias": "tooltipKey"; "required": true; "isSignal": true; }; "tone": { "alias": "tone"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "type": { "alias": "type"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "badge": { "alias": "badge"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=ui-shared-icon-button.component.d.ts.map