import * as i0 from '@angular/core';
import { input, booleanAttribute, ChangeDetectionStrategy, Component, output, viewChild } from '@angular/core';
import { NgTemplateOutlet } from '@angular/common';
import { RouterLink } from '@angular/router';
import * as i1 from '@angular/material/tooltip';
import { MatTooltipModule } from '@angular/material/tooltip';
import { UiTranslatePipe } from '@borassoft/ui-components';
import { UiSharedIconComponent } from '@borassoft/ui-components/display';
import { UiSharedSpinnerComponent } from '@borassoft/ui-components/feedback';
import * as i1$1 from '@angular/material/menu';
import { MatMenuModule, MatMenu } from '@angular/material/menu';

/**
 * The inside of every clickable row: leading icon (or spinner while loading),
 * label, trailing icon. Shared by button, menu item and nav item so they line
 * up identically. With no `labelKey` / `label` the projected content is the label.
 */
class UiSharedButtonContentComponent {
    icon = input('');
    iconEnd = input('');
    labelKey = input('');
    label = input('');
    loading = input(false, { transform: booleanAttribute });
    loadingKey = input('');
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedButtonContentComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: UiSharedButtonContentComponent, isStandalone: true, selector: "ui-shared-button-content", inputs: { icon: { classPropertyName: "icon", publicName: "icon", isSignal: true, isRequired: false, transformFunction: null }, iconEnd: { classPropertyName: "iconEnd", publicName: "iconEnd", isSignal: true, isRequired: false, transformFunction: null }, labelKey: { classPropertyName: "labelKey", publicName: "labelKey", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, loading: { classPropertyName: "loading", publicName: "loading", isSignal: true, isRequired: false, transformFunction: null }, loadingKey: { classPropertyName: "loadingKey", publicName: "loadingKey", isSignal: true, isRequired: false, transformFunction: null } }, host: { classAttribute: "ui-shared-button-content" }, ngImport: i0, template: "@if (loading()) {\n  <ui-shared-spinner class=\"ui-shared-button-content__spinner\" size=\"16\" />\n} @else if (icon()) {\n  <ui-shared-icon class=\"ui-shared-button-content__icon\" [name]=\"icon()\" size=\"sm\" />\n}\n<span class=\"ui-shared-button-content__label\">\n  @if (loading() && loadingKey()) { {{ loadingKey() | uiTranslate }} }\n  @else if (labelKey()) { {{ labelKey() | uiTranslate }} }\n  @else if (label()) { {{ label() }} }\n  @else { <ng-content /> }\n</span>\n@if (iconEnd() && !loading()) {\n  <ui-shared-icon class=\"ui-shared-button-content__icon\" [name]=\"iconEnd()\" size=\"sm\" />\n}\n", styles: [":host{display:inline-flex;box-sizing:border-box;min-width:0;max-width:100%}:host{align-items:center}.ui-shared-button-content__spinner,.ui-shared-button-content__icon{flex:none}.ui-shared-button-content__label{display:inline-flex;align-items:center;min-width:0;white-space:nowrap}.ui-shared-button-content__label:empty{display:none}\n"], dependencies: [{ kind: "pipe", type: UiTranslatePipe, name: "uiTranslate" }, { kind: "component", type: UiSharedIconComponent, selector: "ui-shared-icon", inputs: ["name", "size", "tone", "badge"] }, { kind: "component", type: UiSharedSpinnerComponent, selector: "ui-shared-spinner", inputs: ["size"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedButtonContentComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ui-shared-button-content', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, imports: [UiTranslatePipe, UiSharedIconComponent, UiSharedSpinnerComponent], host: { class: 'ui-shared-button-content' }, template: "@if (loading()) {\n  <ui-shared-spinner class=\"ui-shared-button-content__spinner\" size=\"16\" />\n} @else if (icon()) {\n  <ui-shared-icon class=\"ui-shared-button-content__icon\" [name]=\"icon()\" size=\"sm\" />\n}\n<span class=\"ui-shared-button-content__label\">\n  @if (loading() && loadingKey()) { {{ loadingKey() | uiTranslate }} }\n  @else if (labelKey()) { {{ labelKey() | uiTranslate }} }\n  @else if (label()) { {{ label() }} }\n  @else { <ng-content /> }\n</span>\n@if (iconEnd() && !loading()) {\n  <ui-shared-icon class=\"ui-shared-button-content__icon\" [name]=\"iconEnd()\" size=\"sm\" />\n}\n", styles: [":host{display:inline-flex;box-sizing:border-box;min-width:0;max-width:100%}:host{align-items:center}.ui-shared-button-content__spinner,.ui-shared-button-content__icon{flex:none}.ui-shared-button-content__label{display:inline-flex;align-items:center;min-width:0;white-space:nowrap}.ui-shared-button-content__label:empty{display:none}\n"] }]
        }] });

/**
 * The one text button. Every look is a `variant`, every height a `size`;
 * the styles live in the library theme (`.ui-shared-button`).
 *
 *   primary        filled accent (save, create, submit)
 *   secondary      outlined neutral (cancel, export, secondary actions)
 *   accent         outlined accent (open, sync)
 *   danger         outlined red (delete, deactivate)
 *   danger-filled  filled red (destructive primary)
 *   text           borderless (reset, whole month)
 *
 * Renders an `<a>` when `routerLink` is set, a spinner + `loadingKey` while
 * `loading`. With neither `labelKey` nor `label`, projected content is the label
 * (avatar + name, custom chrome). Put it in `[slot=trigger]` of <ui-shared-menu>
 * to open a menu.
 *
 *   <ui-shared-button variant="primary" icon="add" labelKey="products.add" (click)="openCreate()" />
 *   <ui-shared-button type="submit" [loading]="saving()" loadingKey="common.saving" labelKey="common.save" [disabled]="form.invalid" />
 *   <ui-shared-button variant="secondary" size="lg" labelKey="home.cta.signIn" routerLink="/auth/login" />
 */
class UiSharedButtonComponent {
    variant = input('secondary');
    size = input('md');
    /** Translation key of the label; `label` is the raw-text alternative. */
    labelKey = input('');
    label = input('');
    /** Material icon before the label; `iconEnd` puts it after. */
    icon = input('');
    iconEnd = input('');
    type = input('button');
    disabled = input(false, { transform: booleanAttribute });
    /** Shows a spinner and, when set, `loadingKey` instead of the label; the button is disabled meanwhile. */
    loading = input(false, { transform: booleanAttribute });
    loadingKey = input('');
    tooltipKey = input('');
    /** Renders an anchor instead of a button. */
    routerLink = input(null);
    queryParams = input(null);
    /** Full-width (auth forms). */
    block = input(false, { transform: booleanAttribute });
    get classes() {
        return `ui-shared-button ui-shared-button--${this.variant()} ui-shared-button--${this.size()}`;
    }
    get isDisabled() { return this.disabled() || this.loading(); }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedButtonComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: UiSharedButtonComponent, isStandalone: true, selector: "ui-shared-button", inputs: { variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, labelKey: { classPropertyName: "labelKey", publicName: "labelKey", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, icon: { classPropertyName: "icon", publicName: "icon", isSignal: true, isRequired: false, transformFunction: null }, iconEnd: { classPropertyName: "iconEnd", publicName: "iconEnd", isSignal: true, isRequired: false, transformFunction: null }, type: { classPropertyName: "type", publicName: "type", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, loading: { classPropertyName: "loading", publicName: "loading", isSignal: true, isRequired: false, transformFunction: null }, loadingKey: { classPropertyName: "loadingKey", publicName: "loadingKey", isSignal: true, isRequired: false, transformFunction: null }, tooltipKey: { classPropertyName: "tooltipKey", publicName: "tooltipKey", isSignal: true, isRequired: false, transformFunction: null }, routerLink: { classPropertyName: "routerLink", publicName: "routerLink", isSignal: true, isRequired: false, transformFunction: null }, queryParams: { classPropertyName: "queryParams", publicName: "queryParams", isSignal: true, isRequired: false, transformFunction: null }, block: { classPropertyName: "block", publicName: "block", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class.ui-shared-button--block": "block()" } }, ngImport: i0, template: "<ng-template #content>\n  <ui-shared-button-content [icon]=\"icon()\" [iconEnd]=\"iconEnd()\" [labelKey]=\"labelKey()\" [label]=\"label()\"\n                            [loading]=\"loading()\" [loadingKey]=\"loadingKey()\">\n    <ng-content />\n  </ui-shared-button-content>\n</ng-template>\n\n@if (routerLink(); as link) {\n  <a [class]=\"classes\" [routerLink]=\"link\" [queryParams]=\"queryParams()\" [attr.aria-disabled]=\"isDisabled || null\" [attr.tabindex]=\"isDisabled ? -1 : null\"\n     [matTooltip]=\"tooltipKey() ? (tooltipKey() | uiTranslate) : ''\">\n    <ng-container *ngTemplateOutlet=\"content\" />\n  </a>\n} @else {\n  <button [type]=\"type()\" [class]=\"classes\" [disabled]=\"isDisabled\"\n          [matTooltip]=\"tooltipKey() ? (tooltipKey() | uiTranslate) : ''\">\n    <ng-container *ngTemplateOutlet=\"content\" />\n  </button>\n}\n", styles: [":host{display:inline-flex;box-sizing:border-box;min-width:0;max-width:100%}:host{vertical-align:middle}:host(.ui-shared-button--block){display:flex}:host(.ui-shared-button--block) .ui-shared-button{width:100%}.ui-shared-button{display:inline-flex;align-items:center;justify-content:center}\n"], dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "directive", type: i1.MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }, { kind: "pipe", type: UiTranslatePipe, name: "uiTranslate" }, { kind: "component", type: UiSharedButtonContentComponent, selector: "ui-shared-button-content", inputs: ["icon", "iconEnd", "labelKey", "label", "loading", "loadingKey"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedButtonComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ui-shared-button', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, imports: [NgTemplateOutlet, RouterLink, MatTooltipModule, UiTranslatePipe, UiSharedButtonContentComponent], host: { '[class.ui-shared-button--block]': 'block()' }, template: "<ng-template #content>\n  <ui-shared-button-content [icon]=\"icon()\" [iconEnd]=\"iconEnd()\" [labelKey]=\"labelKey()\" [label]=\"label()\"\n                            [loading]=\"loading()\" [loadingKey]=\"loadingKey()\">\n    <ng-content />\n  </ui-shared-button-content>\n</ng-template>\n\n@if (routerLink(); as link) {\n  <a [class]=\"classes\" [routerLink]=\"link\" [queryParams]=\"queryParams()\" [attr.aria-disabled]=\"isDisabled || null\" [attr.tabindex]=\"isDisabled ? -1 : null\"\n     [matTooltip]=\"tooltipKey() ? (tooltipKey() | uiTranslate) : ''\">\n    <ng-container *ngTemplateOutlet=\"content\" />\n  </a>\n} @else {\n  <button [type]=\"type()\" [class]=\"classes\" [disabled]=\"isDisabled\"\n          [matTooltip]=\"tooltipKey() ? (tooltipKey() | uiTranslate) : ''\">\n    <ng-container *ngTemplateOutlet=\"content\" />\n  </button>\n}\n", styles: [":host{display:inline-flex;box-sizing:border-box;min-width:0;max-width:100%}:host{vertical-align:middle}:host(.ui-shared-button--block){display:flex}:host(.ui-shared-button--block) .ui-shared-button{width:100%}.ui-shared-button{display:inline-flex;align-items:center;justify-content:center}\n"] }]
        }] });

/**
 * Square icon-only button; `tooltipKey` doubles as the accessible name.
 * `size="sm"` (32px) is the inline row action (remove line, open row);
 * `size="md"` (40px) the toolbar one. `tone="danger"` turns red on hover,
 * `tone="accent"` is always accent (favourite on).
 *
 *   <ui-shared-icon-button icon="delete" tone="danger" tooltipKey="common.delete" (click)="remove(i)" />
 *   <ui-shared-icon-button slot="trigger" icon="more_vert" tooltipKey="core.grid.rowActions" />  (inside <ui-shared-menu>)
 */
class UiSharedIconButtonComponent {
    icon = input.required();
    tooltipKey = input.required();
    tone = input('default');
    size = input('sm');
    type = input('button');
    disabled = input(false, { transform: booleanAttribute });
    /** Count bubble on the icon (notifications); hidden when null / 0. */
    badge = input(null);
    get classes() {
        return `ui-shared-icon-button ui-shared-icon-button--${this.size()} ui-shared-icon-button--${this.tone()}`;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedIconButtonComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "19.2.25", type: UiSharedIconButtonComponent, isStandalone: true, selector: "ui-shared-icon-button", inputs: { icon: { classPropertyName: "icon", publicName: "icon", isSignal: true, isRequired: true, transformFunction: null }, tooltipKey: { classPropertyName: "tooltipKey", publicName: "tooltipKey", isSignal: true, isRequired: true, transformFunction: null }, tone: { classPropertyName: "tone", publicName: "tone", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, type: { classPropertyName: "type", publicName: "type", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, badge: { classPropertyName: "badge", publicName: "badge", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: "<button [type]=\"type()\" [class]=\"classes\" [disabled]=\"disabled()\"\n        [matTooltip]=\"tooltipKey() | uiTranslate\" [attr.aria-label]=\"tooltipKey() | uiTranslate\">\n  <ui-shared-icon [name]=\"icon()\" [badge]=\"badge()\" />\n</button>\n", styles: [":host{display:inline-flex;box-sizing:border-box;min-width:0;max-width:100%}:host{vertical-align:middle}.ui-shared-icon-button{display:inline-flex;align-items:center;justify-content:center;flex:none}\n"], dependencies: [{ kind: "ngmodule", type: MatTooltipModule }, { kind: "directive", type: i1.MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }, { kind: "pipe", type: UiTranslatePipe, name: "uiTranslate" }, { kind: "component", type: UiSharedIconComponent, selector: "ui-shared-icon", inputs: ["name", "size", "tone", "badge"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedIconButtonComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ui-shared-icon-button', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, imports: [MatTooltipModule, UiTranslatePipe, UiSharedIconComponent], template: "<button [type]=\"type()\" [class]=\"classes\" [disabled]=\"disabled()\"\n        [matTooltip]=\"tooltipKey() | uiTranslate\" [attr.aria-label]=\"tooltipKey() | uiTranslate\">\n  <ui-shared-icon [name]=\"icon()\" [badge]=\"badge()\" />\n</button>\n", styles: [":host{display:inline-flex;box-sizing:border-box;min-width:0;max-width:100%}:host{vertical-align:middle}.ui-shared-icon-button{display:inline-flex;align-items:center;justify-content:center;flex:none}\n"] }]
        }] });

/**
 * The action row: wraps buttons with a uniform gap, wraps on narrow screens.
 * `align` end (default: form actions), start (inline toolbars), between (back + actions),
 * center (empty states). `divided` adds the top rule + spacing of a form footer.
 *
 *   <ui-shared-button-group divided>
 *     <ui-shared-button variant="secondary" labelKey="common.cancel" (click)="close()" />
 *     <ui-shared-button variant="primary" labelKey="common.save" (click)="save()" />
 *   </ui-shared-button-group>
 */
class UiSharedButtonGroupComponent {
    align = input('end');
    divided = input(false, { transform: booleanAttribute });
    /** Vertical list of full-width buttons (auth cards). */
    stack = input(false, { transform: booleanAttribute });
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedButtonGroupComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "19.2.25", type: UiSharedButtonGroupComponent, isStandalone: true, selector: "ui-shared-button-group", inputs: { align: { classPropertyName: "align", publicName: "align", isSignal: true, isRequired: false, transformFunction: null }, divided: { classPropertyName: "divided", publicName: "divided", isSignal: true, isRequired: false, transformFunction: null }, stack: { classPropertyName: "stack", publicName: "stack", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class.ui-shared-button-group--divided": "divided()", "class.ui-shared-button-group--stack": "stack()", "attr.data-align": "align()" }, classAttribute: "ui-shared-button-group" }, ngImport: i0, template: "<ng-content />\n", styles: [":host{display:flex;box-sizing:border-box;min-width:0;max-width:100%}:host{align-items:center;justify-content:flex-end;flex-wrap:wrap}:host([data-align=start]){justify-content:flex-start}:host([data-align=between]){justify-content:space-between}:host([data-align=center]){justify-content:center}:host(.ui-shared-button-group--stack){flex-direction:column;align-items:stretch}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedButtonGroupComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ui-shared-button-group', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, host: {
                        class: 'ui-shared-button-group',
                        '[class.ui-shared-button-group--divided]': 'divided()',
                        '[class.ui-shared-button-group--stack]': 'stack()',
                        '[attr.data-align]': 'align()',
                    }, template: "<ng-content />\n", styles: [":host{display:flex;box-sizing:border-box;min-width:0;max-width:100%}:host{align-items:center;justify-content:flex-end;flex-wrap:wrap}:host([data-align=start]){justify-content:flex-start}:host([data-align=between]){justify-content:space-between}:host([data-align=center]){justify-content:center}:host(.ui-shared-button-group--stack){flex-direction:column;align-items:stretch}\n"] }]
        }] });

/**
 * One entry of <ui-shared-menu> (row actions, user menu). `danger` paints it red.
 * Listen to `(click)` on the host; a disabled item never emits. With neither
 * `labelKey` nor `label`, projected content is the row (rich notification rows).
 *
 *   <mat-menu #rowMenu="matMenu">
 *     <ui-shared-menu-item icon="edit" labelKey="common.edit" (click)="edit(r)" />
 *     <ui-shared-menu-item icon="delete" labelKey="common.delete" danger (click)="remove(r)" />
 *   </mat-menu>
 */
class UiSharedMenuItemComponent {
    icon = input('');
    labelKey = input('');
    label = input('');
    danger = input(false, { transform: booleanAttribute });
    disabled = input(false, { transform: booleanAttribute });
    /** Navigates instead of emitting; renders an anchor. */
    link = input(null);
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedMenuItemComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: UiSharedMenuItemComponent, isStandalone: true, selector: "ui-shared-menu-item", inputs: { icon: { classPropertyName: "icon", publicName: "icon", isSignal: true, isRequired: false, transformFunction: null }, labelKey: { classPropertyName: "labelKey", publicName: "labelKey", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, danger: { classPropertyName: "danger", publicName: "danger", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, link: { classPropertyName: "link", publicName: "link", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: "<ng-template #content>\n  <ui-shared-button-content [icon]=\"icon()\" [labelKey]=\"labelKey()\" [label]=\"label()\"><ng-content /></ui-shared-button-content>\n</ng-template>\n@if (link(); as l) {\n  <a mat-menu-item class=\"ui-shared-menu-item\" [class.ui-shared-menu-item--danger]=\"danger()\" [disabled]=\"disabled()\" [routerLink]=\"disabled() ? null : l\">\n    <ng-container *ngTemplateOutlet=\"content\" />\n  </a>\n} @else {\n  <button mat-menu-item type=\"button\" class=\"ui-shared-menu-item\" [class.ui-shared-menu-item--danger]=\"danger()\" [disabled]=\"disabled()\">\n    <ng-container *ngTemplateOutlet=\"content\" />\n  </button>\n}\n", styles: [":host{display:block;box-sizing:border-box;min-width:0;max-width:100%}\n"], dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "ngmodule", type: MatMenuModule }, { kind: "component", type: i1$1.MatMenuItem, selector: "[mat-menu-item]", inputs: ["role", "disabled", "disableRipple"], exportAs: ["matMenuItem"] }, { kind: "component", type: UiSharedButtonContentComponent, selector: "ui-shared-button-content", inputs: ["icon", "iconEnd", "labelKey", "label", "loading", "loadingKey"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedMenuItemComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ui-shared-menu-item', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, imports: [NgTemplateOutlet, RouterLink, MatMenuModule, UiSharedButtonContentComponent], template: "<ng-template #content>\n  <ui-shared-button-content [icon]=\"icon()\" [labelKey]=\"labelKey()\" [label]=\"label()\"><ng-content /></ui-shared-button-content>\n</ng-template>\n@if (link(); as l) {\n  <a mat-menu-item class=\"ui-shared-menu-item\" [class.ui-shared-menu-item--danger]=\"danger()\" [disabled]=\"disabled()\" [routerLink]=\"disabled() ? null : l\">\n    <ng-container *ngTemplateOutlet=\"content\" />\n  </a>\n} @else {\n  <button mat-menu-item type=\"button\" class=\"ui-shared-menu-item\" [class.ui-shared-menu-item--danger]=\"danger()\" [disabled]=\"disabled()\">\n    <ng-container *ngTemplateOutlet=\"content\" />\n  </button>\n}\n", styles: [":host{display:block;box-sizing:border-box;min-width:0;max-width:100%}\n"] }]
        }] });

/**
 * Dropdown menu: the trigger is whatever you project into `[slot=trigger]`
 * (a ui-shared-button / icon-button), the rest is the panel content
 * (<ui-shared-menu-item>, <ui-shared-divider>, or custom rows).
 * Arrow / Home / End keys move between the rows, Escape closes.
 *
 *   <ui-shared-menu align="end" (opened)="reload()">
 *     <ui-shared-icon-button slot="trigger" icon="more_vert" tooltipKey="core.grid.rowActions" />
 *     <ui-shared-menu-item icon="edit" labelKey="common.edit" (click)="edit()" />
 *   </ui-shared-menu>
 */
class UiSharedMenuComponent {
    /** Which edge of the trigger the panel aligns to. */
    align = input('start');
    /** Extra class on the overlay panel (for app-level width / layout rules). */
    panelClass = input('');
    /** No inner padding (rows carry their own). */
    flush = input(false, { transform: booleanAttribute });
    /** Wide panel capped to the viewport, scrolls inside (notification feeds). */
    wide = input(false, { transform: booleanAttribute });
    opened = output();
    closed = output();
    panel = viewChild.required(MatMenu);
    get panelClasses() {
        return ['ui-shared-menu__panel', this.flush() ? 'ui-shared-menu__panel--flush' : '', this.wide() ? 'ui-shared-menu__panel--wide' : '', this.panelClass()]
            .filter(Boolean).join(' ');
    }
    onOpened() {
        this.opened.emit();
        // The rows are projected, so Material's own key manager never sees them: focus the first one ourselves.
        setTimeout(() => this.items()[0]?.focus());
    }
    onKeydown(event) {
        const items = this.items();
        if (!items.length)
            return;
        const step = { ArrowDown: 1, ArrowUp: -1, Home: -Infinity, End: Infinity }[event.key];
        if (step === undefined)
            return;
        event.preventDefault();
        const current = items.indexOf(document.activeElement);
        const next = step === -Infinity ? 0 : step === Infinity ? items.length - 1
            : current < 0 ? (step > 0 ? 0 : items.length - 1) : (current + step + items.length) % items.length;
        items[next].focus();
    }
    items() {
        const el = document.getElementById(this.panel().panelId);
        return el ? Array.from(el.querySelectorAll('.mat-mdc-menu-item:not([disabled])')) : [];
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedMenuComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.2.0", version: "19.2.25", type: UiSharedMenuComponent, isStandalone: true, selector: "ui-shared-menu", inputs: { align: { classPropertyName: "align", publicName: "align", isSignal: true, isRequired: false, transformFunction: null }, panelClass: { classPropertyName: "panelClass", publicName: "panelClass", isSignal: true, isRequired: false, transformFunction: null }, flush: { classPropertyName: "flush", publicName: "flush", isSignal: true, isRequired: false, transformFunction: null }, wide: { classPropertyName: "wide", publicName: "wide", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { opened: "opened", closed: "closed" }, viewQueries: [{ propertyName: "panel", first: true, predicate: MatMenu, descendants: true, isSignal: true }], ngImport: i0, template: "<span class=\"ui-shared-menu__trigger\" [matMenuTriggerFor]=\"panel\" (menuOpened)=\"onOpened()\" (menuClosed)=\"closed.emit()\">\n  <ng-content select=\"[slot=trigger]\" />\n</span>\n<mat-menu #panel=\"matMenu\" [xPosition]=\"align() === 'end' ? 'before' : 'after'\" [class]=\"panelClasses\">\n  <div class=\"ui-shared-menu__list\" (keydown)=\"onKeydown($event)\">\n    <ng-content />\n  </div>\n</mat-menu>\n", styles: [":host{display:inline-flex;box-sizing:border-box;min-width:0;max-width:100%}.ui-shared-menu__trigger{display:inline-flex}\n"], dependencies: [{ kind: "ngmodule", type: MatMenuModule }, { kind: "component", type: i1$1.MatMenu, selector: "mat-menu", inputs: ["backdropClass", "aria-label", "aria-labelledby", "aria-describedby", "xPosition", "yPosition", "overlapTrigger", "hasBackdrop", "class", "classList"], outputs: ["closed", "close"], exportAs: ["matMenu"] }, { kind: "directive", type: i1$1.MatMenuTrigger, selector: "[mat-menu-trigger-for], [matMenuTriggerFor]", inputs: ["mat-menu-trigger-for", "matMenuTriggerFor", "matMenuTriggerData", "matMenuTriggerRestoreFocus"], outputs: ["menuOpened", "onMenuOpen", "menuClosed", "onMenuClose"], exportAs: ["matMenuTrigger"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedMenuComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ui-shared-menu', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, imports: [MatMenuModule], template: "<span class=\"ui-shared-menu__trigger\" [matMenuTriggerFor]=\"panel\" (menuOpened)=\"onOpened()\" (menuClosed)=\"closed.emit()\">\n  <ng-content select=\"[slot=trigger]\" />\n</span>\n<mat-menu #panel=\"matMenu\" [xPosition]=\"align() === 'end' ? 'before' : 'after'\" [class]=\"panelClasses\">\n  <div class=\"ui-shared-menu__list\" (keydown)=\"onKeydown($event)\">\n    <ng-content />\n  </div>\n</mat-menu>\n", styles: [":host{display:inline-flex;box-sizing:border-box;min-width:0;max-width:100%}.ui-shared-menu__trigger{display:inline-flex}\n"] }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { UiSharedButtonComponent, UiSharedButtonContentComponent, UiSharedButtonGroupComponent, UiSharedIconButtonComponent, UiSharedMenuComponent, UiSharedMenuItemComponent };
//# sourceMappingURL=borassoft-ui-components-buttons.mjs.map
