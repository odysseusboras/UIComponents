import { SafeHtml } from '@angular/platform-browser';
import * as i0 from "@angular/core";
/**
 * Renders a string (e.g. a verification URL) as an actual QR code. Pure
 * client-side, zero network: qrcode-generator builds a scalable SVG that fills
 * the host box (size it from the parent).
 */
export declare class UiSharedQrCodeComponent {
    /** The payload to encode. */
    value: import("@angular/core").InputSignal<string>;
    private sanitizer;
    protected svg: import("@angular/core").Signal<"" | SafeHtml>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UiSharedQrCodeComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UiSharedQrCodeComponent, "ui-shared-qr-code", never, { "value": { "alias": "value"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=ui-shared-qr-code.component.d.ts.map