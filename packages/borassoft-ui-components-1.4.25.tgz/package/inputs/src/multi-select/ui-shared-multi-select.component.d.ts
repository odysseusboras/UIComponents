import { FormControl } from '@angular/forms';
import { SubscriptSizing } from '@angular/material/form-field';
import { ClauseBuilder, GridFilterState, SelectOption, firstError } from '@borassoft/ui-components';
import * as i0 from "@angular/core";
/**
 * The one multi-value dropdown: the control holds an array of option VALUES. Inactive
 * (soft-deleted) options are offered only while they are selected, struck through with a marker,
 * exactly like <ui-shared-select> (D-55 of ATLAS). A list of 8 options or more has a search box on top: typing
 * narrows the options (label, ignoring case and accents), the picks made so far stay.
 *
 * Inside `<ui-shared-grid>` with `field` (or `[clauseBuilder]`) it is a grid filter: rows matching ANY of the
 * picked values.
 *
 *   <ui-shared-multi-select [control]="form.controls.regionIds" labelKey="activity.regions" [options]="regions()" />
 *   <ui-shared-multi-select labelKey="users.role" [options]="roles" field="Role" />
 */
export declare class UiSharedMultiSelectComponent<T = string> {
    /** Optional when used as a grid filter. */
    control: import("@angular/core").InputSignal<FormControl<T[]> | null>;
    labelKey: import("@angular/core").InputSignal<string>;
    options: import("@angular/core").InputSignal<SelectOption<T>[]>;
    hintKey: import("@angular/core").InputSignal<string>;
    hintText: import("@angular/core").InputSignal<string>;
    subscriptSizing: import("@angular/core").InputSignal<SubscriptSizing>;
    /** Grid filter: OData field compared with `eq` against each picked value (any of them). */
    field: import("@angular/core").InputSignal<string | null>;
    /** Grid filter: custom clause for the picked values (overrides `field`). */
    clauseBuilder: import("@angular/core").InputSignal<ClauseBuilder<T[]> | null>;
    private own;
    protected ctrl: import("@angular/core").Signal<FormControl<T[]>>;
    readonly filter: GridFilterState<T[]>;
    protected readonly firstError: typeof firstError;
    protected required: import("@angular/core").Signal<boolean>;
    private translate;
    private search;
    private select;
    protected query: import("@angular/core").WritableSignal<string>;
    protected get searchable(): boolean;
    protected filteredOut(o: SelectOption<T>): boolean;
    protected onQuery(text: string): void;
    protected onOpened(open: boolean): void;
    /** Typing goes to the search box: on open, and again after a pick (a click moves the focus to the panel). */
    protected focusSearch(): void;
    /** The panel's own keys still work from the box (arrows, Enter to tick, Escape, Tab); the rest is text, not type-ahead. */
    protected onSearchKey(event: KeyboardEvent): void;
    /** Active options, plus the inactive ones that are currently selected. */
    protected get offered(): SelectOption<T>[];
    /** The selected options, in option order, for the trigger text. */
    protected get selected(): SelectOption<T>[];
    protected get hasInactive(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<UiSharedMultiSelectComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UiSharedMultiSelectComponent<any>, "ui-shared-multi-select", never, { "control": { "alias": "control"; "required": false; "isSignal": true; }; "labelKey": { "alias": "labelKey"; "required": true; "isSignal": true; }; "options": { "alias": "options"; "required": true; "isSignal": true; }; "hintKey": { "alias": "hintKey"; "required": false; "isSignal": true; }; "hintText": { "alias": "hintText"; "required": false; "isSignal": true; }; "subscriptSizing": { "alias": "subscriptSizing"; "required": false; "isSignal": true; }; "field": { "alias": "field"; "required": false; "isSignal": true; }; "clauseBuilder": { "alias": "clauseBuilder"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=ui-shared-multi-select.component.d.ts.map