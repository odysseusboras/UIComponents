import { ValidatorFn } from '@angular/forms';
export type PasswordStrength = 'weak' | 'medium' | 'strong';
/**
 * strong = 12+ characters with a lowercase letter, an uppercase letter, a digit and a symbol (anything else);
 * medium = 8+ characters with three of those four; weak otherwise. Letters are any script (Greek too).
 */
export declare function passwordStrength(value: string): PasswordStrength;
/** `{ passwordWeak: true }` unless the value is strong; an empty value is left to `Validators.required`. */
export declare const strongPassword: ValidatorFn;
/**
 * Group validator: `{ passwordMismatch: true }` on the group AND on control `b` (so its field shows the error)
 * while the two values differ. Only that error is ever added or removed on `b`.
 */
export declare function matchingFields(a: string, b: string): ValidatorFn;
//# sourceMappingURL=password.d.ts.map