import { OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { ClauseBuilder, GridFilterState, SelectOption } from '@borassoft/ui-components';
import * as i0 from "@angular/core";
/**
 * The one segmented control (single-choice button toggle row). Three uses:
 *  - view state: `[value]` in, `(valueChange)` out;
 *  - form: `[control]`;
 *  - grid filter inside `<ui-shared-grid>`: `field` or `[clauseBuilder]`, plus
 *    `initial` (selected on load, restored by Clear; defaults to the first
 *    option). With `field`, the value `all` filters nothing.
 *
 * `storageKey` remembers the choice in the browser and restores it on load
 * (emitting `valueChange`, and applying it when used as a filter). The options
 * must be known on init for the restore to happen.
 *
 *   <ui-shared-segmented [options]="years" [value]="year()" (valueChange)="year.set($event)" storageKey="home.year" />
 *   <ui-shared-segmented [options]="statusOptions" initial="active" [clauseBuilder]="softDeleteClauseBuilder" />
 */
export declare class UiSharedSegmentedComponent<T = string> implements OnInit {
    options: import("@angular/core").InputSignal<SelectOption<T>[]>;
    value: import("@angular/core").InputSignal<T | null>;
    disabled: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    ariaLabelKey: import("@angular/core").InputSignal<string>;
    valueChange: import("@angular/core").OutputEmitterRef<T>;
    control: import("@angular/core").InputSignal<FormControl<T | null> | null>;
    /** Remember the choice in the browser under this key. */
    storageKey: import("@angular/core").InputSignal<string>;
    /** Grid filter: OData field compared with `eq` (`all` = no filter). */
    field: import("@angular/core").InputSignal<string | null>;
    /** Grid filter: custom clause for the picked value (overrides `field`). */
    clauseBuilder: import("@angular/core").InputSignal<ClauseBuilder<T> | null>;
    /** Grid filter: value selected on load and restored by Clear; defaults to the first option. */
    initial: import("@angular/core").InputSignal<T | null>;
    private own;
    /** The group always binds a control: the caller's, or an internal one (view state / filter). */
    protected ctrl: import("@angular/core").Signal<FormControl<T | null>>;
    readonly filter: GridFilterState<T>;
    constructor();
    ngOnInit(): void;
    protected onChange(value: T): void;
    private fieldEq;
    static ɵfac: i0.ɵɵFactoryDeclaration<UiSharedSegmentedComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UiSharedSegmentedComponent<any>, "ui-shared-segmented", never, { "options": { "alias": "options"; "required": true; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "ariaLabelKey": { "alias": "ariaLabelKey"; "required": false; "isSignal": true; }; "control": { "alias": "control"; "required": false; "isSignal": true; }; "storageKey": { "alias": "storageKey"; "required": false; "isSignal": true; }; "field": { "alias": "field"; "required": false; "isSignal": true; }; "clauseBuilder": { "alias": "clauseBuilder"; "required": false; "isSignal": true; }; "initial": { "alias": "initial"; "required": false; "isSignal": true; }; }, { "valueChange": "valueChange"; }, never, never, true, never>;
}
//# sourceMappingURL=ui-shared-segmented.component.d.ts.map