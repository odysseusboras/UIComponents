import * as i0 from "@angular/core";
/**
 * Tracks in-flight work for `<ui-shared-loading-overlay>`. The host calls
 * start()/stop() around every request (e.g. from an HTTP interceptor); the
 * overlay reads `visible`.
 *
 * `visible` is debounced: it only turns on if work stays pending past a short
 * grace period (so fast calls don't flash the overlay), and turns off the
 * moment the last call settles.
 */
export declare class UiLoadingService {
    private active;
    private timer;
    private static readonly GRACE_MS;
    /** True while a request has been pending longer than the grace period. */
    readonly visible: import("@angular/core").WritableSignal<boolean>;
    start(): void;
    stop(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<UiLoadingService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UiLoadingService>;
}
//# sourceMappingURL=loading.service.d.ts.map