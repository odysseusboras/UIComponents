/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@borassoft/ui-components/buttons" />
export * from './public-api';
//# sourceMappingURL=borassoft-ui-components-buttons.d.ts.map