import { FormControl } from '@angular/forms';
import { SubscriptSizing } from '@angular/material/form-field';
import { firstError } from '@borassoft/ui-components';
import * as i0 from "@angular/core";
/** The one date picker. Day-first typing/display comes from `provideUiDates()` in the app config. */
export declare class UiSharedDateInputComponent {
    control: import("@angular/core").InputSignal<FormControl<any>>;
    labelKey: import("@angular/core").InputSignal<string>;
    hintKey: import("@angular/core").InputSignal<string>;
    hintText: import("@angular/core").InputSignal<string>;
    min: import("@angular/core").InputSignal<Date | null>;
    max: import("@angular/core").InputSignal<Date | null>;
    subscriptSizing: import("@angular/core").InputSignal<SubscriptSizing>;
    protected readonly firstError: typeof firstError;
    protected required: import("@angular/core").Signal<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UiSharedDateInputComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UiSharedDateInputComponent, "ui-shared-date-input", never, { "control": { "alias": "control"; "required": true; "isSignal": true; }; "labelKey": { "alias": "labelKey"; "required": true; "isSignal": true; }; "hintKey": { "alias": "hintKey"; "required": false; "isSignal": true; }; "hintText": { "alias": "hintText"; "required": false; "isSignal": true; }; "min": { "alias": "min"; "required": false; "isSignal": true; }; "max": { "alias": "max"; "required": false; "isSignal": true; }; "subscriptSizing": { "alias": "subscriptSizing"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=ui-shared-date-input.component.d.ts.map