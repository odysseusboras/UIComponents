import * as i0 from "@angular/core";
/**
 * One entry of <ui-shared-menu> (row actions, user menu). `danger` paints it red.
 * Listen to `(click)` on the host; a disabled item never emits. With neither
 * `labelKey` nor `label`, projected content is the row (rich notification rows).
 *
 *   <mat-menu #rowMenu="matMenu">
 *     <ui-shared-menu-item icon="edit" labelKey="common.edit" (click)="edit(r)" />
 *     <ui-shared-menu-item icon="delete" labelKey="common.delete" danger (click)="remove(r)" />
 *   </mat-menu>
 */
export declare class UiSharedMenuItemComponent {
    icon: import("@angular/core").InputSignal<string>;
    labelKey: import("@angular/core").InputSignal<string>;
    label: import("@angular/core").InputSignal<string>;
    danger: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    disabled: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    /** Navigates instead of emitting; renders an anchor. */
    link: import("@angular/core").InputSignal<string | any[] | null>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UiSharedMenuItemComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UiSharedMenuItemComponent, "ui-shared-menu-item", never, { "icon": { "alias": "icon"; "required": false; "isSignal": true; }; "labelKey": { "alias": "labelKey"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "danger": { "alias": "danger"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "link": { "alias": "link"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}
//# sourceMappingURL=ui-shared-menu-item.component.d.ts.map