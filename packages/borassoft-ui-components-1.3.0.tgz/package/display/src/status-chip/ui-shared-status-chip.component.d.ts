import { StatusTone } from './status-tones';
import * as i0 from "@angular/core";
/**
 * The one status/state pill, so every grid, detail page and drawer renders
 * state identically.
 *
 *   <ui-shared-status-chip [tone]="activeTone(row.isDeleted)" icon="check_circle">
 *     {{ 'documents.status.submitted' | uiTranslate }}
 *   </ui-shared-status-chip>
 *
 *   <ui-shared-status-chip tone="bad" dot size="lg" [tooltip]="row.errorMessage">…</ui-shared-status-chip>
 */
export declare class UiSharedStatusChipComponent {
    tone: import("@angular/core").InputSignal<StatusTone>;
    /** Optional leading Material icon name. */
    icon: import("@angular/core").InputSignal<string>;
    /** Leading state dot instead of an icon. */
    dot: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    size: import("@angular/core").InputSignal<"sm" | "lg">;
    /** Tooltip text (already translated). Adds `cursor: help`. */
    tooltip: import("@angular/core").InputSignal<string>;
    /** Transparent fill with a tinted border. */
    outline: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UiSharedStatusChipComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UiSharedStatusChipComponent, "ui-shared-status-chip", never, { "tone": { "alias": "tone"; "required": false; "isSignal": true; }; "icon": { "alias": "icon"; "required": false; "isSignal": true; }; "dot": { "alias": "dot"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "tooltip": { "alias": "tooltip"; "required": false; "isSignal": true; }; "outline": { "alias": "outline"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}
//# sourceMappingURL=ui-shared-status-chip.component.d.ts.map