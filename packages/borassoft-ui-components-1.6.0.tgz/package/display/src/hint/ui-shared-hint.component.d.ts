import * as i0 from "@angular/core";
export type UiHintTone = 'muted' | 'danger' | 'warning';
/**
 * The one explanation line: a small leading icon and muted text. Used under every form field
 * (hint and error), under a checkbox / toggle / segmented control, and on its own wherever a
 * section or a group of fields needs a sentence of help.
 *
 *   <ui-shared-hint textKey="settings.logo.hint" />
 *   <ui-shared-hint tone="danger" [text]="message" />
 */
export declare class UiSharedHintComponent {
    textKey: import("@angular/core").InputSignal<string>;
    text: import("@angular/core").InputSignal<string>;
    tone: import("@angular/core").InputSignal<UiHintTone>;
    protected icon: import("@angular/core").Signal<"info" | "error">;
    protected hostClass: import("@angular/core").Signal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UiSharedHintComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UiSharedHintComponent, "ui-shared-hint", never, { "textKey": { "alias": "textKey"; "required": false; "isSignal": true; }; "text": { "alias": "text"; "required": false; "isSignal": true; }; "tone": { "alias": "tone"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}
//# sourceMappingURL=ui-shared-hint.component.d.ts.map