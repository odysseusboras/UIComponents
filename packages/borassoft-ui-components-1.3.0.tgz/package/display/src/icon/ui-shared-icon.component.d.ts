import * as i0 from "@angular/core";
export type UiIconSize = 'sm' | 'md' | 'lg';
export type UiIconTone = 'inherit' | 'muted' | 'accent' | 'danger' | 'success' | 'warning' | 'info';
/**
 * A Material Symbols icon by name. `size` sm 18px / md 24px / lg 32px,
 * `tone` colours it, `badge` shows a count (hidden when empty or 0).
 *
 *   <ui-shared-icon name="receipt_long" />
 *   <ui-shared-icon name="notifications" [badge]="unread()" />
 */
export declare class UiSharedIconComponent {
    name: import("@angular/core").InputSignal<string>;
    size: import("@angular/core").InputSignal<UiIconSize>;
    tone: import("@angular/core").InputSignal<UiIconTone>;
    badge: import("@angular/core").InputSignal<string | number | null | undefined>;
    protected hostClass: import("@angular/core").Signal<string>;
    protected badgeHidden: import("@angular/core").Signal<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UiSharedIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UiSharedIconComponent, "ui-shared-icon", never, { "name": { "alias": "name"; "required": true; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "tone": { "alias": "tone"; "required": false; "isSignal": true; }; "badge": { "alias": "badge"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=ui-shared-icon.component.d.ts.map