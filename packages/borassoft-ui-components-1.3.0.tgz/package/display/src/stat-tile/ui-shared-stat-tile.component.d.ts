import { StatusTone } from '../status-chip/status-tones';
import * as i0 from "@angular/core";
/**
 * The one KPI tile (overview stats, summaries): icon + label + value, optional
 * tinted tone, optional link. Project extra lines as content; they render
 * under the value in the muted sub style.
 *
 *   <ui-shared-stat-tile icon="trending_up" [label]="'dashboard.income' | uiTranslate"
 *                 [value]="(d.income.totalGross | number:'1.2-2') + ' €'" [link]="documentsLink()">
 *     {{ 'dashboard.net' | uiTranslate }} {{ d.income.totalNet | number:'1.2-2' }}
 *   </ui-shared-stat-tile>
 */
export declare class UiSharedStatTileComponent {
    icon: import("@angular/core").InputSignal<string>;
    /** Already translated. */
    label: import("@angular/core").InputSignal<string>;
    /** Already formatted; ignored while `loading`, shows an em dash when empty. */
    value: import("@angular/core").InputSignal<string | number | null | undefined>;
    loading: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    /** Tints the icon and the value. */
    tone: import("@angular/core").InputSignal<"" | StatusTone>;
    link: import("@angular/core").InputSignal<any[] | null>;
    queryParams: import("@angular/core").InputSignal<Record<string, unknown> | null>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UiSharedStatTileComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UiSharedStatTileComponent, "ui-shared-stat-tile", never, { "icon": { "alias": "icon"; "required": true; "isSignal": true; }; "label": { "alias": "label"; "required": true; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "loading": { "alias": "loading"; "required": false; "isSignal": true; }; "tone": { "alias": "tone"; "required": false; "isSignal": true; }; "link": { "alias": "link"; "required": false; "isSignal": true; }; "queryParams": { "alias": "queryParams"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}
//# sourceMappingURL=ui-shared-stat-tile.component.d.ts.map