import * as i0 from "@angular/core";
/**
 * Section label of <ui-shared-nav-list>. Two shapes:
 *  - plain label above sibling items: `<ui-shared-nav-group labelKey="…" />`
 *  - collapsible section with its items inside: `<ui-shared-nav-group labelKey="…" collapsible storageKey="admin.lists">…items…</ui-shared-nav-group>`
 * The open/closed state is remembered per `storageKey` (`ui.choice.navGroup.<key>`).
 */
export declare class UiSharedNavGroupComponent {
    labelKey: import("@angular/core").InputSignal<string>;
    icon: import("@angular/core").InputSignal<string>;
    collapsible: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    /** Remembers open/closed under this key; without it the group starts open every time. */
    storageKey: import("@angular/core").InputSignal<string>;
    open: import("@angular/core").WritableSignal<boolean>;
    constructor();
    toggle(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<UiSharedNavGroupComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UiSharedNavGroupComponent, "ui-shared-nav-group", never, { "labelKey": { "alias": "labelKey"; "required": true; "isSignal": true; }; "icon": { "alias": "icon"; "required": false; "isSignal": true; }; "collapsible": { "alias": "collapsible"; "required": false; "isSignal": true; }; "storageKey": { "alias": "storageKey"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}
//# sourceMappingURL=ui-shared-nav-group.component.d.ts.map