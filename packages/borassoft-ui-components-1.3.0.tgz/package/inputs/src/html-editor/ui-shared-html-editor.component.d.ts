import { ControlValueAccessor } from '@angular/forms';
import { SafeHtml } from '@angular/platform-browser';
import * as i0 from "@angular/core";
/**
 * Tiny HTML editor with a Source / Preview toggle.
 *
 *   - SOURCE  : textarea holding the raw HTML markup.
 *   - PREVIEW : the same markup rendered via `bypassSecurityTrustHtml` — meant
 *               for trusted (admin-authored) content only.
 *
 * Implements `ControlValueAccessor` so it slots straight into a reactive form
 * (`formControlName="bodyEn"`). The current mode is component-local; the
 * bound form value is always the raw HTML string.
 *
 *   <ui-shared-html-editor formControlName="bodyEn" rows="16" />
 */
export declare class UiSharedHtmlEditorComponent implements ControlValueAccessor {
    /** Visible row count for the source textarea. */
    rows: import("@angular/core").InputSignalWithTransform<number, unknown>;
    /** Optional placeholder shown in the source textarea when empty. */
    placeholder: import("@angular/core").InputSignal<string>;
    private sanitizer;
    private injector;
    private ta?;
    protected value: import("@angular/core").WritableSignal<string>;
    protected disabled: import("@angular/core").WritableSignal<boolean>;
    protected mode: import("@angular/core").WritableSignal<"source" | "preview">;
    protected previewHtml: import("@angular/core").Signal<SafeHtml>;
    private onChange;
    private onTouched;
    writeValue(v: string | null): void;
    registerOnChange(fn: (v: string) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    protected onInput(ev: Event): void;
    protected onBlur(): void;
    protected showSource(): void;
    protected showPreview(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<UiSharedHtmlEditorComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UiSharedHtmlEditorComponent, "ui-shared-html-editor", never, { "rows": { "alias": "rows"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=ui-shared-html-editor.component.d.ts.map