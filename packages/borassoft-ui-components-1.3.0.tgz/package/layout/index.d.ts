/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@borassoft/ui-components/layout" />
export * from './public-api';
//# sourceMappingURL=borassoft-ui-components-layout.d.ts.map