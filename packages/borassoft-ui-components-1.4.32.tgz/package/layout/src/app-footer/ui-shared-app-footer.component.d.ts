import * as i0 from "@angular/core";
/**
 * Slim application footer: `[slot=start]` (copyright / owner), `[slot=links]` (terms, privacy, …),
 * `[slot=end]` (version). Wraps on narrow screens.
 */
export declare class UiSharedAppFooterComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<UiSharedAppFooterComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UiSharedAppFooterComponent, "ui-shared-app-footer", never, {}, {}, never, ["[slot=start]", "[slot=links]", "[slot=end]"], true, never>;
}
//# sourceMappingURL=ui-shared-app-footer.component.d.ts.map