import * as i0 from '@angular/core';
import { input, output, inject, NgZone, viewChild, effect, ChangeDetectionStrategy, Component } from '@angular/core';
import * as i1 from '@fullcalendar/angular';
import { FullCalendarComponent, FullCalendarModule } from '@fullcalendar/angular';
import dayGridPlugin from '@fullcalendar/daygrid';
import interactionPlugin from '@fullcalendar/interaction';
import elLocale from '@fullcalendar/core/locales/el';
import { UI_LOCALE, UI_TRANSLATE } from '@borassoft/ui-components';

/**
 * Month grid of all-day events, fed lazily per visible range like the grid is fed per page:
 * `source(from, to)` answers the events of `[from, to)` (ISO dates). The shown month is
 * reported through `monthChange` (yyyy-MM); `dateClick` gives the clicked day, `eventClick`
 * the clicked event's data, `eventAction` the hover button pressed on an event.
 *
 *   <ui-shared-calendar [source]="load" [actions]="[{ key: 'edit', icon: 'edit', labelKey: 'common.edit' }]"
 *       (monthChange)="month.set($event)" (dateClick)="add($event)" (eventClick)="open($event)" (eventAction)="run($event)" />
 */
class UiSharedCalendarComponent {
    source = input.required();
    actions = input([]);
    /** yyyy-MM to open on; the calendar otherwise starts on the current month. */
    month = input(null);
    /** Rows per day before "+n more" (FullCalendar `dayMaxEvents`). */
    maxPerDay = input(4);
    monthChange = output();
    dateClick = output();
    eventClick = output();
    eventAction = output();
    zone = inject(NgZone);
    locale = inject(UI_LOCALE);
    translate = inject(UI_TRANSLATE);
    calendar = viewChild(FullCalendarComponent);
    shown = '';
    options = {
        plugins: [dayGridPlugin, interactionPlugin],
        initialView: 'dayGridMonth',
        firstDay: 1,
        height: 'auto',
        fixedWeekCount: false,
        headerToolbar: { left: 'prev,next today', center: 'title', right: '' },
        events: (info, success, failure) => {
            this.source()(info.startStr.slice(0, 10), info.endStr.slice(0, 10))
                .subscribe({
                next: rows => success(rows.map(e => ({
                    id: e.id, title: e.title, date: e.date, allDay: true,
                    backgroundColor: e.color, borderColor: e.color, textColor: '#ffffff', extendedProps: { data: e.data },
                }))),
                error: err => failure(err),
            });
        },
        datesSet: info => {
            const d = info.view.currentStart;
            const month = `${d.getFullYear()}-${`${d.getMonth() + 1}`.padStart(2, '0')}`;
            if (month === this.shown)
                return;
            this.shown = month;
            this.zone.run(() => this.monthChange.emit(month));
        },
        dateClick: (arg) => this.zone.run(() => this.dateClick.emit(arg.dateStr.slice(0, 10))),
        eventClick: arg => this.zone.run(() => this.eventClick.emit(arg.event.extendedProps['data'])),
        eventContent: arg => this.render(arg),
    };
    constructor() {
        effect(() => {
            const api = this.calendar()?.getApi();
            if (!api)
                return;
            api.setOption('locale', this.locale() === 'el' ? elLocale : 'en');
            api.setOption('dayMaxEvents', this.maxPerDay());
            const month = this.month();
            if (month && month !== this.shown)
                api.gotoDate(`${month}-01`);
        });
    }
    /** Re-asks `source` for the visible range (after a save or delete). */
    reload() { this.calendar()?.getApi()?.refetchEvents(); }
    /** FullCalendar sizes against a visible container - call when the host becomes visible again. */
    resize() { this.calendar()?.getApi()?.updateSize(); }
    /** FullCalendar builds event bodies as raw DOM outside Angular: the hover buttons hop back into the zone. */
    render(arg) {
        const data = arg.event.extendedProps['data'];
        const wrap = document.createElement('div');
        wrap.className = 'ui-shared-calendar__event';
        const title = document.createElement('span');
        title.className = 'ui-shared-calendar__event-title';
        title.textContent = arg.event.title;
        title.title = arg.event.title;
        wrap.appendChild(title);
        const actions = this.actions();
        if (actions.length) {
            const bar = document.createElement('span');
            bar.className = 'ui-shared-calendar__event-actions';
            for (const a of actions) {
                const btn = document.createElement('button');
                btn.type = 'button';
                btn.className = 'ui-shared-calendar__event-btn';
                btn.title = this.translate(a.labelKey);
                btn.setAttribute('aria-label', btn.title);
                const icon = document.createElement('span');
                icon.className = 'material-icons';
                icon.textContent = a.icon;
                btn.appendChild(icon);
                btn.addEventListener('click', e => {
                    e.stopPropagation();
                    this.zone.run(() => this.eventAction.emit({ action: a.key, data }));
                });
                bar.appendChild(btn);
            }
            wrap.appendChild(bar);
        }
        return { domNodes: [wrap] };
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedCalendarComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.2.0", version: "19.2.25", type: UiSharedCalendarComponent, isStandalone: true, selector: "ui-shared-calendar", inputs: { source: { classPropertyName: "source", publicName: "source", isSignal: true, isRequired: true, transformFunction: null }, actions: { classPropertyName: "actions", publicName: "actions", isSignal: true, isRequired: false, transformFunction: null }, month: { classPropertyName: "month", publicName: "month", isSignal: true, isRequired: false, transformFunction: null }, maxPerDay: { classPropertyName: "maxPerDay", publicName: "maxPerDay", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { monthChange: "monthChange", dateClick: "dateClick", eventClick: "eventClick", eventAction: "eventAction" }, viewQueries: [{ propertyName: "calendar", first: true, predicate: FullCalendarComponent, descendants: true, isSignal: true }], ngImport: i0, template: "<div class=\"ui-shared-calendar\">\n  <full-calendar [options]=\"options\" />\n</div>\n", styles: [":host{display:block;box-sizing:border-box;min-width:0;max-width:100%}.ui-shared-calendar__event{display:flex;align-items:center;width:100%;min-width:0}.ui-shared-calendar__event-title{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.ui-shared-calendar__event-actions{display:inline-flex}.ui-shared-calendar__event-btn{display:inline-flex;align-items:center;justify-content:center;padding:0;cursor:pointer}\n"], dependencies: [{ kind: "ngmodule", type: FullCalendarModule }, { kind: "component", type: i1.FullCalendarComponent, selector: "full-calendar", inputs: ["options", "deepChangeDetection", "events", "eventSources", "resources"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedCalendarComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ui-shared-calendar', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, imports: [FullCalendarModule], template: "<div class=\"ui-shared-calendar\">\n  <full-calendar [options]=\"options\" />\n</div>\n", styles: [":host{display:block;box-sizing:border-box;min-width:0;max-width:100%}.ui-shared-calendar__event{display:flex;align-items:center;width:100%;min-width:0}.ui-shared-calendar__event-title{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.ui-shared-calendar__event-actions{display:inline-flex}.ui-shared-calendar__event-btn{display:inline-flex;align-items:center;justify-content:center;padding:0;cursor:pointer}\n"] }]
        }], ctorParameters: () => [] });

/**
 * Generated bundle index. Do not edit.
 */

export { UiSharedCalendarComponent };
//# sourceMappingURL=borassoft-ui-components-calendar.mjs.map
