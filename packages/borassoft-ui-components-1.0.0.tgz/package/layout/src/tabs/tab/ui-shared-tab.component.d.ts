import { TemplateRef } from '@angular/core';
import * as i0 from "@angular/core";
/**
 * One tab of <ui-shared-tabs>. Its content renders lazily, only while selected.
 * Label: `labelKey` (translated) or `label` (raw text).
 */
export declare class UiSharedTabComponent {
    labelKey: import("@angular/core").InputSignal<string>;
    label: import("@angular/core").InputSignal<string>;
    content: import("@angular/core").Signal<TemplateRef<unknown>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UiSharedTabComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UiSharedTabComponent, "ui-shared-tab", never, { "labelKey": { "alias": "labelKey"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}
//# sourceMappingURL=ui-shared-tab.component.d.ts.map