import { OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { SelectOption } from '@borassoft/ui-components';
import * as i0 from "@angular/core";
/**
 * Year dropdown: the current year ± `range` (default 5). The control holds a number.
 * A stored year outside that window (an old record) is still listed, so the field never shows empty.
 * Typing filters like every ui-shared-select ("202" → 2020…2029); required is read from the control.
 *
 *   <ui-shared-year-select [control]="form.controls.year" labelKey="form.year" />
 *   <ui-shared-year-select [control]="form.controls.year" labelKey="form.year" [range]="10" nullable />
 */
export declare class UiSharedYearSelectComponent implements OnInit {
    control: import("@angular/core").InputSignal<FormControl<number | null>>;
    labelKey: import("@angular/core").InputSignal<string>;
    /** Years offered before and after the current one. */
    range: import("@angular/core").InputSignalWithTransform<number, unknown>;
    nullable: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    hintKey: import("@angular/core").InputSignal<string | undefined>;
    private destroyRef;
    private readonly current;
    /** The control's value, followed so a year loaded later (patchValue) is added to the list. */
    private value;
    readonly years: import("@angular/core").Signal<SelectOption<number>[]>;
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<UiSharedYearSelectComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UiSharedYearSelectComponent, "ui-shared-year-select", never, { "control": { "alias": "control"; "required": true; "isSignal": true; }; "labelKey": { "alias": "labelKey"; "required": true; "isSignal": true; }; "range": { "alias": "range"; "required": false; "isSignal": true; }; "nullable": { "alias": "nullable"; "required": false; "isSignal": true; }; "hintKey": { "alias": "hintKey"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=ui-shared-year-select.component.d.ts.map