import * as i0 from "@angular/core";
/** Small uppercase label that opens a section of <ui-shared-nav-list>. */
export declare class UiSharedNavGroupComponent {
    labelKey: import("@angular/core").InputSignal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UiSharedNavGroupComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UiSharedNavGroupComponent, "ui-shared-nav-group", never, { "labelKey": { "alias": "labelKey"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=ui-shared-nav-group.component.d.ts.map