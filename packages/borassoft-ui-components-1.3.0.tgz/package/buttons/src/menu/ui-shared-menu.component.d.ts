import * as i0 from "@angular/core";
/**
 * Dropdown menu: the trigger is whatever you project into `[slot=trigger]`
 * (a ui-shared-button / icon-button), the rest is the panel content
 * (<ui-shared-menu-item>, <ui-shared-divider>, or custom rows).
 * Arrow / Home / End keys move between the rows, Escape closes.
 *
 *   <ui-shared-menu align="end" (opened)="reload()">
 *     <ui-shared-icon-button slot="trigger" icon="more_vert" tooltipKey="core.grid.rowActions" />
 *     <ui-shared-menu-item icon="edit" labelKey="common.edit" (click)="edit()" />
 *   </ui-shared-menu>
 */
export declare class UiSharedMenuComponent {
    /** Which edge of the trigger the panel aligns to. */
    align: import("@angular/core").InputSignal<"end" | "start">;
    /** Extra class on the overlay panel (for app-level width / layout rules). */
    panelClass: import("@angular/core").InputSignal<string>;
    /** No inner padding (rows carry their own). */
    flush: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    /** Wide panel capped to the viewport, scrolls inside (notification feeds). */
    wide: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    opened: import("@angular/core").OutputEmitterRef<void>;
    closed: import("@angular/core").OutputEmitterRef<void>;
    private panel;
    protected get panelClasses(): string;
    protected onOpened(): void;
    protected onKeydown(event: KeyboardEvent): void;
    private items;
    static ɵfac: i0.ɵɵFactoryDeclaration<UiSharedMenuComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UiSharedMenuComponent, "ui-shared-menu", never, { "align": { "alias": "align"; "required": false; "isSignal": true; }; "panelClass": { "alias": "panelClass"; "required": false; "isSignal": true; }; "flush": { "alias": "flush"; "required": false; "isSignal": true; }; "wide": { "alias": "wide"; "required": false; "isSignal": true; }; }, { "opened": "opened"; "closed": "closed"; }, never, ["[slot=trigger]", "*"], true, never>;
}
//# sourceMappingURL=ui-shared-menu.component.d.ts.map