import * as i0 from "@angular/core";
/**
 * The one file input: a button that opens the native picker and emits the
 * chosen file(s). The hidden `<input type="file">` is reset after each pick so
 * choosing the same file twice still emits.
 *
 *   <ui-shared-file-button labelKey="logo.upload" icon="upload" accept="image/*" (filesSelected)="upload($event[0])" />
 */
export declare class UiSharedFileButtonComponent {
    labelKey: import("@angular/core").InputSignal<string>;
    icon: import("@angular/core").InputSignal<string>;
    /** Native `accept` filter, e.g. `image/*` or `.pdf,.xml`. */
    accept: import("@angular/core").InputSignal<string>;
    multiple: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    disabled: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    variant: import("@angular/core").InputSignal<"flat" | "stroked">;
    color: import("@angular/core").InputSignal<"primary" | "accent" | "warn" | undefined>;
    filesSelected: import("@angular/core").OutputEmitterRef<File[]>;
    protected onChange(el: HTMLInputElement): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<UiSharedFileButtonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UiSharedFileButtonComponent, "ui-shared-file-button", never, { "labelKey": { "alias": "labelKey"; "required": true; "isSignal": true; }; "icon": { "alias": "icon"; "required": false; "isSignal": true; }; "accept": { "alias": "accept"; "required": false; "isSignal": true; }; "multiple": { "alias": "multiple"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "color": { "alias": "color"; "required": false; "isSignal": true; }; }, { "filesSelected": "filesSelected"; }, never, never, true, never>;
}
//# sourceMappingURL=ui-shared-file-button.component.d.ts.map