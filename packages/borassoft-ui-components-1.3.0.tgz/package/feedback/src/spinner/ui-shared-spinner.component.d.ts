import * as i0 from "@angular/core";
/** Indeterminate spinner for inline loading states; `size` in px (default 24). */
export declare class UiSharedSpinnerComponent {
    size: import("@angular/core").InputSignalWithTransform<number, unknown>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UiSharedSpinnerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UiSharedSpinnerComponent, "ui-shared-spinner", never, { "size": { "alias": "size"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=ui-shared-spinner.component.d.ts.map