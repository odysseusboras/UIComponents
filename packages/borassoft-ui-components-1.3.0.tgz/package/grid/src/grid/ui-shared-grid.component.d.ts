import { AfterContentInit, OnInit, TemplateRef } from '@angular/core';
import { OdataSource, SortDirection } from '../odata/odata-source';
import { UiSharedGridColumnComponent } from '../grid-column/ui-shared-grid-column.component';
import * as i0 from "@angular/core";
/**
 * Reusable table view. Columns are declared by projecting
 * <ui-shared-grid-column> children.
 *
 * USER STATE PERSISTED IN LOCALSTORAGE (when [storageKey] is set):
 *   - column WIDTH  per column key (px), set by dragging the right edge
 *     of each header.
 *   - column ORDER, set by dragging a header onto another.
 *   - the current VIEW: applied filter values, page and page size, so a reload
 *     (or coming back to the page) lands on what the user was looking at.
 * All three are restored on init so a logged-in user gets their layout and
 * their view back across sessions. State lives at:
 *     app.coreGrid.<storageKey>.widths   ->  { [key]: number }
 *     app.coreGrid.<storageKey>.order    ->  string[]   (column keys)
 *     app.coreGrid.<storageKey>.view     ->  { page, pageSize, filters: unknown[] }
 *     app.coreGrid.<storageKey>.settings ->  { hidden: string[], pagerTop: boolean }
 *   (hidden columns + "pager above the table", picked in the header gear menu).
 *
 * Sort: clicking a sortable header label cycles none -> asc -> desc -> none.
 * Sort or page-size changes reset to page 1.
 */
export declare class UiSharedGridComponent<T> implements OnInit, AfterContentInit {
    source: import("@angular/core").InputSignal<OdataSource<T>>;
    emptyKey: import("@angular/core").InputSignal<string>;
    initialPageSize: import("@angular/core").InputSignal<number>;
    pageSizeOptions: import("@angular/core").InputSignal<number[]>;
    /** Default sort applied on first load. Matches an OData PascalCase field name. */
    initialSortField: import("@angular/core").InputSignal<string | undefined>;
    /** Default sort direction. Defaults to 'asc' when initialSortField is set. */
    initialSortDir: import("@angular/core").InputSignal<SortDirection>;
    /**
     * Optional storage key — when set, the grid persists per-column widths and
     * order to localStorage so the user's layout is restored across sessions.
     * Pick something unique-per-grid like "admin-companies" / "tenant-contracted".
     */
    storageKey: import("@angular/core").InputSignal<string | undefined>;
    /**
     * When true, the grid renders a leading checkbox column (header = select-all
     * on the current page, per-row = select that row) and a bulk-action bar above
     * the table. Project a <ng-template #bulkActions let-rows> to fill the bar;
     * `rows` is the array of currently-selected rows. Selection is per-page and
     * clears on every fetch (page / filter / sort change or refresh()).
     */
    selectable: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    /**
     * Rows a fetched page starts with ticked (only with `selectable`): every row the predicate
     * accepts is selected as soon as the page arrives. `[preselect]="r => r.status === 'Valid'"`.
     */
    preselect: import("@angular/core").InputSignal<((row: T) => boolean) | null>;
    /**
     * When set, the grid reloads its CURRENT page (filters/sort/paging untouched)
     * every time a SignalR `gridRefresh` signal with a matching key arrives — e.g.
     * "Invoices" so the documents grid updates when a background submit completes.
     */
    refreshKey: import("@angular/core").InputSignal<string | undefined>;
    /** Min / max column width in px when the user drags the resize handle. */
    protected readonly minColWidth = 60;
    protected readonly maxColWidth = 800;
    protected columns: import("@angular/core").Signal<readonly UiSharedGridColumnComponent[]>;
    /** Projected inputs acting as filters (ui-shared-text-input / -select / -segmented). */
    private filters;
    protected hasFilters: import("@angular/core").Signal<boolean>;
    /** Any filter currently applied — shows the Clear button. */
    protected hasActiveFilters: import("@angular/core").Signal<boolean>;
    protected actionsTemplate: import("@angular/core").Signal<TemplateRef<any> | undefined>;
    protected bulkActionsTemplate: import("@angular/core").Signal<TemplateRef<any> | undefined>;
    /**
     * Master-detail: project `<ng-template #detail let-row>` and every row gets a leading
     * expand arrow that opens the template under it (one row's detail at a time per click,
     * several may stay open). Expansion clears on every fetch.
     */
    protected detailTemplate: import("@angular/core").Signal<TemplateRef<any> | undefined>;
    protected expanded: import("@angular/core").WritableSignal<Set<T>>;
    protected isExpanded(row: T): boolean;
    protected toggleExpanded(row: T): void;
    /** Columns a detail row spans: arrow + checkbox + visible + actions. */
    protected detailSpan: import("@angular/core").Signal<number>;
    /** Rows are clickable (→ {@link rowClick}) only when the grid declares a per-row
     *  action menu (open/edit). Clicks on the checkbox or actions cell don't count. */
    protected interactive: import("@angular/core").Signal<boolean>;
    /** Emitted when an interactive row is clicked — wire it to open the detail
     *  page / side panel for that row. */
    rowClick: import("@angular/core").OutputEmitterRef<T>;
    /** Enter on the focused ROW opens it; Enter inside a cell control (checkbox, ⋮ menu) must not. */
    protected onRowKeyEnter(ev: Event, row: T): void;
    protected rows: import("@angular/core").WritableSignal<T[]>;
    protected total: import("@angular/core").WritableSignal<number>;
    protected loading: import("@angular/core").WritableSignal<boolean>;
    /** False until the first fetch resolves — the only time the spinner replaces the table. */
    protected loaded: import("@angular/core").WritableSignal<boolean>;
    protected selected: import("@angular/core").WritableSignal<T[]>;
    protected page: import("@angular/core").WritableSignal<number>;
    protected pageSize: import("@angular/core").WritableSignal<number>;
    protected sortField: import("@angular/core").WritableSignal<string | null>;
    protected sortDir: import("@angular/core").WritableSignal<SortDirection | null>;
    protected widths: import("@angular/core").WritableSignal<Record<string, number>>;
    protected order: import("@angular/core").WritableSignal<string[] | null>;
    /** Column keys the user hid from the settings menu. */
    protected hidden: import("@angular/core").WritableSignal<string[]>;
    /** Pager rendered above the table (as well as below) so paging needs no scroll. */
    protected pagerTop: import("@angular/core").WritableSignal<boolean>;
    /** Rendered columns: the user's order minus the hidden ones (the last visible column can't be hidden). */
    protected visibleColumns: import("@angular/core").Signal<UiSharedGridColumnComponent[]>;
    protected isHidden(col: UiSharedGridColumnComponent): boolean;
    protected toggleColumn(col: UiSharedGridColumnComponent, visible: boolean): void;
    protected setPagerTop(on: boolean): void;
    /** Columns in the (possibly user-reordered) order to render. */
    protected orderedColumns: import("@angular/core").Signal<UiSharedGridColumnComponent[]>;
    private zone;
    private stopResize;
    private refreshSignals;
    /** Every fetch goes through here so a newer request cancels the in-flight one
     *  (switchMap) — a slow earlier page can never overwrite a later one. */
    private queries$;
    constructor();
    ngOnInit(): void;
    ngAfterContentInit(): void;
    refresh(): void;
    protected anySelected: import("@angular/core").Signal<boolean>;
    protected allOnPageSelected: import("@angular/core").Signal<boolean>;
    protected isSelected(row: T): boolean;
    protected toggleRow(row: T, checked: boolean): void;
    protected toggleAll(checked: boolean): void;
    /** Public so consumers can drop the selection after a bulk action. */
    clearSelection(): void;
    reset(): void;
    protected onPage(p: number): void;
    protected onPageSize(size: number): void;
    protected onHeaderClick(col: UiSharedGridColumnComponent): void;
    protected sortIconFor(col: UiSharedGridColumnComponent): string;
    protected ariaSortFor(col: UiSharedGridColumnComponent): string | null;
    protected onSearch(): void;
    protected onClearFilters(): void;
    protected widthFor(col: UiSharedGridColumnComponent): string | null;
    /** Pointer down on a column's resize handle. */
    protected startResize(ev: PointerEvent, col: UiSharedGridColumnComponent, thEl: HTMLElement): void;
    private setWidth;
    private clampWidth;
    protected onDragStart(ev: DragEvent, col: UiSharedGridColumnComponent): void;
    protected onDragOver(ev: DragEvent): void;
    protected onDrop(ev: DragEvent, target: UiSharedGridColumnComponent): void;
    private settingsKey;
    private widthsKey;
    private orderKey;
    private viewKey;
    /** The view the user is looking at — written on every fetch, with the clause that fetch used. */
    private persistView;
    /**
     * Puts the remembered filters + paging back before the first fetch. Filters
     * are matched BY POSITION, so a template that has since gained or lost one is
     * treated as a different view and its values are dropped rather than landing
     * on the wrong input. A page past the end self-heals: the fetch falls back to
     * the last page.
     */
    private restoreView;
    /**
     * The remembered OData clause, used for the FIRST fetch only. A restored
     * filter cannot always build its own clause yet — a select compares the value
     * against its options, which may still be loading — so without this the grid
     * would load unfiltered and then correct itself with a second request. Cleared
     * once used; every later fetch reads the live filters.
     */
    private restoredClause;
    private persistSettings;
    private restoreLayout;
    private persistLayout;
    /**
     * Settings menu -> "Reset to default". Wipes any user-driven column
     * customisation (widths from drag-resize + order from drag-reorder) AND the
     * persisted localStorage entries, so the grid renders with its declared
     * columns at their default widths.
     */
    protected resetLayout(): void;
    /** True when the user has any persisted/in-memory layout customisation. */
    protected hasLayoutChanges: import("@angular/core").Signal<boolean>;
    private fetchFirstPage;
    private fetch;
    static ɵfac: i0.ɵɵFactoryDeclaration<UiSharedGridComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UiSharedGridComponent<any>, "ui-shared-grid", never, { "source": { "alias": "source"; "required": true; "isSignal": true; }; "emptyKey": { "alias": "emptyKey"; "required": false; "isSignal": true; }; "initialPageSize": { "alias": "initialPageSize"; "required": false; "isSignal": true; }; "pageSizeOptions": { "alias": "pageSizeOptions"; "required": false; "isSignal": true; }; "initialSortField": { "alias": "initialSortField"; "required": false; "isSignal": true; }; "initialSortDir": { "alias": "initialSortDir"; "required": false; "isSignal": true; }; "storageKey": { "alias": "storageKey"; "required": false; "isSignal": true; }; "selectable": { "alias": "selectable"; "required": false; "isSignal": true; }; "preselect": { "alias": "preselect"; "required": false; "isSignal": true; }; "refreshKey": { "alias": "refreshKey"; "required": false; "isSignal": true; }; }, { "rowClick": "rowClick"; }, ["columns", "filters", "actionsTemplate", "bulkActionsTemplate", "detailTemplate"], ["ui-shared-text-input, ui-shared-select, ui-shared-segmented", "[slot=empty-actions]"], true, never>;
}
//# sourceMappingURL=ui-shared-grid.component.d.ts.map