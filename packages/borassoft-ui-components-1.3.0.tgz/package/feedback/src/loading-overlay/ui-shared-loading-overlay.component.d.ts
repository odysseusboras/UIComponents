import { UiLoadingService } from './loading.service';
import * as i0 from "@angular/core";
/**
 * App-wide loading overlay shown while `UiLoadingService` reports pending work.
 * A slim progress bar slides across the top and a small floating card holds an
 * animated ring; pointer input is blocked so the user can't fire conflicting
 * actions until the request settles. Mount it once, in the root component.
 */
export declare class UiSharedLoadingOverlayComponent {
    protected loading: UiLoadingService;
    static ɵfac: i0.ɵɵFactoryDeclaration<UiSharedLoadingOverlayComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UiSharedLoadingOverlayComponent, "ui-shared-loading-overlay", never, {}, {}, never, never, true, never>;
}
//# sourceMappingURL=ui-shared-loading-overlay.component.d.ts.map