/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@borassoft/ui-components/feedback" />
export * from './public-api';
//# sourceMappingURL=borassoft-ui-components-feedback.d.ts.map