import * as i0 from "@angular/core";
/**
 * The action row: wraps buttons with a uniform gap, wraps on narrow screens.
 * `align` end (default: form actions), start (inline toolbars), between (back + actions),
 * center (empty states). `divided` adds the top rule + spacing of a form footer.
 *
 *   <ui-shared-button-group divided>
 *     <ui-shared-button variant="secondary" labelKey="common.cancel" (click)="close()" />
 *     <ui-shared-button variant="primary" labelKey="common.save" (click)="save()" />
 *   </ui-shared-button-group>
 */
export declare class UiSharedButtonGroupComponent {
    align: import("@angular/core").InputSignal<"end" | "start" | "between" | "center">;
    divided: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    /** Vertical list of full-width buttons (auth cards). */
    stack: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UiSharedButtonGroupComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UiSharedButtonGroupComponent, "ui-shared-button-group", never, { "align": { "alias": "align"; "required": false; "isSignal": true; }; "divided": { "alias": "divided"; "required": false; "isSignal": true; }; "stack": { "alias": "stack"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}
//# sourceMappingURL=ui-shared-button-group.component.d.ts.map