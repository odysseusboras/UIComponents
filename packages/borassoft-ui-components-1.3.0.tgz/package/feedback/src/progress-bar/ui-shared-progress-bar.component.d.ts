import * as i0 from "@angular/core";
/** Thin loading bar: indeterminate by default, determinate when `value` (0-100) is set. */
export declare class UiSharedProgressBarComponent {
    value: import("@angular/core").InputSignalWithTransform<number | null, unknown>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UiSharedProgressBarComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UiSharedProgressBarComponent, "ui-shared-progress-bar", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=ui-shared-progress-bar.component.d.ts.map