import * as i0 from "@angular/core";
/**
 * Standard page header — title (h1) + optional lede line + optional back link.
 *
 * Two ways to provide content:
 *   - translation KEYS (preferred for static labels) via `titleKey` / `ledeKey`
 *   - literal STRINGS (for dynamic content like an entity name) via `titleText` / `ledeText`
 *
 * Translation keys win when both are set:
 *
 *   <ui-shared-page-header titleKey="admin.companies.title" ledeKey="admin.companies.lede" />
 *
 *   <ui-shared-page-header [titleText]="company.friendlyName"
 *                   [ledeText]="company.country + ' · VAT: ' + company.vat"
 *                   [backLink]="['..']" backKey="admin.companies.title" />
 *
 * The breadcrumb trail (`provideUiBreadcrumbs`) renders above the title on every page; the
 * current page's crumb is this title, and the back link is dropped while a trail shows. Set
 * `breadcrumb="false"` to leave it out.
 *
 * Detail pages set `backLink` (a routerLink value) to render a small
 * "← Back" link above the title; set `(back)` instead (with no `backLink`)
 * for an imperative handler. Project content into `[slot=actions]` for
 * page-level actions.
 */
export declare class UiSharedPageHeaderComponent {
    /** Translation key for the page title. Wins over titleText. */
    titleKey: import("@angular/core").InputSignal<string>;
    /** Literal title text (e.g. an entity name). Used only when titleKey is empty. */
    titleText: import("@angular/core").InputSignal<string>;
    /** Translation key for the lede paragraph. Wins over ledeText. */
    ledeKey: import("@angular/core").InputSignal<string>;
    /** Literal lede text. Used only when ledeKey is empty. */
    ledeText: import("@angular/core").InputSignal<string>;
    /** routerLink target for the back link. `null` + a `(back)` listener renders a button instead. */
    backLink: import("@angular/core").InputSignal<string | any[] | null>;
    /** Translation key for the back link label. */
    backKey: import("@angular/core").InputSignal<string>;
    /** Force the back control on (as a button) even without a `backLink`. */
    showBack: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    /** Whether the [slot=actions] projection should be rendered. */
    showActions: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    /** Emitted when the back BUTTON (no `backLink`) is clicked. */
    back: import("@angular/core").OutputEmitterRef<void>;
    /** Render the breadcrumb trail above the title (when the app registered a tree). */
    breadcrumb: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    private translate;
    private trail;
    /** The back link is the trail's job once a trail renders; it stays for pages outside the tree. */
    protected hasBack: import("@angular/core").Signal<boolean>;
    protected titleLabel: import("@angular/core").Signal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UiSharedPageHeaderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UiSharedPageHeaderComponent, "ui-shared-page-header", never, { "titleKey": { "alias": "titleKey"; "required": false; "isSignal": true; }; "titleText": { "alias": "titleText"; "required": false; "isSignal": true; }; "ledeKey": { "alias": "ledeKey"; "required": false; "isSignal": true; }; "ledeText": { "alias": "ledeText"; "required": false; "isSignal": true; }; "backLink": { "alias": "backLink"; "required": false; "isSignal": true; }; "backKey": { "alias": "backKey"; "required": false; "isSignal": true; }; "showBack": { "alias": "showBack"; "required": false; "isSignal": true; }; "showActions": { "alias": "showActions"; "required": false; "isSignal": true; }; "breadcrumb": { "alias": "breadcrumb"; "required": false; "isSignal": true; }; }, { "back": "back"; }, never, ["[slot=actions]"], true, never>;
}
//# sourceMappingURL=ui-shared-page-header.component.d.ts.map