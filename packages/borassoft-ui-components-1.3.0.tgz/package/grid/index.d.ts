/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@borassoft/ui-components/grid" />
export * from './public-api';
//# sourceMappingURL=borassoft-ui-components-grid.d.ts.map