import { NgZone } from '@angular/core';
/**
 * Follows a pointer drag (column / panel resize): `onMove` runs inside the zone
 * for every move, `onEnd` once when the pointer is released or cancelled. While
 * dragging, `body` carries `ui-resizing` so the host can force the resize cursor.
 * Returns a stop function — call it on destroy so a drag never outlives its component.
 */
export declare function trackPointerDrag(zone: NgZone, onMove: (e: PointerEvent) => void, onEnd?: () => void): () => void;
//# sourceMappingURL=pointer-drag.d.ts.map