import { FormControl } from '@angular/forms';
import { SubscriptSizing } from '@angular/material/form-field';
import { ClauseBuilder, GridFilterState, firstError } from '@borassoft/ui-components';
import * as i0 from "@angular/core";
export type TextInputType = 'text' | 'email' | 'number' | 'tel' | 'url' | 'search' | 'time' | 'date';
/**
 * The one single-line input: text, email, number, tel, url. Takes the
 * FormControl directly; the label / hint / errors are translation keys
 * resolved through UI_TRANSLATE. Project `[suffix]` / `[prefix]` content for
 * icons, buttons or unit text.
 *
 * Inside `<ui-shared-grid>` with `[fields]` it is a free-text grid filter
 * (`contains` on any of the fields; Enter runs the grid's Search):
 *
 *   <ui-shared-text-input labelKey="users.search" [fields]="['Name','Email']" />
 *
 *   <ui-shared-text-input [control]="form.controls.name" labelKey="form.name" maxlength="200" />
 *   <ui-shared-text-input [control]="form.controls.amount" labelKey="form.amount" type="number" min="0" step="0.01">
 *     <span suffix>€</span>
 *   </ui-shared-text-input>
 */
export declare class UiSharedTextInputComponent {
    /** Optional when used as a grid filter. */
    control: import("@angular/core").InputSignal<FormControl<any> | null>;
    labelKey: import("@angular/core").InputSignal<string>;
    type: import("@angular/core").InputSignal<TextInputType>;
    hintKey: import("@angular/core").InputSignal<string>;
    /** Already translated hint text — for hints built at runtime. */
    hintText: import("@angular/core").InputSignal<string>;
    placeholderKey: import("@angular/core").InputSignal<string>;
    maxlength: import("@angular/core").InputSignal<string | number | null>;
    min: import("@angular/core").InputSignal<string | number | null>;
    max: import("@angular/core").InputSignal<string | number | null>;
    step: import("@angular/core").InputSignal<string | number | null>;
    inputMode: import("@angular/core").InputSignal<string>;
    autocomplete: import("@angular/core").InputSignal<string>;
    readonly: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    subscriptSizing: import("@angular/core").InputSignal<SubscriptSizing>;
    /** Grid filter: OData fields matched with `contains`. */
    fields: import("@angular/core").InputSignal<string[]>;
    /** Grid filter: custom clause for the typed text (overrides `fields`). */
    clauseBuilder: import("@angular/core").InputSignal<ClauseBuilder<string> | null>;
    private own;
    protected ctrl: import("@angular/core").Signal<FormControl<any>>;
    readonly filter: GridFilterState<string>;
    protected readonly firstError: typeof firstError;
    protected required: import("@angular/core").Signal<boolean>;
    private containsAny;
    static ɵfac: i0.ɵɵFactoryDeclaration<UiSharedTextInputComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UiSharedTextInputComponent, "ui-shared-text-input", never, { "control": { "alias": "control"; "required": false; "isSignal": true; }; "labelKey": { "alias": "labelKey"; "required": true; "isSignal": true; }; "type": { "alias": "type"; "required": false; "isSignal": true; }; "hintKey": { "alias": "hintKey"; "required": false; "isSignal": true; }; "hintText": { "alias": "hintText"; "required": false; "isSignal": true; }; "placeholderKey": { "alias": "placeholderKey"; "required": false; "isSignal": true; }; "maxlength": { "alias": "maxlength"; "required": false; "isSignal": true; }; "min": { "alias": "min"; "required": false; "isSignal": true; }; "max": { "alias": "max"; "required": false; "isSignal": true; }; "step": { "alias": "step"; "required": false; "isSignal": true; }; "inputMode": { "alias": "inputMode"; "required": false; "isSignal": true; }; "autocomplete": { "alias": "autocomplete"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "subscriptSizing": { "alias": "subscriptSizing"; "required": false; "isSignal": true; }; "fields": { "alias": "fields"; "required": false; "isSignal": true; }; "clauseBuilder": { "alias": "clauseBuilder"; "required": false; "isSignal": true; }; }, {}, never, ["[prefix]", "[suffix]"], true, never>;
}
//# sourceMappingURL=ui-shared-text-input.component.d.ts.map