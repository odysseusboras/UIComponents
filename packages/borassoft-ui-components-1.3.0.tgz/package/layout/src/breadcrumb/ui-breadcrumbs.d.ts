import { InjectionToken, Provider } from '@angular/core';
import { Params } from '@angular/router';
/**
 * One node of the app's breadcrumb tree. `path` is one URL segment (static, or `:param`);
 * a node without a label shows the page title of the page that renders there.
 *
 *   provideUiBreadcrumbs([
 *     { path: 'admin', labelKey: 'admin.title', children: [
 *       { path: 'companies', labelKey: 'admin.companies.title', children: [{ path: ':id' }] },
 *     ] },
 *   ])
 */
export interface UiBreadcrumbNode {
    path: string;
    labelKey?: string;
    /** Dynamic label from the matched params (e.g. the VAT segment). */
    label?: (params: Params) => string;
    /** Where the crumb links to when it is not the current page; defaults to its own URL. */
    redirect?: string;
    children?: UiBreadcrumbNode[];
}
export interface UiBreadcrumb {
    labelKey?: string;
    label?: string;
    url: string;
    last: boolean;
}
export declare const UI_BREADCRUMBS: InjectionToken<UiBreadcrumbNode[]>;
export declare function provideUiBreadcrumbs(nodes: UiBreadcrumbNode[]): Provider;
/** Walks the URL through the tree: static paths win over `:param` ones; stops at the first segment nothing matches. */
export declare function resolveUiBreadcrumbs(nodes: UiBreadcrumbNode[], url: string): UiBreadcrumb[];
//# sourceMappingURL=ui-breadcrumbs.d.ts.map