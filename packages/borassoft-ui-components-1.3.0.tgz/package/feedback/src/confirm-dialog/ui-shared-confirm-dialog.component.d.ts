import { MatDialogRef } from '@angular/material/dialog';
import * as i0 from "@angular/core";
/**
 * Inputs for the shared confirm dialog. Pass translation keys (preferred)
 * or literal strings via the *Text fallbacks. The buttons are always
 * "No" / "Yes" so the title + message must make the action unambiguous.
 */
export interface ConfirmDialogData {
    titleKey?: string;
    titleText?: string;
    messageKey?: string;
    messageText?: string;
    confirmKey?: string;
    cancelKey?: string;
    /** Drives only the icon ("warn" = warning, "primary" = question); the Yes button is always primary. */
    variant?: 'warn' | 'primary';
}
/**
 * Generic Yes / No dialog. Never open it directly — go through
 * `UiConfirmService.confirm(data)` so every confirmation looks and behaves
 * identically.
 */
export declare class UiSharedConfirmDialogComponent {
    protected ref: MatDialogRef<UiSharedConfirmDialogComponent, boolean>;
    protected data: ConfirmDialogData;
    protected get confirmKey(): string;
    protected get cancelKey(): string;
    protected get variant(): "warn" | "primary";
    confirm(): void;
    cancel(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<UiSharedConfirmDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UiSharedConfirmDialogComponent, "ui-shared-confirm-dialog", never, {}, {}, never, never, true, never>;
}
//# sourceMappingURL=ui-shared-confirm-dialog.component.d.ts.map