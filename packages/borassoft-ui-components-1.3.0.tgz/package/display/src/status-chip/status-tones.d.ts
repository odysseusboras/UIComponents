export type StatusTone = 'ok' | 'warn' | 'bad' | 'info' | 'muted';
/** Soft-delete flag → chip tone (Active → ok, Deleted → bad). */
export declare function activeTone(isDeleted: boolean | null | undefined): StatusTone;
//# sourceMappingURL=status-tones.d.ts.map