import * as i0 from "@angular/core";
/** Hairline rule between sections or menu groups; `vertical` for toolbars. */
export declare class UiSharedDividerComponent {
    vertical: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UiSharedDividerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UiSharedDividerComponent, "ui-shared-divider", never, { "vertical": { "alias": "vertical"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=ui-shared-divider.component.d.ts.map