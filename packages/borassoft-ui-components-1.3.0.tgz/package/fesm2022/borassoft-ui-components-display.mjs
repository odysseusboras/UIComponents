import * as i0 from '@angular/core';
import { input, booleanAttribute, ChangeDetectionStrategy, Component, inject, computed } from '@angular/core';
import * as i1 from '@angular/material/icon';
import { MatIconModule } from '@angular/material/icon';
import * as i2 from '@angular/material/tooltip';
import { MatTooltipModule } from '@angular/material/tooltip';
import { NgTemplateOutlet, DatePipe } from '@angular/common';
import { RouterLink } from '@angular/router';
import * as i2$1 from '@angular/material/progress-spinner';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { UI_LOCALE, UI_DATE_FORMAT } from '@borassoft/ui-components';
import { DomSanitizer } from '@angular/platform-browser';
import qrcode from 'qrcode-generator';
import * as i2$2 from '@angular/material/badge';
import { MatBadgeModule } from '@angular/material/badge';

/**
 * The one status/state pill, so every grid, detail page and drawer renders
 * state identically.
 *
 *   <ui-shared-status-chip [tone]="activeTone(row.isDeleted)" icon="check_circle">
 *     {{ 'documents.status.submitted' | uiTranslate }}
 *   </ui-shared-status-chip>
 *
 *   <ui-shared-status-chip tone="bad" dot size="lg" [tooltip]="row.errorMessage">…</ui-shared-status-chip>
 */
class UiSharedStatusChipComponent {
    tone = input('muted');
    /** Optional leading Material icon name. */
    icon = input('');
    /** Leading state dot instead of an icon. */
    dot = input(false, { transform: booleanAttribute });
    size = input('sm');
    /** Tooltip text (already translated). Adds `cursor: help`. */
    tooltip = input('');
    /** Transparent fill with a tinted border. */
    outline = input(false, { transform: booleanAttribute });
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedStatusChipComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: UiSharedStatusChipComponent, isStandalone: true, selector: "ui-shared-status-chip", inputs: { tone: { classPropertyName: "tone", publicName: "tone", isSignal: true, isRequired: false, transformFunction: null }, icon: { classPropertyName: "icon", publicName: "icon", isSignal: true, isRequired: false, transformFunction: null }, dot: { classPropertyName: "dot", publicName: "dot", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, tooltip: { classPropertyName: "tooltip", publicName: "tooltip", isSignal: true, isRequired: false, transformFunction: null }, outline: { classPropertyName: "outline", publicName: "outline", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: "<span class=\"ui-shared-status-chip\"\n      [class.ui-shared-status-chip--ok]=\"tone() === 'ok'\"\n      [class.ui-shared-status-chip--warn]=\"tone() === 'warn'\"\n      [class.ui-shared-status-chip--bad]=\"tone() === 'bad'\"\n      [class.ui-shared-status-chip--info]=\"tone() === 'info'\"\n      [class.ui-shared-status-chip--muted]=\"tone() === 'muted'\"\n      [class.ui-shared-status-chip--lg]=\"size() === 'lg'\"\n      [class.ui-shared-status-chip--outline]=\"outline()\"\n      [class.ui-shared-status-chip--help]=\"!!tooltip()\"\n      [matTooltip]=\"tooltip()\"\n      [matTooltipDisabled]=\"!tooltip()\">\n  @if (dot()) {\n    <span class=\"ui-shared-status-chip__dot\" aria-hidden=\"true\"></span>\n  } @else if (icon()) {\n    <mat-icon aria-hidden=\"true\">{{ icon() }}</mat-icon>\n  }\n  <ng-content></ng-content>\n</span>\n", styles: [":host{display:inline-flex;box-sizing:border-box;min-width:0;max-width:100%}:host{vertical-align:middle}.ui-shared-status-chip{display:inline-flex;align-items:center;white-space:nowrap;vertical-align:middle}.ui-shared-status-chip--help{cursor:help}\n"], dependencies: [{ kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i1.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "directive", type: i2.MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedStatusChipComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ui-shared-status-chip', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, imports: [MatIconModule, MatTooltipModule], template: "<span class=\"ui-shared-status-chip\"\n      [class.ui-shared-status-chip--ok]=\"tone() === 'ok'\"\n      [class.ui-shared-status-chip--warn]=\"tone() === 'warn'\"\n      [class.ui-shared-status-chip--bad]=\"tone() === 'bad'\"\n      [class.ui-shared-status-chip--info]=\"tone() === 'info'\"\n      [class.ui-shared-status-chip--muted]=\"tone() === 'muted'\"\n      [class.ui-shared-status-chip--lg]=\"size() === 'lg'\"\n      [class.ui-shared-status-chip--outline]=\"outline()\"\n      [class.ui-shared-status-chip--help]=\"!!tooltip()\"\n      [matTooltip]=\"tooltip()\"\n      [matTooltipDisabled]=\"!tooltip()\">\n  @if (dot()) {\n    <span class=\"ui-shared-status-chip__dot\" aria-hidden=\"true\"></span>\n  } @else if (icon()) {\n    <mat-icon aria-hidden=\"true\">{{ icon() }}</mat-icon>\n  }\n  <ng-content></ng-content>\n</span>\n", styles: [":host{display:inline-flex;box-sizing:border-box;min-width:0;max-width:100%}:host{vertical-align:middle}.ui-shared-status-chip{display:inline-flex;align-items:center;white-space:nowrap;vertical-align:middle}.ui-shared-status-chip--help{cursor:help}\n"] }]
        }] });

/** Soft-delete flag → chip tone (Active → ok, Deleted → bad). */
function activeTone(isDeleted) {
    return isDeleted ? 'bad' : 'ok';
}

/**
 * The one KPI tile (overview stats, summaries): icon + label + value, optional
 * tinted tone, optional link. Project extra lines as content; they render
 * under the value in the muted sub style.
 *
 *   <ui-shared-stat-tile icon="trending_up" [label]="'dashboard.income' | uiTranslate"
 *                 [value]="(d.income.totalGross | number:'1.2-2') + ' €'" [link]="documentsLink()">
 *     {{ 'dashboard.net' | uiTranslate }} {{ d.income.totalNet | number:'1.2-2' }}
 *   </ui-shared-stat-tile>
 */
class UiSharedStatTileComponent {
    icon = input.required();
    /** Already translated. */
    label = input.required();
    /** Already formatted; ignored while `loading`, shows an em dash when empty. */
    value = input(null);
    loading = input(false, { transform: booleanAttribute });
    /** Tints the icon and the value. */
    tone = input('');
    link = input(null);
    queryParams = input(null);
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedStatTileComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: UiSharedStatTileComponent, isStandalone: true, selector: "ui-shared-stat-tile", inputs: { icon: { classPropertyName: "icon", publicName: "icon", isSignal: true, isRequired: true, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: true, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, loading: { classPropertyName: "loading", publicName: "loading", isSignal: true, isRequired: false, transformFunction: null }, tone: { classPropertyName: "tone", publicName: "tone", isSignal: true, isRequired: false, transformFunction: null }, link: { classPropertyName: "link", publicName: "link", isSignal: true, isRequired: false, transformFunction: null }, queryParams: { classPropertyName: "queryParams", publicName: "queryParams", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: "<ng-template #body>\n  <div class=\"ui-shared-stat-tile__icon\" [attr.data-tone]=\"tone() || null\"><mat-icon>{{ icon() }}</mat-icon></div>\n  <div class=\"ui-shared-stat-tile__body\">\n    <div class=\"ui-shared-stat-tile__label\">{{ label() }}</div>\n    <div class=\"ui-shared-stat-tile__value\" [attr.data-tone]=\"tone() || null\">\n      @if (loading()) {\n        <mat-progress-spinner mode=\"indeterminate\" diameter=\"20\" />\n      } @else if (value() !== null && value() !== undefined && value() !== '') {\n        {{ value() }}\n      } @else {\n        <span class=\"ui-shared-stat-tile__empty\">\u2014</span>\n      }\n    </div>\n    @if (!loading()) {\n      <div class=\"ui-shared-stat-tile__sub\"><ng-content /></div>\n    }\n  </div>\n  @if (link()) {\n    <mat-icon class=\"ui-shared-stat-tile__arrow\">chevron_right</mat-icon>\n  }\n</ng-template>\n\n@if (link(); as l) {\n  <a class=\"ui-shared-stat-tile\" [routerLink]=\"l\" [queryParams]=\"queryParams()\">\n    <ng-container [ngTemplateOutlet]=\"body\" />\n  </a>\n} @else {\n  <div class=\"ui-shared-stat-tile ui-shared-stat-tile--static\">\n    <ng-container [ngTemplateOutlet]=\"body\" />\n  </div>\n}\n", styles: [":host{display:block;box-sizing:border-box;min-width:0;max-width:100%}.ui-shared-stat-tile{display:grid;grid-template-columns:auto 1fr auto;align-items:center;height:100%;text-decoration:none;color:inherit}.ui-shared-stat-tile__icon{display:grid;place-items:center}.ui-shared-stat-tile__body{display:flex;flex-direction:column;min-width:0}.ui-shared-stat-tile__value{display:flex;align-items:center}.ui-shared-stat-tile__sub:empty{display:none}\n"], dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i1.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatProgressSpinnerModule }, { kind: "component", type: i2$1.MatProgressSpinner, selector: "mat-progress-spinner, mat-spinner", inputs: ["color", "mode", "value", "diameter", "strokeWidth"], exportAs: ["matProgressSpinner"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedStatTileComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ui-shared-stat-tile', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, imports: [NgTemplateOutlet, RouterLink, MatIconModule, MatProgressSpinnerModule], template: "<ng-template #body>\n  <div class=\"ui-shared-stat-tile__icon\" [attr.data-tone]=\"tone() || null\"><mat-icon>{{ icon() }}</mat-icon></div>\n  <div class=\"ui-shared-stat-tile__body\">\n    <div class=\"ui-shared-stat-tile__label\">{{ label() }}</div>\n    <div class=\"ui-shared-stat-tile__value\" [attr.data-tone]=\"tone() || null\">\n      @if (loading()) {\n        <mat-progress-spinner mode=\"indeterminate\" diameter=\"20\" />\n      } @else if (value() !== null && value() !== undefined && value() !== '') {\n        {{ value() }}\n      } @else {\n        <span class=\"ui-shared-stat-tile__empty\">\u2014</span>\n      }\n    </div>\n    @if (!loading()) {\n      <div class=\"ui-shared-stat-tile__sub\"><ng-content /></div>\n    }\n  </div>\n  @if (link()) {\n    <mat-icon class=\"ui-shared-stat-tile__arrow\">chevron_right</mat-icon>\n  }\n</ng-template>\n\n@if (link(); as l) {\n  <a class=\"ui-shared-stat-tile\" [routerLink]=\"l\" [queryParams]=\"queryParams()\">\n    <ng-container [ngTemplateOutlet]=\"body\" />\n  </a>\n} @else {\n  <div class=\"ui-shared-stat-tile ui-shared-stat-tile--static\">\n    <ng-container [ngTemplateOutlet]=\"body\" />\n  </div>\n}\n", styles: [":host{display:block;box-sizing:border-box;min-width:0;max-width:100%}.ui-shared-stat-tile{display:grid;grid-template-columns:auto 1fr auto;align-items:center;height:100%;text-decoration:none;color:inherit}.ui-shared-stat-tile__icon{display:grid;place-items:center}.ui-shared-stat-tile__body{display:flex;flex-direction:column;min-width:0}.ui-shared-stat-tile__value{display:flex;align-items:center}.ui-shared-stat-tile__sub:empty{display:none}\n"] }]
        }] });

/**
 * Single source of truth for rendering ANY date.
 *
 *   <ui-shared-display-date [value]="row.dateCreated" />
 *   <ui-shared-display-date [value]="row.dateCreated" empty="never" />
 *
 * ONE format app-wide, from `UI_DATE_FORMAT` (default `dd/MM/yyyy, HH:mm`),
 * rendered in the locale `UI_LOCALE` returns. The `mode` input is accepted
 * but IGNORED so existing `mode="date"` call sites keep working. Because the
 * locale is read inside a computed, a host whose `UI_LOCALE` reads a signal
 * gets a re-render on language change.
 */
class UiSharedDisplayDateComponent {
    /** The date to render. Accepts ISO-8601 strings (the wire format), Date, number, null, undefined. */
    value = input(null);
    /** Accepted but IGNORED — there is one format (date + time). Kept so existing call sites don't break. */
    mode = input('datetime');
    /** What to render when the value is null/empty. Defaults to an em-dash. */
    empty = input('—');
    locale = inject(UI_LOCALE);
    format = inject(UI_DATE_FORMAT);
    /** NULL when the value can't be rendered — the template branches to the [empty] rendering. */
    formatted = computed(() => {
        const v = this.value();
        if (v === null || v === undefined || v === '')
            return null;
        // DatePipe throws on text it can't parse; a bad value shows as empty, not a broken page.
        try {
            return new DatePipe(this.locale()).transform(v, this.format);
        }
        catch {
            return null;
        }
    });
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedDisplayDateComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: UiSharedDisplayDateComponent, isStandalone: true, selector: "ui-shared-display-date", inputs: { value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, mode: { classPropertyName: "mode", publicName: "mode", isSignal: true, isRequired: false, transformFunction: null }, empty: { classPropertyName: "empty", publicName: "empty", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: "@if (formatted(); as text) {\n  <span class=\"ui-shared-display-date\">{{ text }}</span>\n} @else {\n  <span class=\"ui-shared-display-date ui-shared-display-date--empty\">{{ empty() }}</span>\n}\n", styles: [":host{display:inline;box-sizing:border-box;min-width:0;max-width:100%}.ui-shared-display-date{white-space:nowrap}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedDisplayDateComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ui-shared-display-date', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: "@if (formatted(); as text) {\n  <span class=\"ui-shared-display-date\">{{ text }}</span>\n} @else {\n  <span class=\"ui-shared-display-date ui-shared-display-date--empty\">{{ empty() }}</span>\n}\n", styles: [":host{display:inline;box-sizing:border-box;min-width:0;max-width:100%}.ui-shared-display-date{white-space:nowrap}\n"] }]
        }] });

/**
 * Renders a string (e.g. a verification URL) as an actual QR code. Pure
 * client-side, zero network: qrcode-generator builds a scalable SVG that fills
 * the host box (size it from the parent).
 */
class UiSharedQrCodeComponent {
    /** The payload to encode. */
    value = input.required();
    sanitizer = inject(DomSanitizer);
    svg = computed(() => {
        const v = this.value();
        if (!v)
            return '';
        const qr = qrcode(0, 'M');
        qr.addData(v);
        qr.make();
        return this.sanitizer.bypassSecurityTrustHtml(qr.createSvgTag({ scalable: true, margin: 0 }));
    });
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedQrCodeComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "19.2.25", type: UiSharedQrCodeComponent, isStandalone: true, selector: "ui-shared-qr-code", inputs: { value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: true, transformFunction: null } }, ngImport: i0, template: "<div class=\"ui-shared-qr-code\" [innerHTML]=\"svg()\"></div>\n", styles: [":host{display:inline-block;box-sizing:border-box;min-width:0;max-width:100%}:host{line-height:0}.ui-shared-qr-code{width:100%;height:100%}\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedQrCodeComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ui-shared-qr-code', standalone: true, template: "<div class=\"ui-shared-qr-code\" [innerHTML]=\"svg()\"></div>\n", styles: [":host{display:inline-block;box-sizing:border-box;min-width:0;max-width:100%}:host{line-height:0}.ui-shared-qr-code{width:100%;height:100%}\n"] }]
        }] });

/**
 * A Material Symbols icon by name. `size` sm 18px / md 24px / lg 32px,
 * `tone` colours it, `badge` shows a count (hidden when empty or 0).
 *
 *   <ui-shared-icon name="receipt_long" />
 *   <ui-shared-icon name="notifications" [badge]="unread()" />
 */
class UiSharedIconComponent {
    name = input.required();
    size = input('md');
    tone = input('inherit');
    badge = input(null);
    hostClass = computed(() => `ui-shared-icon ui-shared-icon--${this.size()} ui-shared-icon--${this.tone()}`);
    badgeHidden = computed(() => { const b = this.badge(); return b == null || b === '' || b === 0; });
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "19.2.25", type: UiSharedIconComponent, isStandalone: true, selector: "ui-shared-icon", inputs: { name: { classPropertyName: "name", publicName: "name", isSignal: true, isRequired: true, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, tone: { classPropertyName: "tone", publicName: "tone", isSignal: true, isRequired: false, transformFunction: null }, badge: { classPropertyName: "badge", publicName: "badge", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "hostClass()" } }, ngImport: i0, template: "<mat-icon aria-hidden=\"true\" [matBadge]=\"badge()\" [matBadgeHidden]=\"badgeHidden()\" matBadgeColor=\"warn\" matBadgeSize=\"medium\">{{ name() }}</mat-icon>\n", styles: [":host{display:inline-flex;box-sizing:border-box;min-width:0;max-width:100%}:host{vertical-align:middle;align-items:center;justify-content:center}mat-icon{flex:none}\n"], dependencies: [{ kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i1.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatBadgeModule }, { kind: "directive", type: i2$2.MatBadge, selector: "[matBadge]", inputs: ["matBadgeColor", "matBadgeOverlap", "matBadgeDisabled", "matBadgePosition", "matBadge", "matBadgeDescription", "matBadgeSize", "matBadgeHidden"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ui-shared-icon', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, imports: [MatIconModule, MatBadgeModule], host: { '[class]': 'hostClass()' }, template: "<mat-icon aria-hidden=\"true\" [matBadge]=\"badge()\" [matBadgeHidden]=\"badgeHidden()\" matBadgeColor=\"warn\" matBadgeSize=\"medium\">{{ name() }}</mat-icon>\n", styles: [":host{display:inline-flex;box-sizing:border-box;min-width:0;max-width:100%}:host{vertical-align:middle;align-items:center;justify-content:center}mat-icon{flex:none}\n"] }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { UiSharedDisplayDateComponent, UiSharedIconComponent, UiSharedQrCodeComponent, UiSharedStatTileComponent, UiSharedStatusChipComponent, activeTone };
//# sourceMappingURL=borassoft-ui-components-display.mjs.map
