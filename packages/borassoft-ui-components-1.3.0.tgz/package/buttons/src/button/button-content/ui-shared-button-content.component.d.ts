import * as i0 from "@angular/core";
/**
 * The inside of every clickable row: leading icon (or spinner while loading),
 * label, trailing icon. Shared by button, menu item and nav item so they line
 * up identically. With no `labelKey` / `label` the projected content is the label.
 */
export declare class UiSharedButtonContentComponent {
    icon: import("@angular/core").InputSignal<string>;
    iconEnd: import("@angular/core").InputSignal<string>;
    labelKey: import("@angular/core").InputSignal<string>;
    label: import("@angular/core").InputSignal<string>;
    loading: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    loadingKey: import("@angular/core").InputSignal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UiSharedButtonContentComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UiSharedButtonContentComponent, "ui-shared-button-content", never, { "icon": { "alias": "icon"; "required": false; "isSignal": true; }; "iconEnd": { "alias": "iconEnd"; "required": false; "isSignal": true; }; "labelKey": { "alias": "labelKey"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "loading": { "alias": "loading"; "required": false; "isSignal": true; }; "loadingKey": { "alias": "loadingKey"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}
//# sourceMappingURL=ui-shared-button-content.component.d.ts.map