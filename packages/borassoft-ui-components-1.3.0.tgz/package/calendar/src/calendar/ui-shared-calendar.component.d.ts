import { Observable } from 'rxjs';
import { CalendarOptions } from '@fullcalendar/core';
import * as i0 from "@angular/core";
/** One all-day entry of the month grid. `data` comes back on every click / action. */
export interface UiCalendarEvent<T = unknown> {
    id: string;
    /** yyyy-MM-dd */
    date: string;
    title: string;
    color?: string;
    data: T;
}
/** A hover button on every event (edit, delete …): `key` is what `eventAction` reports. */
export interface UiCalendarAction {
    key: string;
    icon: string;
    labelKey: string;
}
/**
 * Month grid of all-day events, fed lazily per visible range like the grid is fed per page:
 * `source(from, to)` answers the events of `[from, to)` (ISO dates). The shown month is
 * reported through `monthChange` (yyyy-MM); `dateClick` gives the clicked day, `eventClick`
 * the clicked event's data, `eventAction` the hover button pressed on an event.
 *
 *   <ui-shared-calendar [source]="load" [actions]="[{ key: 'edit', icon: 'edit', labelKey: 'common.edit' }]"
 *       (monthChange)="month.set($event)" (dateClick)="add($event)" (eventClick)="open($event)" (eventAction)="run($event)" />
 */
export declare class UiSharedCalendarComponent<T = unknown> {
    source: import("@angular/core").InputSignal<(from: string, to: string) => Observable<UiCalendarEvent<T>[]>>;
    actions: import("@angular/core").InputSignal<UiCalendarAction[]>;
    /** yyyy-MM to open on; the calendar otherwise starts on the current month. */
    month: import("@angular/core").InputSignal<string | null>;
    /** Rows per day before "+n more" (FullCalendar `dayMaxEvents`). */
    maxPerDay: import("@angular/core").InputSignal<number>;
    monthChange: import("@angular/core").OutputEmitterRef<string>;
    dateClick: import("@angular/core").OutputEmitterRef<string>;
    eventClick: import("@angular/core").OutputEmitterRef<T>;
    eventAction: import("@angular/core").OutputEmitterRef<{
        action: string;
        data: T;
    }>;
    private zone;
    private locale;
    private translate;
    private calendar;
    private shown;
    protected options: CalendarOptions;
    constructor();
    /** Re-asks `source` for the visible range (after a save or delete). */
    reload(): void;
    /** FullCalendar sizes against a visible container - call when the host becomes visible again. */
    resize(): void;
    /** FullCalendar builds event bodies as raw DOM outside Angular: the hover buttons hop back into the zone. */
    private render;
    static ɵfac: i0.ɵɵFactoryDeclaration<UiSharedCalendarComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UiSharedCalendarComponent<any>, "ui-shared-calendar", never, { "source": { "alias": "source"; "required": true; "isSignal": true; }; "actions": { "alias": "actions"; "required": false; "isSignal": true; }; "month": { "alias": "month"; "required": false; "isSignal": true; }; "maxPerDay": { "alias": "maxPerDay"; "required": false; "isSignal": true; }; }, { "monthChange": "monthChange"; "dateClick": "dateClick"; "eventClick": "eventClick"; "eventAction": "eventAction"; }, never, never, true, never>;
}
//# sourceMappingURL=ui-shared-calendar.component.d.ts.map