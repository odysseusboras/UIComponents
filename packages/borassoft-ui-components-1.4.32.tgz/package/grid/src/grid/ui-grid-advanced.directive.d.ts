import * as i0 from "@angular/core";
/**
 * The «advanced search» of a grid: the filters inside it stay out of the filter panel until the user opens them
 * with the panel's toggle. They keep filtering while hidden (the toggle shows how many are applied).
 *
 *   <ui-shared-grid …>
 *     <ui-shared-text-input labelKey="x.name" [fields]="['Name']" />
 *     <div uiGridAdvanced>
 *       <ui-shared-multi-select labelKey="x.region" [options]="regions" field="RegionId" />
 *     </div>
 *   </ui-shared-grid>
 */
export declare class UiGridAdvancedDirective {
    readonly filters: import("@angular/core").Signal<readonly import("@borassoft/ui-components").UiGridFilter[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UiGridAdvancedDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<UiGridAdvancedDirective, "[uiGridAdvanced]", never, {}, {}, ["filters"], never, true, never>;
}
//# sourceMappingURL=ui-grid-advanced.directive.d.ts.map