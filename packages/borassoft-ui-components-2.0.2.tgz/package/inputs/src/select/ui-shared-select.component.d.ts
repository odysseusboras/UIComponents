import { DoCheck, OnChanges, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { ErrorStateMatcher } from '@angular/material/core';
import { MatAutocompleteSelectedEvent, MatAutocompleteTrigger } from '@angular/material/autocomplete';
import { ClauseBuilder, GridFilterState, SelectOption, firstError } from '@borassoft/ui-components';
import * as i0 from "@angular/core";
/**
 * The one dropdown. The control holds the option VALUE.
 *
 *  - strict (default): a list with a search box on top, like <ui-shared-multi-select>: typing narrows the options
 *    (label or value, ignoring case and accents), arrows / Enter / click pick one. `nullable` adds an explicit "none".
 *  - `freeText`: an editable field instead; typing filters the options the same way, and any typed text is a value
 *    too (codes, numbers the list may not have).
 *
 * `disableWhenEmpty` disables the control while there are no options (cascade
 * children); it re-enables only when the control's group is enabled.
 *
 * Inside `<ui-shared-grid>` with `field` (or `[clauseBuilder]`) it is a grid filter;
 * `storageKey` remembers the choice in the browser (the options must be known on init).
 *
 *   <ui-shared-select [control]="form.controls.country" labelKey="form.country" [options]="countries" nullable />
 *   <ui-shared-select [control]="form.controls.mark" labelKey="form.mark" [options]="marks" freeText inputMode="numeric" />
 *   <ui-shared-select labelKey="users.role" [options]="roles" field="Role" />
 */
export declare class UiSharedSelectComponent<T = string> implements OnChanges, OnInit, DoCheck {
    /** Optional when used as a grid filter. */
    set control(c: FormControl);
    get control(): FormControl;
    labelKey: string;
    set options(value: SelectOption<T>[]);
    get options(): SelectOption<T>[];
    /** Accept typed text that matches no option. */
    freeText: boolean;
    nullable: boolean;
    nullLabelKey: string;
    hintKey?: string;
    /** Already translated hint text — for hints built at runtime. */
    hintText?: string;
    emptyHintKey?: string;
    disableWhenEmpty: boolean;
    /** Mobile keyboard hint (`numeric` for digit-only codes); it does not validate the value. */
    inputMode: 'text' | 'numeric';
    /** Grid filter: OData field compared with `eq` against the option value. */
    field?: string;
    /** Grid filter: custom clause for the value (overrides `field`). */
    clauseBuilder?: ClauseBuilder<T>;
    /** Grid filter: value selected on load and restored by Clear. */
    initial: T | null;
    /** Remember the choice in the browser under this key. */
    storageKey?: string;
    /** What the input shows; the bound control only ever receives values. */
    protected text: FormControl<string>;
    protected readonly firstError: typeof firstError;
    /** Errors belong to the bound control, not to the text the user is typing. */
    protected readonly errorMatcher: ErrorStateMatcher;
    private translate;
    private destroyRef;
    private allOptions;
    protected query: import("@angular/core").WritableSignal<string>;
    private typing;
    /** The control value the input text was last derived from. */
    private shownValue;
    private _control;
    /** The bound control as a signal, for `requiredSignal` (the input is a setter, not a signal input). */
    private controlSignal;
    protected required: import("@angular/core").Signal<boolean>;
    readonly filter: GridFilterState<T>;
    protected filtered: import("@angular/core").Signal<SelectOption<T>[]>;
    private search?;
    private select?;
    /** Active options, plus the current one when it is inactive. Filtered-out options stay in the list, hidden: mat-select
     *  forgets a selection whose option leaves the DOM. */
    protected get offered(): SelectOption<T>[];
    protected get current(): SelectOption<T> | undefined;
    protected filteredOut(o: SelectOption<T> | null): boolean;
    protected onQuery(text: string): void;
    protected onOpened(open: boolean): void;
    /** The panel's own keys still work from the box (arrows, Enter to pick, Escape, Tab); the rest is text, not type-ahead. */
    protected onSearchKey(event: KeyboardEvent): void;
    /** The current value points to a soft-deleted record: the field shows it struck through with a marker. */
    protected get currentInactive(): boolean;
    /**
     * Callers often change the control with `{ emitEvent: false }` (a loading
     * lock, a mirrored selection), which raises no event — so the input follows
     * the control's value and disabled state on every check instead.
     */
    ngDoCheck(): void;
    ngOnInit(): void;
    ngOnChanges(): void;
    /**
     * Material's trigger writes EVERY value the input shows through this: the
     * picked option value (→ its label) and the text we set (a label already).
     */
    protected displayWith: (value: unknown) => string;
    protected onInput(event: Event): void;
    protected onPick(event: MatAutocompleteSelectedEvent): void;
    protected onFocus(event: FocusEvent): void;
    /**
     * Clicking an option blurs the input BEFORE the click lands. Clearing the
     * filter here would re-render the full list under the pointer and pick
     * whatever option now sits there, so while the panel is open the filter
     * stays until the panel closes (`resetQuery`).
     */
    protected onBlur(trigger: MatAutocompleteTrigger): void;
    protected resetQuery(): void;
    protected toggle(trigger: MatAutocompleteTrigger, input: HTMLInputElement): void;
    private syncText;
    private syncDisabled;
    /** The option's label; free text as typed; nothing for a value the options don't (yet) hold. */
    private textOf;
    private label;
    private optionEq;
    static ɵfac: i0.ɵɵFactoryDeclaration<UiSharedSelectComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UiSharedSelectComponent<any>, "ui-shared-select", never, { "control": { "alias": "control"; "required": false; }; "labelKey": { "alias": "labelKey"; "required": true; }; "options": { "alias": "options"; "required": false; }; "freeText": { "alias": "freeText"; "required": false; }; "nullable": { "alias": "nullable"; "required": false; }; "nullLabelKey": { "alias": "nullLabelKey"; "required": false; }; "hintKey": { "alias": "hintKey"; "required": false; }; "hintText": { "alias": "hintText"; "required": false; }; "emptyHintKey": { "alias": "emptyHintKey"; "required": false; }; "disableWhenEmpty": { "alias": "disableWhenEmpty"; "required": false; }; "inputMode": { "alias": "inputMode"; "required": false; }; "field": { "alias": "field"; "required": false; }; "clauseBuilder": { "alias": "clauseBuilder"; "required": false; }; "initial": { "alias": "initial"; "required": false; }; "storageKey": { "alias": "storageKey"; "required": false; }; }, {}, never, ["[suffix]", "[suffix]"], true, never>;
    static ngAcceptInputType_freeText: unknown;
    static ngAcceptInputType_nullable: unknown;
    static ngAcceptInputType_disableWhenEmpty: unknown;
}
//# sourceMappingURL=ui-shared-select.component.d.ts.map