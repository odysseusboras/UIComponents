import { SelectOption } from '@borassoft/ui-components';
/**
 * The standard Active / Deleted / All filter every soft-deletable management
 * grid projects, as a `<ui-shared-segmented>`. Pair with `softDeleteClauseBuilder`.
 */
export declare const SOFT_DELETE_STATUS_OPTIONS: SelectOption[];
/** OData clause for `SOFT_DELETE_STATUS_OPTIONS` against the row's `IsDeleted` flag. */
export declare function softDeleteClauseBuilder(v: string): string | null;
//# sourceMappingURL=soft-delete.d.ts.map