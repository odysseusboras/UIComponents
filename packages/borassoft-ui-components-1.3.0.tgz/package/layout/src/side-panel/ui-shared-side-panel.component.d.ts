import { OnDestroy } from '@angular/core';
import * as i0 from "@angular/core";
/**
 * Generic show/hide + drag-resizable side panel for a shell layout. Consumers
 * project the nav body and the main content via named slots:
 *
 * ```html
 * <ui-shared-side-panel storageKey="admin-shell">
 *   <div slot="nav">…sidenav head + nav list…</div>
 *   <div slot="content"><router-outlet /></div>
 * </ui-shared-side-panel>
 * ```
 *
 * Behaviour:
 *  - **Show / hide.** A toggle button collapses the panel to a slim rail.
 *    A second toggle at the rail edge expands it back to the saved width.
 *  - **Drag-resize.** Grab the vertical handle on the right edge of the
 *    expanded panel and drag to set the width. Width is clamped to
 *    `[minWidth, maxWidth]`.
 *  - **Persistence.** Both the collapsed flag and the current width are
 *    written to `localStorage` under `ui.sidePanel.<storageKey>` so each
 *    shell remembers its own layout independently across sessions.
 *
 * The rail sticks below the host's header: set `--header-h` (or `--ui-sticky-top`).
 * While dragging, `body` carries the `ui-resizing` class so the host can force
 * the column-resize cursor globally.
 */
export declare class UiSharedSidePanelComponent implements OnDestroy {
    /** Unique storage key — e.g. "admin-shell". Required. */
    storageKey: import("@angular/core").InputSignal<string>;
    /** Default expanded width (px) when nothing is in localStorage. */
    defaultWidth: import("@angular/core").InputSignalWithTransform<number, unknown>;
    /** Minimum drag width (px). Anything below clamps up. */
    minWidth: import("@angular/core").InputSignalWithTransform<number, unknown>;
    /** Maximum drag width (px). Anything above clamps down. */
    maxWidth: import("@angular/core").InputSignalWithTransform<number, unknown>;
    /** Width of the slim "collapsed" rail that hosts the expand toggle. */
    protected readonly railWidth = 36;
    private host;
    private zone;
    protected width: import("@angular/core").WritableSignal<number>;
    protected collapsed: import("@angular/core").WritableSignal<boolean>;
    /** True while the user is dragging the resize handle. */
    protected dragging: import("@angular/core").WritableSignal<boolean>;
    private stopDrag;
    constructor();
    ngOnDestroy(): void;
    toggleCollapsed(): void;
    /** Pointerdown on the resize handle — start tracking width. */
    startDrag(ev: PointerEvent): void;
    private clamp;
    private storageKeyFor;
    private readState;
    get widthVar(): number;
    static ɵfac: i0.ɵɵFactoryDeclaration<UiSharedSidePanelComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UiSharedSidePanelComponent, "ui-shared-side-panel", never, { "storageKey": { "alias": "storageKey"; "required": true; "isSignal": true; }; "defaultWidth": { "alias": "defaultWidth"; "required": false; "isSignal": true; }; "minWidth": { "alias": "minWidth"; "required": false; "isSignal": true; }; "maxWidth": { "alias": "maxWidth"; "required": false; "isSignal": true; }; }, {}, never, ["[slot=nav]", "[slot=content]"], true, never>;
}
//# sourceMappingURL=ui-shared-side-panel.component.d.ts.map