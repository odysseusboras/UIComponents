import { PipeTransform } from '@angular/core';
import * as i0 from "@angular/core";
/**
 * One choice for every option-based input (select, radio group,
 * segmented). Give an already translated `label`, or a `labelKey` resolved
 * through UI_TRANSLATE.
 */
export interface SelectOption<T = string> {
    value: T;
    label?: string;
    labelKey?: string;
    /**
     * A soft-deleted record: never offered in a dropdown, but when it is the current
     * value it stays visible, struck through and marked (old data keeps its value).
     */
    inactive?: boolean;
}
/** Case- and accent-insensitive form for matching typed text: «γαλλια» finds «Γαλλία», «τμημα» finds «Τμήμα». */
export declare function foldText(s: string): string;
/** The text an option shows. */
export declare function optionText(o: SelectOption<unknown>, translate: (key: string) => string): string;
/** `{{ option | uiOptionText }}` — impure so labels follow a locale change, like `uiTranslate`. */
export declare class UiOptionTextPipe implements PipeTransform {
    private translate;
    transform(option: SelectOption<unknown>): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<UiOptionTextPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<UiOptionTextPipe, "uiOptionText", true>;
}
//# sourceMappingURL=select-option.d.ts.map