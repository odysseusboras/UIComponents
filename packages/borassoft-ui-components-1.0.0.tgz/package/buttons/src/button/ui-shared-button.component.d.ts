import * as i0 from "@angular/core";
export type UiButtonVariant = 'primary' | 'secondary' | 'accent' | 'danger' | 'danger-filled' | 'text';
export type UiButtonSize = 'sm' | 'md' | 'lg';
/**
 * The one text button. Every look is a `variant`, every height a `size`;
 * the styles live in the library theme (`.ui-shared-button`).
 *
 *   primary        filled accent (save, create, submit)
 *   secondary      outlined neutral (cancel, export, secondary actions)
 *   accent         outlined accent (open, sync)
 *   danger         outlined red (delete, deactivate)
 *   danger-filled  filled red (destructive primary)
 *   text           borderless (reset, whole month)
 *
 * Renders an `<a>` when `routerLink` is set, a spinner + `loadingKey` while
 * `loading`. With neither `labelKey` nor `label`, projected content is the label
 * (avatar + name, custom chrome). Put it in `[slot=trigger]` of <ui-shared-menu>
 * to open a menu.
 *
 *   <ui-shared-button variant="primary" icon="add" labelKey="products.add" (click)="openCreate()" />
 *   <ui-shared-button type="submit" [loading]="saving()" loadingKey="common.saving" labelKey="common.save" [disabled]="form.invalid" />
 *   <ui-shared-button variant="secondary" size="lg" labelKey="home.cta.signIn" routerLink="/auth/login" />
 */
export declare class UiSharedButtonComponent {
    variant: import("@angular/core").InputSignal<UiButtonVariant>;
    size: import("@angular/core").InputSignal<UiButtonSize>;
    /** Translation key of the label; `label` is the raw-text alternative. */
    labelKey: import("@angular/core").InputSignal<string>;
    label: import("@angular/core").InputSignal<string>;
    /** Material icon before the label; `iconEnd` puts it after. */
    icon: import("@angular/core").InputSignal<string>;
    iconEnd: import("@angular/core").InputSignal<string>;
    type: import("@angular/core").InputSignal<"button" | "submit">;
    disabled: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    /** Shows a spinner and, when set, `loadingKey` instead of the label; the button is disabled meanwhile. */
    loading: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    loadingKey: import("@angular/core").InputSignal<string>;
    tooltipKey: import("@angular/core").InputSignal<string>;
    /** Renders an anchor instead of a button. */
    routerLink: import("@angular/core").InputSignal<string | any[] | null>;
    queryParams: import("@angular/core").InputSignal<Record<string, unknown> | null>;
    /** Full-width (auth forms). */
    block: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    protected get classes(): string;
    protected get isDisabled(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<UiSharedButtonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UiSharedButtonComponent, "ui-shared-button", never, { "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "labelKey": { "alias": "labelKey"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "icon": { "alias": "icon"; "required": false; "isSignal": true; }; "iconEnd": { "alias": "iconEnd"; "required": false; "isSignal": true; }; "type": { "alias": "type"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "loading": { "alias": "loading"; "required": false; "isSignal": true; }; "loadingKey": { "alias": "loadingKey"; "required": false; "isSignal": true; }; "tooltipKey": { "alias": "tooltipKey"; "required": false; "isSignal": true; }; "routerLink": { "alias": "routerLink"; "required": false; "isSignal": true; }; "queryParams": { "alias": "queryParams"; "required": false; "isSignal": true; }; "block": { "alias": "block"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}
//# sourceMappingURL=ui-shared-button.component.d.ts.map