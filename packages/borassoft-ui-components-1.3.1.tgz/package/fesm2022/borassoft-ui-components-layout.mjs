import * as i0 from '@angular/core';
import { InjectionToken, signal, Injectable, input, inject, computed, ChangeDetectionStrategy, Component, booleanAttribute, output, viewChild, ElementRef, HostListener, numberAttribute, NgZone, effect, HostBinding, contentChildren } from '@angular/core';
import { Router, NavigationEnd, RouterLink, RouterLinkActive } from '@angular/router';
import * as i1 from '@angular/material/icon';
import { MatIconModule } from '@angular/material/icon';
import { UiTranslatePipe, UI_TRANSLATE, uiStorage, trackPointerDrag } from '@borassoft/ui-components';
import { toSignal } from '@angular/core/rxjs-interop';
import { filter, map, startWith } from 'rxjs';
import * as i1$1 from '@angular/material/button';
import { MatButtonModule } from '@angular/material/button';
import * as i2 from '@angular/material/tooltip';
import { MatTooltipModule } from '@angular/material/tooltip';
import { NgTemplateOutlet } from '@angular/common';
import * as i1$2 from '@angular/material/tabs';
import { MatTabsModule } from '@angular/material/tabs';
import { UiSharedButtonContentComponent } from '@borassoft/ui-components/buttons';

const UI_BREADCRUMBS = new InjectionToken('UI_BREADCRUMBS', { providedIn: 'root', factory: () => [] });
function provideUiBreadcrumbs(nodes) {
    return { provide: UI_BREADCRUMBS, useValue: nodes };
}
/**
 * Labels for `:param` crumbs that only the page knows (a company's name for its id): the page
 * registers `set(paramValue, label)` once it has loaded the record, the trail picks it up.
 */
class UiBreadcrumbLabels {
    labels = signal(new Map());
    set(value, label) {
        this.labels.update(m => { const n = new Map(m); n.set(value, label); return n; });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiBreadcrumbLabels, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiBreadcrumbLabels, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiBreadcrumbLabels, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });
/** Walks the URL through the tree: static paths win over `:param` ones; stops at the first segment nothing matches. */
function resolveUiBreadcrumbs(nodes, url, labels) {
    const segments = url.split(/[?#]/)[0].split('/').filter(Boolean).map(decodeURIComponent);
    const crumbs = [];
    const params = {};
    let level = nodes;
    let path = '';
    for (const seg of segments) {
        const node = level.find(n => n.path === seg) ?? level.find(n => n.path.startsWith(':'));
        if (!node)
            break;
        if (node.path.startsWith(':'))
            params[node.path.slice(1)] = seg;
        path += '/' + encodeURIComponent(seg);
        const label = node.label?.(params) ?? (node.path.startsWith(':') ? labels?.get(seg) : undefined);
        crumbs.push({ labelKey: node.labelKey, label, url: node.redirect ? `${path}/${node.redirect}` : path, last: false });
        level = node.children ?? [];
    }
    // A parent that redirects to the page we are on is that page: keep the child, drop the twin.
    const unique = crumbs.filter((c, i) => crumbs[i + 1]?.url !== c.url);
    if (unique.length)
        unique[unique.length - 1].last = true;
    return unique;
}

/**
 * Breadcrumb trail for the current URL, from the tree the app registers with
 * `provideUiBreadcrumbs`. Renders nothing with fewer than two crumbs. The last crumb is the
 * current page: its node label, or `currentLabel` (the page title) when the node has none.
 * `<ui-shared-page-header>` renders it above the title, so pages need not place it themselves.
 */
class UiSharedBreadcrumbComponent {
    /** Label of the current page when its node has none (the page title). */
    currentLabel = input('');
    router = inject(Router);
    tree = inject(UI_BREADCRUMBS);
    labels = inject(UiBreadcrumbLabels);
    url = toSignal(this.router.events.pipe(filter(e => e instanceof NavigationEnd), map(() => this.router.url), startWith(this.router.url)));
    crumbs = computed(() => resolveUiBreadcrumbs(this.tree, this.url() ?? '', this.labels.labels()));
    /** Whether a trail renders (two crumbs or more); the page header reads it. */
    visible = computed(() => this.crumbs().length > 1);
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedBreadcrumbComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: UiSharedBreadcrumbComponent, isStandalone: true, selector: "ui-shared-breadcrumb", inputs: { currentLabel: { classPropertyName: "currentLabel", publicName: "currentLabel", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: "@if (visible()) {\n  <nav class=\"ui-shared-breadcrumb\" aria-label=\"breadcrumb\">\n    <ol class=\"ui-shared-breadcrumb__list\">\n      @for (c of crumbs(); track c.url) {\n        <li class=\"ui-shared-breadcrumb__item\">\n          @if (!c.last) {\n            <a class=\"ui-shared-breadcrumb__link\" [routerLink]=\"c.url\">{{ c.labelKey ? (c.labelKey | uiTranslate) : c.label }}</a>\n            <span class=\"ui-shared-breadcrumb__sep\" aria-hidden=\"true\">/</span>\n          } @else {\n            <span class=\"ui-shared-breadcrumb__current\" aria-current=\"page\">{{ c.labelKey ? (c.labelKey | uiTranslate) : (c.label || currentLabel()) }}</span>\n          }\n        </li>\n      }\n    </ol>\n  </nav>\n}\n", styles: [":host{display:block;box-sizing:border-box;min-width:0;max-width:100%}.ui-shared-breadcrumb__list{display:flex;flex-wrap:wrap;align-items:center;margin:0;padding:0;list-style:none}.ui-shared-breadcrumb__item{display:inline-flex;align-items:center}\n"], dependencies: [{ kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "pipe", type: UiTranslatePipe, name: "uiTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedBreadcrumbComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ui-shared-breadcrumb', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, imports: [RouterLink, UiTranslatePipe], template: "@if (visible()) {\n  <nav class=\"ui-shared-breadcrumb\" aria-label=\"breadcrumb\">\n    <ol class=\"ui-shared-breadcrumb__list\">\n      @for (c of crumbs(); track c.url) {\n        <li class=\"ui-shared-breadcrumb__item\">\n          @if (!c.last) {\n            <a class=\"ui-shared-breadcrumb__link\" [routerLink]=\"c.url\">{{ c.labelKey ? (c.labelKey | uiTranslate) : c.label }}</a>\n            <span class=\"ui-shared-breadcrumb__sep\" aria-hidden=\"true\">/</span>\n          } @else {\n            <span class=\"ui-shared-breadcrumb__current\" aria-current=\"page\">{{ c.labelKey ? (c.labelKey | uiTranslate) : (c.label || currentLabel()) }}</span>\n          }\n        </li>\n      }\n    </ol>\n  </nav>\n}\n", styles: [":host{display:block;box-sizing:border-box;min-width:0;max-width:100%}.ui-shared-breadcrumb__list{display:flex;flex-wrap:wrap;align-items:center;margin:0;padding:0;list-style:none}.ui-shared-breadcrumb__item{display:inline-flex;align-items:center}\n"] }]
        }] });

/**
 * Standard page header — title (h1) + optional lede line + optional back link.
 *
 * Two ways to provide content:
 *   - translation KEYS (preferred for static labels) via `titleKey` / `ledeKey`
 *   - literal STRINGS (for dynamic content like an entity name) via `titleText` / `ledeText`
 *
 * Translation keys win when both are set:
 *
 *   <ui-shared-page-header titleKey="admin.companies.title" ledeKey="admin.companies.lede" />
 *
 *   <ui-shared-page-header [titleText]="company.friendlyName"
 *                   [ledeText]="company.country + ' · VAT: ' + company.vat"
 *                   [backLink]="['..']" backKey="admin.companies.title" />
 *
 * The breadcrumb trail (`provideUiBreadcrumbs`) renders above the title on every page; the
 * current page's crumb is this title, and the back link is dropped while a trail shows. Set
 * `breadcrumb="false"` to leave it out.
 *
 * Detail pages set `backLink` (a routerLink value) to render a small
 * "← Back" link above the title; set `(back)` instead (with no `backLink`)
 * for an imperative handler. Project content into `[slot=actions]` for
 * page-level actions.
 */
class UiSharedPageHeaderComponent {
    /** Translation key for the page title. Wins over titleText. */
    titleKey = input('');
    /** Literal title text (e.g. an entity name). Used only when titleKey is empty. */
    titleText = input('');
    /** Translation key for the lede paragraph. Wins over ledeText. */
    ledeKey = input('');
    /** Literal lede text. Used only when ledeKey is empty. */
    ledeText = input('');
    /** routerLink target for the back link. `null` + a `(back)` listener renders a button instead. */
    backLink = input(null);
    /** Translation key for the back link label. */
    backKey = input('common.back');
    /** Force the back control on (as a button) even without a `backLink`. */
    showBack = input(false, { transform: booleanAttribute });
    /** Whether the [slot=actions] projection should be rendered. */
    showActions = input(true, { transform: booleanAttribute });
    /** Emitted when the back BUTTON (no `backLink`) is clicked. */
    back = output();
    /** Render the breadcrumb trail above the title (when the app registered a tree). */
    breadcrumb = input(true, { transform: booleanAttribute });
    translate = inject(UI_TRANSLATE);
    trail = viewChild(UiSharedBreadcrumbComponent);
    /** The back link is the trail's job once a trail renders; it stays for pages outside the tree. */
    hasBack = computed(() => !this.trail()?.visible() && (this.backLink() !== null || this.showBack()));
    titleLabel = computed(() => this.titleKey() ? this.translate(this.titleKey()) : this.titleText());
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedPageHeaderComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: UiSharedPageHeaderComponent, isStandalone: true, selector: "ui-shared-page-header", inputs: { titleKey: { classPropertyName: "titleKey", publicName: "titleKey", isSignal: true, isRequired: false, transformFunction: null }, titleText: { classPropertyName: "titleText", publicName: "titleText", isSignal: true, isRequired: false, transformFunction: null }, ledeKey: { classPropertyName: "ledeKey", publicName: "ledeKey", isSignal: true, isRequired: false, transformFunction: null }, ledeText: { classPropertyName: "ledeText", publicName: "ledeText", isSignal: true, isRequired: false, transformFunction: null }, backLink: { classPropertyName: "backLink", publicName: "backLink", isSignal: true, isRequired: false, transformFunction: null }, backKey: { classPropertyName: "backKey", publicName: "backKey", isSignal: true, isRequired: false, transformFunction: null }, showBack: { classPropertyName: "showBack", publicName: "showBack", isSignal: true, isRequired: false, transformFunction: null }, showActions: { classPropertyName: "showActions", publicName: "showActions", isSignal: true, isRequired: false, transformFunction: null }, breadcrumb: { classPropertyName: "breadcrumb", publicName: "breadcrumb", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { back: "back" }, viewQueries: [{ propertyName: "trail", first: true, predicate: UiSharedBreadcrumbComponent, descendants: true, isSignal: true }], ngImport: i0, template: "<header class=\"ui-shared-page-header\" [class.ui-shared-page-header--with-back]=\"hasBack()\">\n  @if (breadcrumb()) {\n    <ui-shared-breadcrumb class=\"ui-shared-page-header__breadcrumb\" [currentLabel]=\"titleLabel()\" />\n  }\n  @if (hasBack()) {\n    @if (backLink(); as link) {\n      <a class=\"ui-shared-page-header__back\" [routerLink]=\"link\">\n        <mat-icon aria-hidden=\"true\">arrow_back</mat-icon>\n        <span>{{ backKey() | uiTranslate }}</span>\n      </a>\n    } @else {\n      <button type=\"button\" class=\"ui-shared-page-header__back\" (click)=\"back.emit()\">\n        <mat-icon aria-hidden=\"true\">arrow_back</mat-icon>\n        <span>{{ backKey() | uiTranslate }}</span>\n      </button>\n    }\n  }\n\n  <h1 class=\"ui-shared-page-header__title\">\n    @if (titleKey()) {\n      {{ titleKey() | uiTranslate }}\n    } @else {\n      {{ titleText() }}\n    }\n  </h1>\n\n  @if (ledeKey()) {\n    <p class=\"ui-shared-page-header__lede\">{{ ledeKey() | uiTranslate }}</p>\n  } @else if (ledeText()) {\n    <p class=\"ui-shared-page-header__lede\">{{ ledeText() }}</p>\n  }\n\n  @if (showActions()) {\n    <div class=\"ui-shared-page-header__actions\">\n      <ng-content select=\"[slot=actions]\"></ng-content>\n    </div>\n  }\n</header>\n", styles: [":host{display:block;box-sizing:border-box;min-width:0;max-width:100%}.ui-shared-page-header{display:grid;grid-template-columns:minmax(0,1fr) auto;align-items:end}.ui-shared-page-header__breadcrumb,.ui-shared-page-header__back,.ui-shared-page-header__title,.ui-shared-page-header__lede{grid-column:1}.ui-shared-page-header__back{display:inline-flex;align-items:center;width:fit-content;cursor:pointer}.ui-shared-page-header__actions{grid-column:2;grid-row:1/span 4;display:flex;align-items:center;justify-content:flex-end}.ui-shared-page-header__actions:empty{display:none}@media(max-width:640px){.ui-shared-page-header{grid-template-columns:1fr}.ui-shared-page-header__actions{grid-column:1;grid-row:auto;justify-content:flex-start}}\n"], dependencies: [{ kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i1.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "pipe", type: UiTranslatePipe, name: "uiTranslate" }, { kind: "component", type: UiSharedBreadcrumbComponent, selector: "ui-shared-breadcrumb", inputs: ["currentLabel"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedPageHeaderComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ui-shared-page-header', standalone: true, imports: [RouterLink, MatIconModule, UiTranslatePipe, UiSharedBreadcrumbComponent], template: "<header class=\"ui-shared-page-header\" [class.ui-shared-page-header--with-back]=\"hasBack()\">\n  @if (breadcrumb()) {\n    <ui-shared-breadcrumb class=\"ui-shared-page-header__breadcrumb\" [currentLabel]=\"titleLabel()\" />\n  }\n  @if (hasBack()) {\n    @if (backLink(); as link) {\n      <a class=\"ui-shared-page-header__back\" [routerLink]=\"link\">\n        <mat-icon aria-hidden=\"true\">arrow_back</mat-icon>\n        <span>{{ backKey() | uiTranslate }}</span>\n      </a>\n    } @else {\n      <button type=\"button\" class=\"ui-shared-page-header__back\" (click)=\"back.emit()\">\n        <mat-icon aria-hidden=\"true\">arrow_back</mat-icon>\n        <span>{{ backKey() | uiTranslate }}</span>\n      </button>\n    }\n  }\n\n  <h1 class=\"ui-shared-page-header__title\">\n    @if (titleKey()) {\n      {{ titleKey() | uiTranslate }}\n    } @else {\n      {{ titleText() }}\n    }\n  </h1>\n\n  @if (ledeKey()) {\n    <p class=\"ui-shared-page-header__lede\">{{ ledeKey() | uiTranslate }}</p>\n  } @else if (ledeText()) {\n    <p class=\"ui-shared-page-header__lede\">{{ ledeText() }}</p>\n  }\n\n  @if (showActions()) {\n    <div class=\"ui-shared-page-header__actions\">\n      <ng-content select=\"[slot=actions]\"></ng-content>\n    </div>\n  }\n</header>\n", styles: [":host{display:block;box-sizing:border-box;min-width:0;max-width:100%}.ui-shared-page-header{display:grid;grid-template-columns:minmax(0,1fr) auto;align-items:end}.ui-shared-page-header__breadcrumb,.ui-shared-page-header__back,.ui-shared-page-header__title,.ui-shared-page-header__lede{grid-column:1}.ui-shared-page-header__back{display:inline-flex;align-items:center;width:fit-content;cursor:pointer}.ui-shared-page-header__actions{grid-column:2;grid-row:1/span 4;display:flex;align-items:center;justify-content:flex-end}.ui-shared-page-header__actions:empty{display:none}@media(max-width:640px){.ui-shared-page-header{grid-template-columns:1fr}.ui-shared-page-header__actions{grid-column:1;grid-row:auto;justify-content:flex-start}}\n"] }]
        }] });

/**
 * A card panel whose body can be collapsed to its header. The state is
 * remembered per `storageKey` in localStorage (`ui.collapsible.<storageKey>`),
 * so a user who hides a stats block keeps it hidden across visits.
 *
 *   <ui-shared-collapsible-panel titleKey="stats.title" storageKey="stats">…</ui-shared-collapsible-panel>
 */
class UiSharedCollapsiblePanelComponent {
    titleKey = input.required();
    ledeKey = input('');
    storageKey = input.required();
    toggled = signal(null);
    collapsed = computed(() => this.toggled() ?? this.read());
    toggle() {
        const next = !this.collapsed();
        this.toggled.set(next);
        uiStorage.set(this.key(), next ? '1' : '0');
    }
    key() { return `ui.collapsible.${this.storageKey()}`; }
    read() { return uiStorage.get(this.key()) === '1'; }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedCollapsiblePanelComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: UiSharedCollapsiblePanelComponent, isStandalone: true, selector: "ui-shared-collapsible-panel", inputs: { titleKey: { classPropertyName: "titleKey", publicName: "titleKey", isSignal: true, isRequired: true, transformFunction: null }, ledeKey: { classPropertyName: "ledeKey", publicName: "ledeKey", isSignal: true, isRequired: false, transformFunction: null }, storageKey: { classPropertyName: "storageKey", publicName: "storageKey", isSignal: true, isRequired: true, transformFunction: null } }, ngImport: i0, template: "<section class=\"ui-shared-collapsible-panel\" [class.ui-shared-collapsible-panel--collapsed]=\"collapsed()\">\n  <!-- One control: the whole header row toggles (keyboard: it is a real button). -->\n  <button type=\"button\" class=\"ui-shared-collapsible-panel__head\" (click)=\"toggle()\"\n          [attr.aria-expanded]=\"!collapsed()\"\n          [matTooltip]=\"(collapsed() ? 'common.expand' : 'common.collapse') | uiTranslate\"\n          matTooltipPosition=\"above\">\n    <span class=\"ui-shared-collapsible-panel__title-group\">\n      <span class=\"ui-shared-collapsible-panel__title\">{{ titleKey() | uiTranslate }}</span>\n      @if (ledeKey() && !collapsed()) {\n        <span class=\"ui-shared-collapsible-panel__lede\">{{ ledeKey() | uiTranslate }}</span>\n      }\n    </span>\n    <mat-icon class=\"ui-shared-collapsible-panel__chevron\" aria-hidden=\"true\">expand_more</mat-icon>\n  </button>\n  @if (!collapsed()) {\n    <div class=\"ui-shared-collapsible-panel__body\">\n      <ng-content />\n    </div>\n  }\n</section>\n", styles: [":host{display:block;box-sizing:border-box;min-width:0;max-width:100%}.ui-shared-collapsible-panel{position:relative}.ui-shared-collapsible-panel__head{display:flex;align-items:center;justify-content:space-between;width:100%;text-align:left;cursor:pointer;-webkit-user-select:none;user-select:none}.ui-shared-collapsible-panel__title-group{display:flex;flex-direction:column;flex:1 1 auto;min-width:0}.ui-shared-collapsible-panel__chevron{flex:0 0 auto}\n"], dependencies: [{ kind: "ngmodule", type: MatButtonModule }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i1.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "directive", type: i2.MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }, { kind: "pipe", type: UiTranslatePipe, name: "uiTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedCollapsiblePanelComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ui-shared-collapsible-panel', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, imports: [MatButtonModule, MatIconModule, MatTooltipModule, UiTranslatePipe], template: "<section class=\"ui-shared-collapsible-panel\" [class.ui-shared-collapsible-panel--collapsed]=\"collapsed()\">\n  <!-- One control: the whole header row toggles (keyboard: it is a real button). -->\n  <button type=\"button\" class=\"ui-shared-collapsible-panel__head\" (click)=\"toggle()\"\n          [attr.aria-expanded]=\"!collapsed()\"\n          [matTooltip]=\"(collapsed() ? 'common.expand' : 'common.collapse') | uiTranslate\"\n          matTooltipPosition=\"above\">\n    <span class=\"ui-shared-collapsible-panel__title-group\">\n      <span class=\"ui-shared-collapsible-panel__title\">{{ titleKey() | uiTranslate }}</span>\n      @if (ledeKey() && !collapsed()) {\n        <span class=\"ui-shared-collapsible-panel__lede\">{{ ledeKey() | uiTranslate }}</span>\n      }\n    </span>\n    <mat-icon class=\"ui-shared-collapsible-panel__chevron\" aria-hidden=\"true\">expand_more</mat-icon>\n  </button>\n  @if (!collapsed()) {\n    <div class=\"ui-shared-collapsible-panel__body\">\n      <ng-content />\n    </div>\n  }\n</section>\n", styles: [":host{display:block;box-sizing:border-box;min-width:0;max-width:100%}.ui-shared-collapsible-panel{position:relative}.ui-shared-collapsible-panel__head{display:flex;align-items:center;justify-content:space-between;width:100%;text-align:left;cursor:pointer;-webkit-user-select:none;user-select:none}.ui-shared-collapsible-panel__title-group{display:flex;flex-direction:column;flex:1 1 auto;min-width:0}.ui-shared-collapsible-panel__chevron{flex:0 0 auto}\n"] }]
        }] });

/**
 * Generic slide-in side drawer — the replacement for edit/detail popup dialogs.
 * Distinct from <ui-shared-side-panel>, which is the collapsible LEFT shell nav.
 * Project the body as default content and the footer buttons into
 * <code>[slot=actions]</code> (right-aligned). Controlled by the parent via
 * <code>[open]</code> + <code>(close)</code>; closes on backdrop click or Escape.
 *
 * The host element is re-parented to <body> on init so its fixed-position overlay
 * is viewport-relative — otherwise a transformed/stacking-context ancestor (the
 * Material sidenav content) traps it BELOW the sticky app header and hides the
 * drawer's own header. Keep this; removing it re-introduces that bug everywhere.
 *
 * Typical use from a grid's row-click (`<ui-shared-grid (rowClick)>`):
 *
 *   <ui-shared-side-drawer [open]="!!editing()" titleKey="admin.companies.edit"
 *                   (close)="editing.set(null)">
 *     <!-- per-case edit form here -->
 *     <button slot="actions" mat-stroked-button (click)="editing.set(null)">{{ 'common.cancel' | uiTranslate }}</button>
 *     <button slot="actions" mat-flat-button color="primary" (click)="save()">{{ 'common.save' | uiTranslate }}</button>
 *   </ui-shared-side-drawer>
 */
class UiSharedSideDrawerComponent {
    open = input(false, { transform: booleanAttribute });
    titleKey = input('');
    /** Explicit drawer width on wide screens (overrides `size`); goes full-width on narrow ones via CSS. */
    width = input(null);
    /** md = standard edit form (default); lg = wide forms / multi-column detail. */
    size = input('md');
    widthVar = computed(() => this.width() ?? (this.size() === 'lg' ? 'clamp(640px, 52vw, 760px)' : 'clamp(480px, 38vw, 560px)'));
    close = output();
    host = inject(ElementRef);
    ngOnInit() {
        document.body.appendChild(this.host.nativeElement);
    }
    ngOnDestroy() {
        this.host.nativeElement.remove();
    }
    /** An overlay opened from inside the drawer (menu, select, dialog) that handled Escape itself keeps the drawer open. */
    onEscape(event) {
        if (this.open() && !event.defaultPrevented)
            this.close.emit();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedSideDrawerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: UiSharedSideDrawerComponent, isStandalone: true, selector: "ui-shared-side-drawer", inputs: { open: { classPropertyName: "open", publicName: "open", isSignal: true, isRequired: false, transformFunction: null }, titleKey: { classPropertyName: "titleKey", publicName: "titleKey", isSignal: true, isRequired: false, transformFunction: null }, width: { classPropertyName: "width", publicName: "width", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { close: "close" }, host: { listeners: { "document:keydown.escape": "onEscape($event)" } }, ngImport: i0, template: "@if (open()) {\n  <div class=\"ui-shared-side-drawer__backdrop\" (click)=\"close.emit()\"></div>\n\n  <aside class=\"ui-shared-side-drawer\" role=\"dialog\" aria-modal=\"true\" [style.--side-drawer-w]=\"widthVar()\">\n    <header class=\"ui-shared-side-drawer__head\">\n      <h2 class=\"ui-shared-side-drawer__title\">{{ titleKey() | uiTranslate }}</h2>\n      <button mat-icon-button type=\"button\" class=\"ui-shared-side-drawer__close\"\n              (click)=\"close.emit()\" [attr.aria-label]=\"'common.close' | uiTranslate\">\n        <mat-icon>close</mat-icon>\n      </button>\n    </header>\n\n    <div class=\"ui-shared-side-drawer__body\">\n      <ng-content></ng-content>\n    </div>\n\n    <footer class=\"ui-shared-side-drawer__actions\">\n      <ng-content select=\"[slot=actions]\"></ng-content>\n    </footer>\n  </aside>\n}\n", styles: [":host{display:contents;box-sizing:border-box;min-width:0;max-width:100%}.ui-shared-side-drawer__backdrop{position:fixed;inset:0;z-index:var(--ui-z-drawer, 900)}.ui-shared-side-drawer{position:fixed;top:0;right:0;z-index:calc(var(--ui-z-drawer, 900) + 1);display:flex;flex-direction:column;width:min(var(--side-drawer-w),100vw);height:var(--ui-viewport-h, 100dvh);max-height:var(--ui-viewport-h, 100dvh);overflow:hidden}.ui-shared-side-drawer__head,.ui-shared-side-drawer__actions{flex:0 0 auto;display:flex;align-items:center}.ui-shared-side-drawer__head{justify-content:space-between}.ui-shared-side-drawer__actions{justify-content:flex-end}.ui-shared-side-drawer__actions:empty{display:none}.ui-shared-side-drawer__body{flex:1 1 auto;min-height:0;overflow-y:auto}@media(max-width:600px){.ui-shared-side-drawer{width:100vw}}\n"], dependencies: [{ kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i1$1.MatIconButton, selector: "button[mat-icon-button]", exportAs: ["matButton"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i1.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "pipe", type: UiTranslatePipe, name: "uiTranslate" }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedSideDrawerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ui-shared-side-drawer', standalone: true, imports: [MatButtonModule, MatIconModule, UiTranslatePipe], template: "@if (open()) {\n  <div class=\"ui-shared-side-drawer__backdrop\" (click)=\"close.emit()\"></div>\n\n  <aside class=\"ui-shared-side-drawer\" role=\"dialog\" aria-modal=\"true\" [style.--side-drawer-w]=\"widthVar()\">\n    <header class=\"ui-shared-side-drawer__head\">\n      <h2 class=\"ui-shared-side-drawer__title\">{{ titleKey() | uiTranslate }}</h2>\n      <button mat-icon-button type=\"button\" class=\"ui-shared-side-drawer__close\"\n              (click)=\"close.emit()\" [attr.aria-label]=\"'common.close' | uiTranslate\">\n        <mat-icon>close</mat-icon>\n      </button>\n    </header>\n\n    <div class=\"ui-shared-side-drawer__body\">\n      <ng-content></ng-content>\n    </div>\n\n    <footer class=\"ui-shared-side-drawer__actions\">\n      <ng-content select=\"[slot=actions]\"></ng-content>\n    </footer>\n  </aside>\n}\n", styles: [":host{display:contents;box-sizing:border-box;min-width:0;max-width:100%}.ui-shared-side-drawer__backdrop{position:fixed;inset:0;z-index:var(--ui-z-drawer, 900)}.ui-shared-side-drawer{position:fixed;top:0;right:0;z-index:calc(var(--ui-z-drawer, 900) + 1);display:flex;flex-direction:column;width:min(var(--side-drawer-w),100vw);height:var(--ui-viewport-h, 100dvh);max-height:var(--ui-viewport-h, 100dvh);overflow:hidden}.ui-shared-side-drawer__head,.ui-shared-side-drawer__actions{flex:0 0 auto;display:flex;align-items:center}.ui-shared-side-drawer__head{justify-content:space-between}.ui-shared-side-drawer__actions{justify-content:flex-end}.ui-shared-side-drawer__actions:empty{display:none}.ui-shared-side-drawer__body{flex:1 1 auto;min-height:0;overflow-y:auto}@media(max-width:600px){.ui-shared-side-drawer{width:100vw}}\n"] }]
        }], propDecorators: { onEscape: [{
                type: HostListener,
                args: ['document:keydown.escape', ['$event']]
            }] } });

/**
 * Generic show/hide + drag-resizable side panel for a shell layout. Consumers
 * project the nav body and the main content via named slots:
 *
 * ```html
 * <ui-shared-side-panel storageKey="admin-shell">
 *   <div slot="nav">…sidenav head + nav list…</div>
 *   <div slot="content"><router-outlet /></div>
 * </ui-shared-side-panel>
 * ```
 *
 * Behaviour:
 *  - **Show / hide.** A toggle button collapses the panel to a slim rail.
 *    A second toggle at the rail edge expands it back to the saved width.
 *  - **Drag-resize.** Grab the vertical handle on the right edge of the
 *    expanded panel and drag to set the width. Width is clamped to
 *    `[minWidth, maxWidth]`.
 *  - **Persistence.** Both the collapsed flag and the current width are
 *    written to `localStorage` under `ui.sidePanel.<storageKey>` so each
 *    shell remembers its own layout independently across sessions.
 *
 * The rail sticks below the host's header: set `--header-h` (or `--ui-sticky-top`).
 * While dragging, `body` carries the `ui-resizing` class so the host can force
 * the column-resize cursor globally.
 */
class UiSharedSidePanelComponent {
    /** Unique storage key — e.g. "admin-shell". Required. */
    storageKey = input.required();
    /** Default expanded width (px) when nothing is in localStorage. */
    defaultWidth = input(248, { transform: numberAttribute });
    /** Minimum drag width (px). Anything below clamps up. */
    minWidth = input(200, { transform: numberAttribute });
    /** Maximum drag width (px). Anything above clamps down. */
    maxWidth = input(480, { transform: numberAttribute });
    /** Width of the slim "collapsed" rail that hosts the expand toggle. */
    railWidth = 36;
    host = inject(ElementRef);
    zone = inject(NgZone);
    width = signal(248);
    collapsed = signal(false);
    /** True while the user is dragging the resize handle. */
    dragging = signal(false);
    stopDrag = null;
    constructor() {
        effect(() => {
            const state = this.readState(this.storageKey());
            if (state) {
                this.collapsed.set(state.collapsed);
                this.width.set(this.clamp(state.width));
            }
            else {
                this.width.set(this.clamp(this.defaultWidth()));
            }
        });
        effect(() => {
            const key = this.storageKey();
            if (!key)
                return;
            uiStorage.setJson(this.storageKeyFor(key), { collapsed: this.collapsed(), width: this.width() });
        });
    }
    ngOnDestroy() {
        this.stopDrag?.();
    }
    toggleCollapsed() {
        this.collapsed.update(v => !v);
    }
    /** Pointerdown on the resize handle — start tracking width. */
    startDrag(ev) {
        if (this.collapsed())
            return;
        ev.preventDefault();
        this.dragging.set(true);
        const left = this.host.nativeElement.getBoundingClientRect().left;
        this.stopDrag = trackPointerDrag(this.zone, e => this.width.set(this.clamp(e.clientX - left)), () => { this.dragging.set(false); this.stopDrag = null; });
    }
    clamp(w) {
        return Math.max(this.minWidth(), Math.min(this.maxWidth(), Math.round(w)));
    }
    storageKeyFor(key) {
        return `ui.sidePanel.${key}`;
    }
    readState(key) {
        const saved = uiStorage.getJson(this.storageKeyFor(key));
        const width = Number(saved?.width);
        return saved && Number.isFinite(width) ? { collapsed: !!saved.collapsed, width } : null;
    }
    get widthVar() {
        return this.collapsed() ? this.railWidth : this.width();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedSidePanelComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: UiSharedSidePanelComponent, isStandalone: true, selector: "ui-shared-side-panel", inputs: { storageKey: { classPropertyName: "storageKey", publicName: "storageKey", isSignal: true, isRequired: true, transformFunction: null }, defaultWidth: { classPropertyName: "defaultWidth", publicName: "defaultWidth", isSignal: true, isRequired: false, transformFunction: null }, minWidth: { classPropertyName: "minWidth", publicName: "minWidth", isSignal: true, isRequired: false, transformFunction: null }, maxWidth: { classPropertyName: "maxWidth", publicName: "maxWidth", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "style.--side-panel-width.px": "this.widthVar" } }, ngImport: i0, template: "<div class=\"ui-shared-side-panel\" [class.ui-shared-side-panel--collapsed]=\"collapsed()\" [class.ui-shared-side-panel--dragging]=\"dragging()\">\n  <aside class=\"ui-shared-side-panel__nav\">\n    <div class=\"ui-shared-side-panel__nav-sticky\">\n      @if (!collapsed()) {\n        <div class=\"ui-shared-side-panel__nav-body\">\n          <ng-content select=\"[slot=nav]\" />\n        </div>\n\n        <div class=\"ui-shared-side-panel__handle\"\n             (pointerdown)=\"startDrag($event)\"\n             role=\"separator\"\n             aria-orientation=\"vertical\"\n             [attr.aria-label]=\"'sidePanel.resize' | uiTranslate\">\n          <span class=\"ui-shared-side-panel__handle-grip\"></span>\n        </div>\n      }\n\n      <button type=\"button\"\n              class=\"ui-shared-side-panel__toggle\"\n              [class.ui-shared-side-panel__toggle--rail]=\"collapsed()\"\n              (click)=\"toggleCollapsed()\"\n              [matTooltip]=\"(collapsed() ? 'sidePanel.show' : 'sidePanel.hide') | uiTranslate\"\n              matTooltipPosition=\"right\"\n              [attr.aria-label]=\"(collapsed() ? 'sidePanel.show' : 'sidePanel.hide') | uiTranslate\">\n        <mat-icon>{{ collapsed() ? 'chevron_right' : 'chevron_left' }}</mat-icon>\n      </button>\n    </div>\n  </aside>\n\n  <section class=\"ui-shared-side-panel__content\">\n    <ng-content select=\"[slot=content]\" />\n  </section>\n</div>\n", styles: [":host{display:flex;box-sizing:border-box;min-width:0;max-width:100%}:host{flex-direction:column;flex:1 0 auto}.ui-shared-side-panel{flex:1 0 auto;display:flex;align-items:stretch}.ui-shared-side-panel__nav{position:relative;flex-shrink:0;width:var(--side-panel-width, 248px)}.ui-shared-side-panel--dragging .ui-shared-side-panel__nav{transition:none;-webkit-user-select:none;user-select:none}.ui-shared-side-panel__nav-sticky{position:sticky;top:var(--ui-sticky-top, 0px);z-index:5;display:flex;flex-direction:column;max-height:calc(var(--ui-viewport-h, 100dvh) - var(--ui-sticky-top, 0px));min-height:min(100%,var(--ui-viewport-h, 100dvh) - var(--ui-sticky-top, 0px))}.ui-shared-side-panel__nav-body{flex:1 1 auto;min-height:0;overflow-x:hidden;overflow-y:auto}.ui-shared-side-panel__handle{position:absolute;top:0;right:0;width:8px;height:100%;display:grid;place-items:center;cursor:col-resize}.ui-shared-side-panel__toggle{position:absolute;top:.6rem;right:.4rem;display:grid;place-items:center;cursor:pointer}.ui-shared-side-panel__toggle--rail{position:relative;top:auto;right:auto;display:flex;margin-left:auto;margin-right:auto}.ui-shared-side-panel__content{flex:1;min-width:0}\n"], dependencies: [{ kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i1.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "directive", type: i2.MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }, { kind: "pipe", type: UiTranslatePipe, name: "uiTranslate" }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedSidePanelComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ui-shared-side-panel', standalone: true, imports: [MatIconModule, MatTooltipModule, UiTranslatePipe], template: "<div class=\"ui-shared-side-panel\" [class.ui-shared-side-panel--collapsed]=\"collapsed()\" [class.ui-shared-side-panel--dragging]=\"dragging()\">\n  <aside class=\"ui-shared-side-panel__nav\">\n    <div class=\"ui-shared-side-panel__nav-sticky\">\n      @if (!collapsed()) {\n        <div class=\"ui-shared-side-panel__nav-body\">\n          <ng-content select=\"[slot=nav]\" />\n        </div>\n\n        <div class=\"ui-shared-side-panel__handle\"\n             (pointerdown)=\"startDrag($event)\"\n             role=\"separator\"\n             aria-orientation=\"vertical\"\n             [attr.aria-label]=\"'sidePanel.resize' | uiTranslate\">\n          <span class=\"ui-shared-side-panel__handle-grip\"></span>\n        </div>\n      }\n\n      <button type=\"button\"\n              class=\"ui-shared-side-panel__toggle\"\n              [class.ui-shared-side-panel__toggle--rail]=\"collapsed()\"\n              (click)=\"toggleCollapsed()\"\n              [matTooltip]=\"(collapsed() ? 'sidePanel.show' : 'sidePanel.hide') | uiTranslate\"\n              matTooltipPosition=\"right\"\n              [attr.aria-label]=\"(collapsed() ? 'sidePanel.show' : 'sidePanel.hide') | uiTranslate\">\n        <mat-icon>{{ collapsed() ? 'chevron_right' : 'chevron_left' }}</mat-icon>\n      </button>\n    </div>\n  </aside>\n\n  <section class=\"ui-shared-side-panel__content\">\n    <ng-content select=\"[slot=content]\" />\n  </section>\n</div>\n", styles: [":host{display:flex;box-sizing:border-box;min-width:0;max-width:100%}:host{flex-direction:column;flex:1 0 auto}.ui-shared-side-panel{flex:1 0 auto;display:flex;align-items:stretch}.ui-shared-side-panel__nav{position:relative;flex-shrink:0;width:var(--side-panel-width, 248px)}.ui-shared-side-panel--dragging .ui-shared-side-panel__nav{transition:none;-webkit-user-select:none;user-select:none}.ui-shared-side-panel__nav-sticky{position:sticky;top:var(--ui-sticky-top, 0px);z-index:5;display:flex;flex-direction:column;max-height:calc(var(--ui-viewport-h, 100dvh) - var(--ui-sticky-top, 0px));min-height:min(100%,var(--ui-viewport-h, 100dvh) - var(--ui-sticky-top, 0px))}.ui-shared-side-panel__nav-body{flex:1 1 auto;min-height:0;overflow-x:hidden;overflow-y:auto}.ui-shared-side-panel__handle{position:absolute;top:0;right:0;width:8px;height:100%;display:grid;place-items:center;cursor:col-resize}.ui-shared-side-panel__toggle{position:absolute;top:.6rem;right:.4rem;display:grid;place-items:center;cursor:pointer}.ui-shared-side-panel__toggle--rail{position:relative;top:auto;right:auto;display:flex;margin-left:auto;margin-right:auto}.ui-shared-side-panel__content{flex:1;min-width:0}\n"] }]
        }], ctorParameters: () => [], propDecorators: { widthVar: [{
                type: HostBinding,
                args: ['style.--side-panel-width.px']
            }] } });

/** Hairline rule between sections or menu groups; `vertical` for toolbars. */
class UiSharedDividerComponent {
    vertical = input(false, { transform: booleanAttribute });
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedDividerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "19.2.25", type: UiSharedDividerComponent, isStandalone: true, selector: "ui-shared-divider", inputs: { vertical: { classPropertyName: "vertical", publicName: "vertical", isSignal: true, isRequired: false, transformFunction: null } }, host: { attributes: { "role": "separator" }, properties: { "class.ui-shared-divider--vertical": "vertical()" }, classAttribute: "ui-shared-divider" }, ngImport: i0, template: "\n", styles: [":host{display:block;box-sizing:border-box;min-width:0;max-width:100%}:host(.ui-shared-divider--vertical){display:inline-block;align-self:stretch}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedDividerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ui-shared-divider', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, host: { class: 'ui-shared-divider', role: 'separator', '[class.ui-shared-divider--vertical]': 'vertical()' }, template: "\n", styles: [":host{display:block;box-sizing:border-box;min-width:0;max-width:100%}:host(.ui-shared-divider--vertical){display:inline-block;align-self:stretch}\n"] }]
        }] });

/**
 * One tab of <ui-shared-tabs>. Its content renders lazily, only while selected.
 * Label: `labelKey` (translated) or `label` (raw text). With `link` the tab is a route.
 */
class UiSharedTabComponent {
    labelKey = input('');
    label = input('');
    /** Routed tab: a routerLink target (relative to the current route). The tabs strip then navigates and the app's <router-outlet> shows the page. */
    link = input(null);
    icon = input('');
    content = viewChild.required('content');
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedTabComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.2.0", version: "19.2.25", type: UiSharedTabComponent, isStandalone: true, selector: "ui-shared-tab", inputs: { labelKey: { classPropertyName: "labelKey", publicName: "labelKey", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, link: { classPropertyName: "link", publicName: "link", isSignal: true, isRequired: false, transformFunction: null }, icon: { classPropertyName: "icon", publicName: "icon", isSignal: true, isRequired: false, transformFunction: null } }, viewQueries: [{ propertyName: "content", first: true, predicate: ["content"], descendants: true, isSignal: true }], ngImport: i0, template: "<ng-template #content><ng-content /></ng-template>\n", styles: [":host{display:contents;box-sizing:border-box;min-width:0;max-width:100%}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedTabComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ui-shared-tab', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: "<ng-template #content><ng-content /></ng-template>\n", styles: [":host{display:contents;box-sizing:border-box;min-width:0;max-width:100%}\n"] }]
        }] });

/**
 * The one tab strip: flat labels, no animation, content rendered only for the
 * selected tab. `selected` / `(selectedChange)` for two-way state (query params).
 *
 *   <ui-shared-tabs [selected]="tab()" (selectedChange)="tab.set($event)">
 *     <ui-shared-tab labelKey="tenant.sales.tabs.sales"> ... </ui-shared-tab>
 *     <ui-shared-tab [label]="monthLabel()"> ... </ui-shared-tab>
 *   </ui-shared-tabs>
 *
 * Routed tabs: give every tab a `link` and put the page's <router-outlet> after the strip -
 * the strip is then a nav bar (each tab a URL, active by the router), the tabs carry no content.
 *
 *   <ui-shared-tabs>
 *     <ui-shared-tab link="info" labelKey="admin.companies.tabs.info" />
 *     <ui-shared-tab link="users" labelKey="admin.companies.tabs.users" />
 *   </ui-shared-tabs>
 *   <router-outlet />
 */
class UiSharedTabsComponent {
    selected = input(0, { transform: numberAttribute });
    selectedChange = output();
    tabs = contentChildren(UiSharedTabComponent);
    routed = computed(() => this.tabs().some(t => t.link() !== null));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedTabsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: UiSharedTabsComponent, isStandalone: true, selector: "ui-shared-tabs", inputs: { selected: { classPropertyName: "selected", publicName: "selected", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { selectedChange: "selectedChange" }, queries: [{ propertyName: "tabs", predicate: UiSharedTabComponent, isSignal: true }], ngImport: i0, template: "<ng-content />\n@if (routed()) {\n  <nav mat-tab-nav-bar class=\"ui-shared-tabs ui-shared-tabs--routed\" [tabPanel]=\"panel\" mat-stretch-tabs=\"false\" mat-align-tabs=\"start\" animationDuration=\"0ms\">\n    @for (tab of tabs(); track tab) {\n      <a mat-tab-link [routerLink]=\"tab.link()\" routerLinkActive #rla=\"routerLinkActive\" [active]=\"rla.isActive\">\n        {{ tab.labelKey() ? (tab.labelKey() | uiTranslate) : tab.label() }}\n      </a>\n    }\n  </nav>\n  <mat-tab-nav-panel #panel></mat-tab-nav-panel>\n} @else {\n<mat-tab-group class=\"ui-shared-tabs\" animationDuration=\"0ms\" mat-stretch-tabs=\"false\" mat-align-tabs=\"start\"\n               [dynamicHeight]=\"false\" [preserveContent]=\"false\"\n               [selectedIndex]=\"selected()\" (selectedIndexChange)=\"selectedChange.emit($event)\">\n  @for (tab of tabs(); track tab) {\n    <mat-tab [label]=\"tab.labelKey() ? (tab.labelKey() | uiTranslate) : tab.label()\">\n      <ng-template matTabContent><ng-container *ngTemplateOutlet=\"tab.content()\" /></ng-template>\n    </mat-tab>\n  }\n</mat-tab-group>\n}\n", styles: [":host{display:block;box-sizing:border-box;min-width:0;max-width:100%}\n"], dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "ngmodule", type: MatTabsModule }, { kind: "directive", type: i1$2.MatTabContent, selector: "[matTabContent]" }, { kind: "component", type: i1$2.MatTab, selector: "mat-tab", inputs: ["disabled", "label", "aria-label", "aria-labelledby", "labelClass", "bodyClass", "id"], exportAs: ["matTab"] }, { kind: "component", type: i1$2.MatTabGroup, selector: "mat-tab-group", inputs: ["color", "fitInkBarToContent", "mat-stretch-tabs", "mat-align-tabs", "dynamicHeight", "selectedIndex", "headerPosition", "animationDuration", "contentTabIndex", "disablePagination", "disableRipple", "preserveContent", "backgroundColor", "aria-label", "aria-labelledby"], outputs: ["selectedIndexChange", "focusChange", "animationDone", "selectedTabChange"], exportAs: ["matTabGroup"] }, { kind: "component", type: i1$2.MatTabNav, selector: "[mat-tab-nav-bar]", inputs: ["fitInkBarToContent", "mat-stretch-tabs", "animationDuration", "backgroundColor", "disableRipple", "color", "tabPanel"], exportAs: ["matTabNavBar", "matTabNav"] }, { kind: "component", type: i1$2.MatTabNavPanel, selector: "mat-tab-nav-panel", inputs: ["id"], exportAs: ["matTabNavPanel"] }, { kind: "component", type: i1$2.MatTabLink, selector: "[mat-tab-link], [matTabLink]", inputs: ["active", "disabled", "disableRipple", "tabIndex", "id"], exportAs: ["matTabLink"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "directive", type: RouterLinkActive, selector: "[routerLinkActive]", inputs: ["routerLinkActiveOptions", "ariaCurrentWhenActive", "routerLinkActive"], outputs: ["isActiveChange"], exportAs: ["routerLinkActive"] }, { kind: "pipe", type: UiTranslatePipe, name: "uiTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedTabsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ui-shared-tabs', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, imports: [NgTemplateOutlet, MatTabsModule, RouterLink, RouterLinkActive, UiTranslatePipe], template: "<ng-content />\n@if (routed()) {\n  <nav mat-tab-nav-bar class=\"ui-shared-tabs ui-shared-tabs--routed\" [tabPanel]=\"panel\" mat-stretch-tabs=\"false\" mat-align-tabs=\"start\" animationDuration=\"0ms\">\n    @for (tab of tabs(); track tab) {\n      <a mat-tab-link [routerLink]=\"tab.link()\" routerLinkActive #rla=\"routerLinkActive\" [active]=\"rla.isActive\">\n        {{ tab.labelKey() ? (tab.labelKey() | uiTranslate) : tab.label() }}\n      </a>\n    }\n  </nav>\n  <mat-tab-nav-panel #panel></mat-tab-nav-panel>\n} @else {\n<mat-tab-group class=\"ui-shared-tabs\" animationDuration=\"0ms\" mat-stretch-tabs=\"false\" mat-align-tabs=\"start\"\n               [dynamicHeight]=\"false\" [preserveContent]=\"false\"\n               [selectedIndex]=\"selected()\" (selectedIndexChange)=\"selectedChange.emit($event)\">\n  @for (tab of tabs(); track tab) {\n    <mat-tab [label]=\"tab.labelKey() ? (tab.labelKey() | uiTranslate) : tab.label()\">\n      <ng-template matTabContent><ng-container *ngTemplateOutlet=\"tab.content()\" /></ng-template>\n    </mat-tab>\n  }\n</mat-tab-group>\n}\n", styles: [":host{display:block;box-sizing:border-box;min-width:0;max-width:100%}\n"] }]
        }] });

/** Vertical shell navigation: a column of <ui-shared-nav-item> and <ui-shared-nav-group> labels. */
class UiSharedNavListComponent {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedNavListComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.25", type: UiSharedNavListComponent, isStandalone: true, selector: "ui-shared-nav-list", host: { attributes: { "role": "navigation" }, classAttribute: "ui-shared-nav-list" }, ngImport: i0, template: "<ng-content />\n", styles: [":host{display:flex;box-sizing:border-box;min-width:0;max-width:100%}:host{flex-direction:column}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedNavListComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ui-shared-nav-list', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, host: { class: 'ui-shared-nav-list', role: 'navigation' }, template: "<ng-content />\n", styles: [":host{display:flex;box-sizing:border-box;min-width:0;max-width:100%}:host{flex-direction:column}\n"] }]
        }] });

/** One routed entry of <ui-shared-nav-list>: icon + label, highlighted while its route is active. */
class UiSharedNavItemComponent {
    link = input.required();
    icon = input('');
    labelKey = input.required();
    /** Highlight only on an exact route match (for the index route). */
    exact = input(false, { transform: booleanAttribute });
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedNavItemComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "19.2.25", type: UiSharedNavItemComponent, isStandalone: true, selector: "ui-shared-nav-item", inputs: { link: { classPropertyName: "link", publicName: "link", isSignal: true, isRequired: true, transformFunction: null }, icon: { classPropertyName: "icon", publicName: "icon", isSignal: true, isRequired: false, transformFunction: null }, labelKey: { classPropertyName: "labelKey", publicName: "labelKey", isSignal: true, isRequired: true, transformFunction: null }, exact: { classPropertyName: "exact", publicName: "exact", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: "<a class=\"ui-shared-nav-item\" [routerLink]=\"link()\" routerLinkActive=\"ui-shared-nav-item--active\" [routerLinkActiveOptions]=\"{ exact: exact() }\">\n  <ui-shared-button-content [icon]=\"icon()\" [labelKey]=\"labelKey()\" />\n</a>\n", styles: [":host{display:block;box-sizing:border-box;min-width:0;max-width:100%}.ui-shared-nav-item{display:flex;align-items:center}.ui-shared-nav-item__label{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\n"], dependencies: [{ kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "directive", type: RouterLinkActive, selector: "[routerLinkActive]", inputs: ["routerLinkActiveOptions", "ariaCurrentWhenActive", "routerLinkActive"], outputs: ["isActiveChange"], exportAs: ["routerLinkActive"] }, { kind: "component", type: UiSharedButtonContentComponent, selector: "ui-shared-button-content", inputs: ["icon", "iconEnd", "labelKey", "label", "loading", "loadingKey"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedNavItemComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ui-shared-nav-item', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, imports: [RouterLink, RouterLinkActive, UiSharedButtonContentComponent], template: "<a class=\"ui-shared-nav-item\" [routerLink]=\"link()\" routerLinkActive=\"ui-shared-nav-item--active\" [routerLinkActiveOptions]=\"{ exact: exact() }\">\n  <ui-shared-button-content [icon]=\"icon()\" [labelKey]=\"labelKey()\" />\n</a>\n", styles: [":host{display:block;box-sizing:border-box;min-width:0;max-width:100%}.ui-shared-nav-item{display:flex;align-items:center}.ui-shared-nav-item__label{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\n"] }]
        }] });

/** Small uppercase label that opens a section of <ui-shared-nav-list>. */
class UiSharedNavGroupComponent {
    labelKey = input.required();
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedNavGroupComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "19.2.25", type: UiSharedNavGroupComponent, isStandalone: true, selector: "ui-shared-nav-group", inputs: { labelKey: { classPropertyName: "labelKey", publicName: "labelKey", isSignal: true, isRequired: true, transformFunction: null } }, host: { classAttribute: "ui-shared-nav-group" }, ngImport: i0, template: "{{ labelKey() | uiTranslate }}\n", styles: [":host{display:block;box-sizing:border-box;min-width:0;max-width:100%}\n"], dependencies: [{ kind: "pipe", type: UiTranslatePipe, name: "uiTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedNavGroupComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ui-shared-nav-group', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, imports: [UiTranslatePipe], host: { class: 'ui-shared-nav-group' }, template: "{{ labelKey() | uiTranslate }}\n", styles: [":host{display:block;box-sizing:border-box;min-width:0;max-width:100%}\n"] }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { UI_BREADCRUMBS, UiBreadcrumbLabels, UiSharedBreadcrumbComponent, UiSharedCollapsiblePanelComponent, UiSharedDividerComponent, UiSharedNavGroupComponent, UiSharedNavItemComponent, UiSharedNavListComponent, UiSharedPageHeaderComponent, UiSharedSideDrawerComponent, UiSharedSidePanelComponent, UiSharedTabComponent, UiSharedTabsComponent, provideUiBreadcrumbs, resolveUiBreadcrumbs };
//# sourceMappingURL=borassoft-ui-components-layout.mjs.map
