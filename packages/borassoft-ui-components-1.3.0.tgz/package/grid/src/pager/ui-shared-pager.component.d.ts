import { FormControl } from '@angular/forms';
import { SelectOption } from '@borassoft/ui-components';
import * as i0 from "@angular/core";
/**
 * Kendo-style pager: first / prev / page numbers (with ellipsis) / next /
 * last, plus a page-size dropdown and a "showing N–M of T" summary.
 *
 * Inputs are reactive (signals); navigation triggers <c>pageChange</c> /
 * <c>pageSizeChange</c> outputs — the parent (CoreGrid) owns the source of
 * truth and re-renders as the bound signals update.
 *
 * Page numbers are 1-based (matches OData $skip semantics and reads
 * naturally in the UI).
 */
export declare class UiSharedPagerComponent {
    /** Current page (1-based). */
    page: import("@angular/core").InputSignal<number>;
    /** Rows per page. */
    pageSize: import("@angular/core").InputSignal<number>;
    /** Total rows in the unfiltered dataset (reported by the server). */
    total: import("@angular/core").InputSignal<number>;
    /** Page-size options. Defaults to a common spread. */
    pageSizeOptions: import("@angular/core").InputSignal<number[]>;
    pageChange: import("@angular/core").OutputEmitterRef<number>;
    pageSizeChange: import("@angular/core").OutputEmitterRef<number>;
    /** Total number of pages (at least 1, so the pager always renders). */
    protected totalPages: import("@angular/core").Signal<number>;
    /** 1-based start index of the visible window for the summary line. */
    protected from: import("@angular/core").Signal<number>;
    /** 1-based end index of the visible window for the summary line. */
    protected to: import("@angular/core").Signal<number>;
    /**
     * The page-number buttons to render between Prev and Next.
     * `null` represents an ellipsis gap. Algorithm:
     *   - Always show first + last
     *   - Show current ± 1
     *   - Insert "…" wherever gaps appear
     */
    protected visiblePages: import("@angular/core").Signal<(number | null)[]>;
    goTo(p: number): void;
    /** The page-size dropdown is the shared select, so it matches every other dropdown. */
    protected sizeControl: FormControl<number | null>;
    protected sizeOptions: import("@angular/core").Signal<SelectOption<number>[]>;
    constructor();
    protected canPrev: import("@angular/core").Signal<boolean>;
    protected canNext: import("@angular/core").Signal<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UiSharedPagerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UiSharedPagerComponent, "ui-shared-pager", never, { "page": { "alias": "page"; "required": true; "isSignal": true; }; "pageSize": { "alias": "pageSize"; "required": true; "isSignal": true; }; "total": { "alias": "total"; "required": true; "isSignal": true; }; "pageSizeOptions": { "alias": "pageSizeOptions"; "required": false; "isSignal": true; }; }, { "pageChange": "pageChange"; "pageSizeChange": "pageSizeChange"; }, never, never, true, never>;
}
//# sourceMappingURL=ui-shared-pager.component.d.ts.map