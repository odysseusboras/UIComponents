import * as i0 from '@angular/core';
import { inject, DestroyRef, signal, computed, booleanAttribute, Input, Component, input, numberAttribute, output, ChangeDetectionStrategy, effect, Injector, afterNextRender, forwardRef, ViewChild } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import * as i1 from '@angular/forms';
import { FormControl, Validators, ReactiveFormsModule, NG_VALUE_ACCESSOR } from '@angular/forms';
import * as i4 from '@angular/material/autocomplete';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import * as i2 from '@angular/material/form-field';
import { MatFormFieldModule } from '@angular/material/form-field';
import * as i5 from '@angular/material/icon';
import { MatIconModule } from '@angular/material/icon';
import * as i3 from '@angular/material/input';
import { MatInputModule } from '@angular/material/input';
import { firstError, UI_TRANSLATE, GridFilterState, storedChoice, storeChoice, optionText, odataLiteral, UiTranslatePipe, UiOptionTextPipe, provideGridFilter, odataString, eqClause } from '@borassoft/ui-components';
import * as i1$1 from '@angular/material/button';
import { MatButtonModule } from '@angular/material/button';
import * as i3$1 from '@angular/material/tooltip';
import { MatTooltipModule } from '@angular/material/tooltip';
import * as i4$1 from '@angular/material/datepicker';
import { MatDatepickerModule } from '@angular/material/datepicker';
import * as i2$1 from '@angular/material/checkbox';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { NgTemplateOutlet } from '@angular/common';
import * as i2$2 from '@angular/material/slide-toggle';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import * as i2$3 from '@angular/material/radio';
import { MatRadioModule } from '@angular/material/radio';
import * as i2$4 from '@angular/material/button-toggle';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { DomSanitizer } from '@angular/platform-browser';

/**
 * The one dropdown. Every dropdown is editable: typing filters the options
 * (label or value, case-insensitive), arrows / Enter / click pick one, and the
 * input shows the picked option's label. The control holds the option VALUE.
 *
 *  - strict (default): only option values reach the control; text that matches
 *    no option is put back to the current choice when the field is left.
 *    Clearing the text sets `''` (use `nullable` to also offer an explicit "none").
 *  - `freeText`: any typed text is a value too (codes, numbers the list may not have).
 *
 * `disableWhenEmpty` disables the control while there are no options (cascade
 * children); it re-enables only when the control's group is enabled.
 *
 * Inside `<ui-shared-grid>` with `field` (or `[clauseBuilder]`) it is a grid filter;
 * `storageKey` remembers the choice in the browser (the options must be known on init).
 *
 *   <ui-shared-select [control]="form.controls.country" labelKey="form.country" [options]="countries" nullable />
 *   <ui-shared-select [control]="form.controls.mark" labelKey="form.mark" [options]="marks" freeText inputMode="numeric" />
 *   <ui-shared-select labelKey="users.role" [options]="roles" field="Role" />
 */
class UiSharedSelectComponent {
    /** Optional when used as a grid filter. */
    set control(c) {
        this._control = c;
        this.syncText();
    }
    get control() { return this._control; }
    labelKey = '';
    set options(value) {
        this.allOptions.set(value ?? []);
        this.syncText();
    }
    get options() { return this.allOptions(); }
    /** Accept typed text that matches no option. */
    freeText = false;
    nullable = false;
    nullLabelKey = 'common.none';
    hintKey;
    /** Already translated hint text — for hints built at runtime. */
    hintText;
    emptyHintKey;
    disableWhenEmpty = false;
    /** Mobile keyboard hint (`numeric` for digit-only codes); it does not validate the value. */
    inputMode = 'text';
    /** Grid filter: OData field compared with `eq` against the option value. */
    field;
    /** Grid filter: custom clause for the value (overrides `field`). */
    clauseBuilder;
    /** Grid filter: value selected on load and restored by Clear. */
    initial = null;
    /** Remember the choice in the browser under this key. */
    storageKey;
    /** What the input shows; the bound control only ever receives values. */
    text = new FormControl('', { nonNullable: true });
    firstError = firstError;
    /** Errors belong to the bound control, not to the text the user is typing. */
    errorMatcher = { isErrorState: () => !!firstError(this.control) };
    translate = inject(UI_TRANSLATE);
    destroyRef = inject(DestroyRef);
    allOptions = signal([]);
    query = signal('');
    typing = false;
    /** The control value the input text was last derived from. */
    shownValue;
    _control = new FormControl(null);
    filter = new GridFilterState(() => this.control, () => this.clauseBuilder ?? this.optionEq(), () => this.initial);
    filtered = computed(() => {
        const q = this.query().trim().toLowerCase();
        const all = this.allOptions();
        if (!q)
            return all;
        return all.filter(o => this.label(o).toLowerCase().includes(q) || String(o.value).toLowerCase().includes(q));
    });
    get required() { return this.control.hasValidator(Validators.required); }
    /**
     * Callers often change the control with `{ emitEvent: false }` (a loading
     * lock, a mirrored selection), which raises no event — so the input follows
     * the control's value and disabled state on every check instead.
     */
    ngDoCheck() {
        if (this.control.value !== this.shownValue)
            this.syncText();
        this.syncDisabled();
    }
    ngOnInit() {
        this.filter.init();
        const key = this.storageKey;
        if (!key)
            return;
        const saved = storedChoice(key, this.options.map(o => o.value));
        if (saved !== null)
            this.filter.restore(saved);
        this.control.valueChanges
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe(v => storeChoice(key, v));
    }
    ngOnChanges() {
        if (!this.disableWhenEmpty)
            return;
        const empty = this.options.length === 0;
        if (empty && this.control.enabled) {
            this.control.disable({ emitEvent: false });
        }
        else if (!empty && this.control.disabled && !this.control.parent?.disabled) {
            // A parent-level lock (a read-only section) disables whole groups;
            // options arriving later must not undo it per control.
            this.control.enable({ emitEvent: false });
        }
        this.syncDisabled();
    }
    /**
     * Material's trigger writes EVERY value the input shows through this: the
     * picked option value (→ its label) and the text we set (a label already).
     */
    displayWith = (value) => {
        const o = this.allOptions().find(x => x.value === value);
        return o ? this.label(o) : value === null || value === undefined ? '' : String(value);
    };
    onInput(event) {
        const typed = event.target.value;
        this.query.set(typed);
        const key = typed.trim().toLowerCase();
        const match = key
            ? this.allOptions().find(o => this.label(o).toLowerCase() === key || String(o.value).toLowerCase() === key)
            : undefined;
        const next = !key ? '' : match ? match.value : this.freeText ? typed : undefined;
        if (next === undefined)
            return;
        this.typing = true;
        // Dirty FIRST: setValue emits valueChanges synchronously, and subscribers
        // tell a user pick from a programmatic patch by that flag.
        this.control.markAsDirty();
        this.control.setValue(next);
        this.typing = false;
    }
    onPick(event) {
        this.control.markAsDirty();
        this.control.setValue(event.option.value);
        this.query.set('');
        this.syncText();
    }
    onFocus(event) {
        event.target.select();
    }
    onBlur() {
        this.control.markAsTouched();
        this.query.set('');
        this.syncText();
    }
    toggle(trigger, input) {
        if (this.text.disabled)
            return;
        if (trigger.panelOpen) {
            trigger.closePanel();
        }
        else {
            input.focus();
            trigger.openPanel();
        }
    }
    syncText() {
        if (this.typing)
            return;
        this.shownValue = this.control.value;
        const t = this.textOf(this.shownValue);
        if (t !== this.text.value)
            this.text.setValue(t, { emitEvent: false });
    }
    syncDisabled() {
        const disabled = this.control.disabled;
        if (disabled === this.text.disabled)
            return;
        if (disabled)
            this.text.disable({ emitEvent: false });
        else
            this.text.enable({ emitEvent: false });
    }
    /** The option's label; free text as typed; nothing for a value the options don't (yet) hold. */
    textOf(value) {
        if (value === null || value === undefined || value === '')
            return '';
        const o = this.allOptions().find(x => x.value === value);
        return o ? this.label(o) : this.freeText ? String(value) : '';
    }
    label(o) { return optionText(o, this.translate); }
    optionEq() {
        const field = this.field;
        if (!field)
            return null;
        return v => (this.allOptions().some(o => o.value === v) ? `${field} eq ${odataLiteral(v)}` : null);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedSelectComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: UiSharedSelectComponent, isStandalone: true, selector: "ui-shared-select", inputs: { control: "control", labelKey: "labelKey", options: "options", freeText: ["freeText", "freeText", booleanAttribute], nullable: ["nullable", "nullable", booleanAttribute], nullLabelKey: "nullLabelKey", hintKey: "hintKey", hintText: "hintText", emptyHintKey: "emptyHintKey", disableWhenEmpty: ["disableWhenEmpty", "disableWhenEmpty", booleanAttribute], inputMode: "inputMode", field: "field", clauseBuilder: "clauseBuilder", initial: "initial", storageKey: "storageKey" }, host: { properties: { "class.ui-shared-filter": "filter.isFilter()" } }, providers: [provideGridFilter(() => UiSharedSelectComponent)], usesOnChanges: true, ngImport: i0, template: "<mat-form-field appearance=\"outline\" subscriptSizing=\"dynamic\">\n  <mat-label>{{ labelKey | uiTranslate }}</mat-label>\n  <input matInput #input type=\"text\" autocomplete=\"off\"\n         [formControl]=\"text\"\n         [required]=\"required\"\n         [errorStateMatcher]=\"errorMatcher\"\n         [attr.inputmode]=\"inputMode\"\n         [matAutocomplete]=\"panel\" #trigger=\"matAutocompleteTrigger\"\n         (input)=\"onInput($event)\"\n         (focus)=\"onFocus($event)\"\n         (blur)=\"onBlur()\" />\n  <mat-autocomplete #panel=\"matAutocomplete\" autoActiveFirstOption\n                    [displayWith]=\"displayWith\"\n                    (optionSelected)=\"onPick($event)\">\n    @if (nullable) {\n      <mat-option [value]=\"''\">{{ nullLabelKey | uiTranslate }}</mat-option>\n    }\n    @for (o of filtered(); track o.value) {\n      <mat-option [value]=\"o.value\">{{ o | uiOptionText }}</mat-option>\n    } @empty {\n      @if (emptyHintKey) {\n        <mat-option disabled>{{ emptyHintKey | uiTranslate }}</mat-option>\n      }\n    }\n  </mat-autocomplete>\n  <ng-content select=\"[suffix]\" ngProjectAs=\"[matSuffix]\" />\n  <mat-icon matSuffix class=\"ui-shared-select__arrow\"\n            (mousedown)=\"$event.preventDefault()\"\n            (click)=\"toggle(trigger, input)\">arrow_drop_down</mat-icon>\n  @if (hintText || hintKey) {\n    <mat-hint>{{ hintText || ((hintKey ?? '') | uiTranslate) }}</mat-hint>\n  }\n  @if (firstError(control); as err) {\n    <mat-error>{{ err | uiTranslate }}</mat-error>\n  }\n</mat-form-field>\n", styles: [":host{display:block;box-sizing:border-box;min-width:0;max-width:100%}:host{width:100%}:host(.ui-shared-filter){width:var(--ui-filter-width, 260px)}mat-form-field{width:100%}.ui-shared-select__arrow{cursor:pointer}\n"], dependencies: [{ kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.RequiredValidator, selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]", inputs: ["required"] }, { kind: "directive", type: i1.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "component", type: i2.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i2.MatLabel, selector: "mat-label" }, { kind: "directive", type: i2.MatHint, selector: "mat-hint", inputs: ["align", "id"] }, { kind: "directive", type: i2.MatError, selector: "mat-error, [matError]", inputs: ["id"] }, { kind: "directive", type: i2.MatSuffix, selector: "[matSuffix], [matIconSuffix], [matTextSuffix]", inputs: ["matTextSuffix"] }, { kind: "ngmodule", type: MatInputModule }, { kind: "directive", type: i3.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly", "disabledInteractive"], exportAs: ["matInput"] }, { kind: "ngmodule", type: MatAutocompleteModule }, { kind: "component", type: i4.MatAutocomplete, selector: "mat-autocomplete", inputs: ["aria-label", "aria-labelledby", "displayWith", "autoActiveFirstOption", "autoSelectActiveOption", "requireSelection", "panelWidth", "disableRipple", "class", "hideSingleSelectionIndicator"], outputs: ["optionSelected", "opened", "closed", "optionActivated"], exportAs: ["matAutocomplete"] }, { kind: "component", type: i4.MatOption, selector: "mat-option", inputs: ["value", "id", "disabled"], outputs: ["onSelectionChange"], exportAs: ["matOption"] }, { kind: "directive", type: i4.MatAutocompleteTrigger, selector: "input[matAutocomplete], textarea[matAutocomplete]", inputs: ["matAutocomplete", "matAutocompletePosition", "matAutocompleteConnectedTo", "autocomplete", "matAutocompleteDisabled"], exportAs: ["matAutocompleteTrigger"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i5.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "pipe", type: UiTranslatePipe, name: "uiTranslate" }, { kind: "pipe", type: UiOptionTextPipe, name: "uiOptionText" }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedSelectComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ui-shared-select', standalone: true, imports: [
                        ReactiveFormsModule, MatFormFieldModule, MatInputModule, MatAutocompleteModule, MatIconModule,
                        UiTranslatePipe, UiOptionTextPipe,
                    ], providers: [provideGridFilter(() => UiSharedSelectComponent)], host: { '[class.ui-shared-filter]': 'filter.isFilter()' }, template: "<mat-form-field appearance=\"outline\" subscriptSizing=\"dynamic\">\n  <mat-label>{{ labelKey | uiTranslate }}</mat-label>\n  <input matInput #input type=\"text\" autocomplete=\"off\"\n         [formControl]=\"text\"\n         [required]=\"required\"\n         [errorStateMatcher]=\"errorMatcher\"\n         [attr.inputmode]=\"inputMode\"\n         [matAutocomplete]=\"panel\" #trigger=\"matAutocompleteTrigger\"\n         (input)=\"onInput($event)\"\n         (focus)=\"onFocus($event)\"\n         (blur)=\"onBlur()\" />\n  <mat-autocomplete #panel=\"matAutocomplete\" autoActiveFirstOption\n                    [displayWith]=\"displayWith\"\n                    (optionSelected)=\"onPick($event)\">\n    @if (nullable) {\n      <mat-option [value]=\"''\">{{ nullLabelKey | uiTranslate }}</mat-option>\n    }\n    @for (o of filtered(); track o.value) {\n      <mat-option [value]=\"o.value\">{{ o | uiOptionText }}</mat-option>\n    } @empty {\n      @if (emptyHintKey) {\n        <mat-option disabled>{{ emptyHintKey | uiTranslate }}</mat-option>\n      }\n    }\n  </mat-autocomplete>\n  <ng-content select=\"[suffix]\" ngProjectAs=\"[matSuffix]\" />\n  <mat-icon matSuffix class=\"ui-shared-select__arrow\"\n            (mousedown)=\"$event.preventDefault()\"\n            (click)=\"toggle(trigger, input)\">arrow_drop_down</mat-icon>\n  @if (hintText || hintKey) {\n    <mat-hint>{{ hintText || ((hintKey ?? '') | uiTranslate) }}</mat-hint>\n  }\n  @if (firstError(control); as err) {\n    <mat-error>{{ err | uiTranslate }}</mat-error>\n  }\n</mat-form-field>\n", styles: [":host{display:block;box-sizing:border-box;min-width:0;max-width:100%}:host{width:100%}:host(.ui-shared-filter){width:var(--ui-filter-width, 260px)}mat-form-field{width:100%}.ui-shared-select__arrow{cursor:pointer}\n"] }]
        }], propDecorators: { control: [{
                type: Input
            }], labelKey: [{
                type: Input,
                args: [{ required: true }]
            }], options: [{
                type: Input
            }], freeText: [{
                type: Input,
                args: [{ transform: booleanAttribute }]
            }], nullable: [{
                type: Input,
                args: [{ transform: booleanAttribute }]
            }], nullLabelKey: [{
                type: Input
            }], hintKey: [{
                type: Input
            }], hintText: [{
                type: Input
            }], emptyHintKey: [{
                type: Input
            }], disableWhenEmpty: [{
                type: Input,
                args: [{ transform: booleanAttribute }]
            }], inputMode: [{
                type: Input
            }], field: [{
                type: Input
            }], clauseBuilder: [{
                type: Input
            }], initial: [{
                type: Input
            }], storageKey: [{
                type: Input
            }] } });

/**
 * The single password / secret-credential input used app-wide: masked by
 * default, with a trailing eye toggle that reveals the value until toggled
 * back. Takes the FormControl directly via [control] so the wrapped
 * mat-form-field surfaces validation errors through the shared firstError
 * helper without a CVA indirection.
 */
class UiSharedPasswordFieldComponent {
    control = input.required();
    labelKey = input.required();
    autocomplete = input('off');
    hintKey = input('');
    maxlength = input(null);
    subscriptSizing = input('fixed');
    revealed = signal(false);
    firstError = firstError;
    required = computed(() => this.control().hasValidator(Validators.required));
    toggle() {
        this.revealed.update(v => !v);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedPasswordFieldComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: UiSharedPasswordFieldComponent, isStandalone: true, selector: "ui-shared-password-field", inputs: { control: { classPropertyName: "control", publicName: "control", isSignal: true, isRequired: true, transformFunction: null }, labelKey: { classPropertyName: "labelKey", publicName: "labelKey", isSignal: true, isRequired: true, transformFunction: null }, autocomplete: { classPropertyName: "autocomplete", publicName: "autocomplete", isSignal: true, isRequired: false, transformFunction: null }, hintKey: { classPropertyName: "hintKey", publicName: "hintKey", isSignal: true, isRequired: false, transformFunction: null }, maxlength: { classPropertyName: "maxlength", publicName: "maxlength", isSignal: true, isRequired: false, transformFunction: null }, subscriptSizing: { classPropertyName: "subscriptSizing", publicName: "subscriptSizing", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: "<mat-form-field appearance=\"outline\" [subscriptSizing]=\"subscriptSizing()\">\n  <mat-label>{{ labelKey() | uiTranslate }}</mat-label>\n  <input matInput\n         [formControl]=\"control()\"\n         [type]=\"revealed() ? 'text' : 'password'\"\n         [required]=\"required()\"\n         [attr.autocomplete]=\"autocomplete()\"\n         [attr.maxlength]=\"maxlength()\"\n         autocapitalize=\"off\" spellcheck=\"false\" />\n  <button mat-icon-button matSuffix type=\"button\" (click)=\"toggle()\"\n          [matTooltip]=\"(revealed() ? 'form.password.hide' : 'form.password.show') | uiTranslate\"\n          [attr.aria-label]=\"(revealed() ? 'form.password.hide' : 'form.password.show') | uiTranslate\">\n    <mat-icon>{{ revealed() ? 'visibility_off' : 'visibility' }}</mat-icon>\n  </button>\n  @if (hintKey()) {\n    <mat-hint>{{ hintKey() | uiTranslate }}</mat-hint>\n  }\n  @if (firstError(control()); as key) {\n    <mat-error>{{ key | uiTranslate }}</mat-error>\n  }\n</mat-form-field>\n", styles: [":host{display:block;box-sizing:border-box;min-width:0;max-width:100%}:host{width:100%}:host(.ui-shared-filter){width:var(--ui-filter-width, 260px)}mat-form-field{width:100%}\n"], dependencies: [{ kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.RequiredValidator, selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]", inputs: ["required"] }, { kind: "directive", type: i1.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "component", type: i2.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i2.MatLabel, selector: "mat-label" }, { kind: "directive", type: i2.MatHint, selector: "mat-hint", inputs: ["align", "id"] }, { kind: "directive", type: i2.MatError, selector: "mat-error, [matError]", inputs: ["id"] }, { kind: "directive", type: i2.MatSuffix, selector: "[matSuffix], [matIconSuffix], [matTextSuffix]", inputs: ["matTextSuffix"] }, { kind: "ngmodule", type: MatInputModule }, { kind: "directive", type: i3.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly", "disabledInteractive"], exportAs: ["matInput"] }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i1$1.MatIconButton, selector: "button[mat-icon-button]", exportAs: ["matButton"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i5.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "directive", type: i3$1.MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }, { kind: "pipe", type: UiTranslatePipe, name: "uiTranslate" }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedPasswordFieldComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ui-shared-password-field', standalone: true, imports: [
                        ReactiveFormsModule,
                        MatFormFieldModule, MatInputModule, MatButtonModule, MatIconModule, MatTooltipModule,
                        UiTranslatePipe,
                    ], template: "<mat-form-field appearance=\"outline\" [subscriptSizing]=\"subscriptSizing()\">\n  <mat-label>{{ labelKey() | uiTranslate }}</mat-label>\n  <input matInput\n         [formControl]=\"control()\"\n         [type]=\"revealed() ? 'text' : 'password'\"\n         [required]=\"required()\"\n         [attr.autocomplete]=\"autocomplete()\"\n         [attr.maxlength]=\"maxlength()\"\n         autocapitalize=\"off\" spellcheck=\"false\" />\n  <button mat-icon-button matSuffix type=\"button\" (click)=\"toggle()\"\n          [matTooltip]=\"(revealed() ? 'form.password.hide' : 'form.password.show') | uiTranslate\"\n          [attr.aria-label]=\"(revealed() ? 'form.password.hide' : 'form.password.show') | uiTranslate\">\n    <mat-icon>{{ revealed() ? 'visibility_off' : 'visibility' }}</mat-icon>\n  </button>\n  @if (hintKey()) {\n    <mat-hint>{{ hintKey() | uiTranslate }}</mat-hint>\n  }\n  @if (firstError(control()); as key) {\n    <mat-error>{{ key | uiTranslate }}</mat-error>\n  }\n</mat-form-field>\n", styles: [":host{display:block;box-sizing:border-box;min-width:0;max-width:100%}:host{width:100%}:host(.ui-shared-filter){width:var(--ui-filter-width, 260px)}mat-form-field{width:100%}\n"] }]
        }] });

/**
 * The one single-line input: text, email, number, tel, url. Takes the
 * FormControl directly; the label / hint / errors are translation keys
 * resolved through UI_TRANSLATE. Project `[suffix]` / `[prefix]` content for
 * icons, buttons or unit text.
 *
 * Inside `<ui-shared-grid>` with `[fields]` it is a free-text grid filter
 * (`contains` on any of the fields; Enter runs the grid's Search):
 *
 *   <ui-shared-text-input labelKey="users.search" [fields]="['Name','Email']" />
 *
 *   <ui-shared-text-input [control]="form.controls.name" labelKey="form.name" maxlength="200" />
 *   <ui-shared-text-input [control]="form.controls.amount" labelKey="form.amount" type="number" min="0" step="0.01">
 *     <span suffix>€</span>
 *   </ui-shared-text-input>
 */
class UiSharedTextInputComponent {
    /** Optional when used as a grid filter. */
    control = input(null);
    labelKey = input.required();
    type = input('text');
    hintKey = input('');
    /** Already translated hint text — for hints built at runtime. */
    hintText = input('');
    placeholderKey = input('');
    maxlength = input(null);
    min = input(null);
    max = input(null);
    step = input(null);
    inputMode = input('');
    autocomplete = input('');
    readonly = input(false, { transform: booleanAttribute });
    subscriptSizing = input('dynamic');
    /** Grid filter: OData fields matched with `contains`. */
    fields = input([]);
    /** Grid filter: custom clause for the typed text (overrides `fields`). */
    clauseBuilder = input(null);
    own = new FormControl(null);
    ctrl = computed(() => this.control() ?? this.own);
    filter = new GridFilterState(() => this.ctrl(), () => this.clauseBuilder() ?? this.containsAny());
    firstError = firstError;
    required = computed(() => this.ctrl().hasValidator(Validators.required));
    containsAny() {
        const fields = this.fields();
        if (!fields.length)
            return null;
        return v => fields.map(f => `contains(tolower(${f}), ${odataString(v.toLowerCase())})`).join(' or ');
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedTextInputComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: UiSharedTextInputComponent, isStandalone: true, selector: "ui-shared-text-input", inputs: { control: { classPropertyName: "control", publicName: "control", isSignal: true, isRequired: false, transformFunction: null }, labelKey: { classPropertyName: "labelKey", publicName: "labelKey", isSignal: true, isRequired: true, transformFunction: null }, type: { classPropertyName: "type", publicName: "type", isSignal: true, isRequired: false, transformFunction: null }, hintKey: { classPropertyName: "hintKey", publicName: "hintKey", isSignal: true, isRequired: false, transformFunction: null }, hintText: { classPropertyName: "hintText", publicName: "hintText", isSignal: true, isRequired: false, transformFunction: null }, placeholderKey: { classPropertyName: "placeholderKey", publicName: "placeholderKey", isSignal: true, isRequired: false, transformFunction: null }, maxlength: { classPropertyName: "maxlength", publicName: "maxlength", isSignal: true, isRequired: false, transformFunction: null }, min: { classPropertyName: "min", publicName: "min", isSignal: true, isRequired: false, transformFunction: null }, max: { classPropertyName: "max", publicName: "max", isSignal: true, isRequired: false, transformFunction: null }, step: { classPropertyName: "step", publicName: "step", isSignal: true, isRequired: false, transformFunction: null }, inputMode: { classPropertyName: "inputMode", publicName: "inputMode", isSignal: true, isRequired: false, transformFunction: null }, autocomplete: { classPropertyName: "autocomplete", publicName: "autocomplete", isSignal: true, isRequired: false, transformFunction: null }, readonly: { classPropertyName: "readonly", publicName: "readonly", isSignal: true, isRequired: false, transformFunction: null }, subscriptSizing: { classPropertyName: "subscriptSizing", publicName: "subscriptSizing", isSignal: true, isRequired: false, transformFunction: null }, fields: { classPropertyName: "fields", publicName: "fields", isSignal: true, isRequired: false, transformFunction: null }, clauseBuilder: { classPropertyName: "clauseBuilder", publicName: "clauseBuilder", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class.ui-shared-filter": "filter.isFilter()" } }, providers: [provideGridFilter(() => UiSharedTextInputComponent)], ngImport: i0, template: "<mat-form-field appearance=\"outline\" [subscriptSizing]=\"subscriptSizing()\">\n  <mat-label>{{ labelKey() | uiTranslate }}</mat-label>\n  <ng-content select=\"[prefix]\" ngProjectAs=\"[matTextPrefix]\" />\n  <input matInput\n         [formControl]=\"ctrl()\"\n         [type]=\"type()\"\n         [required]=\"required()\"\n         [readonly]=\"readonly()\"\n         [attr.placeholder]=\"placeholderKey() ? (placeholderKey() | uiTranslate) : null\"\n         [attr.maxlength]=\"maxlength()\"\n         [attr.min]=\"min()\"\n         [attr.max]=\"max()\"\n         [attr.step]=\"step()\"\n         [attr.inputmode]=\"inputMode() || null\"\n         [attr.autocomplete]=\"autocomplete() || null\" />\n  <ng-content select=\"[suffix]\" ngProjectAs=\"[matSuffix]\" />\n  @if (hintText() || hintKey()) {\n    <mat-hint>{{ hintText() || (hintKey() | uiTranslate) }}</mat-hint>\n  }\n  @if (firstError(ctrl()); as key) {\n    <mat-error>{{ key | uiTranslate }}</mat-error>\n  }\n</mat-form-field>\n", styles: [":host{display:block;box-sizing:border-box;min-width:0;max-width:100%}:host{width:100%}:host(.ui-shared-filter){width:var(--ui-filter-width, 260px)}mat-form-field{width:100%}\n"], dependencies: [{ kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.RequiredValidator, selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]", inputs: ["required"] }, { kind: "directive", type: i1.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "component", type: i2.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i2.MatLabel, selector: "mat-label" }, { kind: "directive", type: i2.MatHint, selector: "mat-hint", inputs: ["align", "id"] }, { kind: "directive", type: i2.MatError, selector: "mat-error, [matError]", inputs: ["id"] }, { kind: "ngmodule", type: MatInputModule }, { kind: "directive", type: i3.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly", "disabledInteractive"], exportAs: ["matInput"] }, { kind: "pipe", type: UiTranslatePipe, name: "uiTranslate" }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedTextInputComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ui-shared-text-input', standalone: true, imports: [ReactiveFormsModule, MatFormFieldModule, MatInputModule, UiTranslatePipe], providers: [provideGridFilter(() => UiSharedTextInputComponent)], host: { '[class.ui-shared-filter]': 'filter.isFilter()' }, template: "<mat-form-field appearance=\"outline\" [subscriptSizing]=\"subscriptSizing()\">\n  <mat-label>{{ labelKey() | uiTranslate }}</mat-label>\n  <ng-content select=\"[prefix]\" ngProjectAs=\"[matTextPrefix]\" />\n  <input matInput\n         [formControl]=\"ctrl()\"\n         [type]=\"type()\"\n         [required]=\"required()\"\n         [readonly]=\"readonly()\"\n         [attr.placeholder]=\"placeholderKey() ? (placeholderKey() | uiTranslate) : null\"\n         [attr.maxlength]=\"maxlength()\"\n         [attr.min]=\"min()\"\n         [attr.max]=\"max()\"\n         [attr.step]=\"step()\"\n         [attr.inputmode]=\"inputMode() || null\"\n         [attr.autocomplete]=\"autocomplete() || null\" />\n  <ng-content select=\"[suffix]\" ngProjectAs=\"[matSuffix]\" />\n  @if (hintText() || hintKey()) {\n    <mat-hint>{{ hintText() || (hintKey() | uiTranslate) }}</mat-hint>\n  }\n  @if (firstError(ctrl()); as key) {\n    <mat-error>{{ key | uiTranslate }}</mat-error>\n  }\n</mat-form-field>\n", styles: [":host{display:block;box-sizing:border-box;min-width:0;max-width:100%}:host{width:100%}:host(.ui-shared-filter){width:var(--ui-filter-width, 260px)}mat-form-field{width:100%}\n"] }]
        }] });

/** The one multi-line input. Same contract as ui-shared-text-input, plus `rows`. */
class UiSharedTextareaInputComponent {
    control = input.required();
    labelKey = input.required();
    rows = input(3, { transform: numberAttribute });
    hintKey = input('');
    hintText = input('');
    maxlength = input(null);
    readonly = input(false, { transform: booleanAttribute });
    subscriptSizing = input('dynamic');
    firstError = firstError;
    required = computed(() => this.control().hasValidator(Validators.required));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedTextareaInputComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: UiSharedTextareaInputComponent, isStandalone: true, selector: "ui-shared-textarea-input", inputs: { control: { classPropertyName: "control", publicName: "control", isSignal: true, isRequired: true, transformFunction: null }, labelKey: { classPropertyName: "labelKey", publicName: "labelKey", isSignal: true, isRequired: true, transformFunction: null }, rows: { classPropertyName: "rows", publicName: "rows", isSignal: true, isRequired: false, transformFunction: null }, hintKey: { classPropertyName: "hintKey", publicName: "hintKey", isSignal: true, isRequired: false, transformFunction: null }, hintText: { classPropertyName: "hintText", publicName: "hintText", isSignal: true, isRequired: false, transformFunction: null }, maxlength: { classPropertyName: "maxlength", publicName: "maxlength", isSignal: true, isRequired: false, transformFunction: null }, readonly: { classPropertyName: "readonly", publicName: "readonly", isSignal: true, isRequired: false, transformFunction: null }, subscriptSizing: { classPropertyName: "subscriptSizing", publicName: "subscriptSizing", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: "<mat-form-field appearance=\"outline\" [subscriptSizing]=\"subscriptSizing()\">\n  <mat-label>{{ labelKey() | uiTranslate }}</mat-label>\n  <textarea matInput [formControl]=\"control()\" [rows]=\"rows()\" [required]=\"required()\" [readonly]=\"readonly()\"\n            [attr.maxlength]=\"maxlength()\"></textarea>\n  @if (hintText() || hintKey()) {\n    <mat-hint>{{ hintText() || (hintKey() | uiTranslate) }}</mat-hint>\n  }\n  @if (firstError(control()); as key) {\n    <mat-error>{{ key | uiTranslate }}</mat-error>\n  }\n</mat-form-field>\n", styles: [":host{display:block;box-sizing:border-box;min-width:0;max-width:100%}:host{width:100%}:host(.ui-shared-filter){width:var(--ui-filter-width, 260px)}mat-form-field{width:100%}textarea{resize:vertical}\n"], dependencies: [{ kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.RequiredValidator, selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]", inputs: ["required"] }, { kind: "directive", type: i1.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "component", type: i2.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i2.MatLabel, selector: "mat-label" }, { kind: "directive", type: i2.MatHint, selector: "mat-hint", inputs: ["align", "id"] }, { kind: "directive", type: i2.MatError, selector: "mat-error, [matError]", inputs: ["id"] }, { kind: "ngmodule", type: MatInputModule }, { kind: "directive", type: i3.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly", "disabledInteractive"], exportAs: ["matInput"] }, { kind: "pipe", type: UiTranslatePipe, name: "uiTranslate" }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedTextareaInputComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ui-shared-textarea-input', standalone: true, imports: [ReactiveFormsModule, MatFormFieldModule, MatInputModule, UiTranslatePipe], template: "<mat-form-field appearance=\"outline\" [subscriptSizing]=\"subscriptSizing()\">\n  <mat-label>{{ labelKey() | uiTranslate }}</mat-label>\n  <textarea matInput [formControl]=\"control()\" [rows]=\"rows()\" [required]=\"required()\" [readonly]=\"readonly()\"\n            [attr.maxlength]=\"maxlength()\"></textarea>\n  @if (hintText() || hintKey()) {\n    <mat-hint>{{ hintText() || (hintKey() | uiTranslate) }}</mat-hint>\n  }\n  @if (firstError(control()); as key) {\n    <mat-error>{{ key | uiTranslate }}</mat-error>\n  }\n</mat-form-field>\n", styles: [":host{display:block;box-sizing:border-box;min-width:0;max-width:100%}:host{width:100%}:host(.ui-shared-filter){width:var(--ui-filter-width, 260px)}mat-form-field{width:100%}textarea{resize:vertical}\n"] }]
        }] });

/** The one date picker. Day-first typing/display comes from `provideUiDates()` in the app config. */
class UiSharedDateInputComponent {
    control = input.required();
    labelKey = input.required();
    hintKey = input('');
    hintText = input('');
    min = input(null);
    max = input(null);
    subscriptSizing = input('dynamic');
    firstError = firstError;
    required = computed(() => this.control().hasValidator(Validators.required));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedDateInputComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: UiSharedDateInputComponent, isStandalone: true, selector: "ui-shared-date-input", inputs: { control: { classPropertyName: "control", publicName: "control", isSignal: true, isRequired: true, transformFunction: null }, labelKey: { classPropertyName: "labelKey", publicName: "labelKey", isSignal: true, isRequired: true, transformFunction: null }, hintKey: { classPropertyName: "hintKey", publicName: "hintKey", isSignal: true, isRequired: false, transformFunction: null }, hintText: { classPropertyName: "hintText", publicName: "hintText", isSignal: true, isRequired: false, transformFunction: null }, min: { classPropertyName: "min", publicName: "min", isSignal: true, isRequired: false, transformFunction: null }, max: { classPropertyName: "max", publicName: "max", isSignal: true, isRequired: false, transformFunction: null }, subscriptSizing: { classPropertyName: "subscriptSizing", publicName: "subscriptSizing", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: "<mat-form-field appearance=\"outline\" [subscriptSizing]=\"subscriptSizing()\">\n  <mat-label>{{ labelKey() | uiTranslate }}</mat-label>\n  <input matInput [matDatepicker]=\"picker\" [formControl]=\"control()\" [required]=\"required()\" [min]=\"min()\" [max]=\"max()\" />\n  <mat-datepicker-toggle matIconSuffix [for]=\"picker\" />\n  <mat-datepicker #picker />\n  @if (hintText() || hintKey()) {\n    <mat-hint>{{ hintText() || (hintKey() | uiTranslate) }}</mat-hint>\n  }\n  @if (firstError(control()); as key) {\n    <mat-error>{{ key | uiTranslate }}</mat-error>\n  }\n</mat-form-field>\n", styles: [":host{display:block;box-sizing:border-box;min-width:0;max-width:100%}:host{width:100%}:host(.ui-shared-filter){width:var(--ui-filter-width, 260px)}mat-form-field{width:100%}\n"], dependencies: [{ kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.RequiredValidator, selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]", inputs: ["required"] }, { kind: "directive", type: i1.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "component", type: i2.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i2.MatLabel, selector: "mat-label" }, { kind: "directive", type: i2.MatHint, selector: "mat-hint", inputs: ["align", "id"] }, { kind: "directive", type: i2.MatError, selector: "mat-error, [matError]", inputs: ["id"] }, { kind: "directive", type: i2.MatSuffix, selector: "[matSuffix], [matIconSuffix], [matTextSuffix]", inputs: ["matTextSuffix"] }, { kind: "ngmodule", type: MatInputModule }, { kind: "directive", type: i3.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly", "disabledInteractive"], exportAs: ["matInput"] }, { kind: "ngmodule", type: MatDatepickerModule }, { kind: "component", type: i4$1.MatDatepicker, selector: "mat-datepicker", exportAs: ["matDatepicker"] }, { kind: "directive", type: i4$1.MatDatepickerInput, selector: "input[matDatepicker]", inputs: ["matDatepicker", "min", "max", "matDatepickerFilter"], exportAs: ["matDatepickerInput"] }, { kind: "component", type: i4$1.MatDatepickerToggle, selector: "mat-datepicker-toggle", inputs: ["for", "tabIndex", "aria-label", "disabled", "disableRipple"], exportAs: ["matDatepickerToggle"] }, { kind: "pipe", type: UiTranslatePipe, name: "uiTranslate" }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedDateInputComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ui-shared-date-input', standalone: true, imports: [ReactiveFormsModule, MatFormFieldModule, MatInputModule, MatDatepickerModule, UiTranslatePipe], template: "<mat-form-field appearance=\"outline\" [subscriptSizing]=\"subscriptSizing()\">\n  <mat-label>{{ labelKey() | uiTranslate }}</mat-label>\n  <input matInput [matDatepicker]=\"picker\" [formControl]=\"control()\" [required]=\"required()\" [min]=\"min()\" [max]=\"max()\" />\n  <mat-datepicker-toggle matIconSuffix [for]=\"picker\" />\n  <mat-datepicker #picker />\n  @if (hintText() || hintKey()) {\n    <mat-hint>{{ hintText() || (hintKey() | uiTranslate) }}</mat-hint>\n  }\n  @if (firstError(control()); as key) {\n    <mat-error>{{ key | uiTranslate }}</mat-error>\n  }\n</mat-form-field>\n", styles: [":host{display:block;box-sizing:border-box;min-width:0;max-width:100%}:host{width:100%}:host(.ui-shared-filter){width:var(--ui-filter-width, 260px)}mat-form-field{width:100%}\n"] }]
        }] });

/**
 * The one checkbox. Two modes:
 *  - form mode: `[control]` is a boolean FormControl;
 *  - selection mode (no control): `[checked]` / `[disabled]` in, `(changed)` out —
 *    for table row / select-all toggles that live in component state, not a form.
 * Label is a translation key or projected content.
 */
class UiSharedCheckboxComponent {
    control = input(null);
    labelKey = input('');
    ariaLabelKey = input('');
    /** Hover hint on the whole checkbox. */
    tooltipKey = input('');
    checked = input(false, { transform: booleanAttribute });
    indeterminate = input(false, { transform: booleanAttribute });
    disabled = input(false, { transform: booleanAttribute });
    changed = output();
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedCheckboxComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: UiSharedCheckboxComponent, isStandalone: true, selector: "ui-shared-checkbox", inputs: { control: { classPropertyName: "control", publicName: "control", isSignal: true, isRequired: false, transformFunction: null }, labelKey: { classPropertyName: "labelKey", publicName: "labelKey", isSignal: true, isRequired: false, transformFunction: null }, ariaLabelKey: { classPropertyName: "ariaLabelKey", publicName: "ariaLabelKey", isSignal: true, isRequired: false, transformFunction: null }, tooltipKey: { classPropertyName: "tooltipKey", publicName: "tooltipKey", isSignal: true, isRequired: false, transformFunction: null }, checked: { classPropertyName: "checked", publicName: "checked", isSignal: true, isRequired: false, transformFunction: null }, indeterminate: { classPropertyName: "indeterminate", publicName: "indeterminate", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { changed: "changed" }, ngImport: i0, template: "@if (control(); as c) {\n  <mat-checkbox [formControl]=\"c\" [matTooltip]=\"tooltipKey() ? (tooltipKey() | uiTranslate) : ''\"\n                [aria-label]=\"ariaLabelKey() ? (ariaLabelKey() | uiTranslate) : ''\"><ng-container *ngTemplateOutlet=\"label\" /></mat-checkbox>\n} @else {\n  <mat-checkbox [checked]=\"checked()\" [indeterminate]=\"indeterminate()\" [disabled]=\"disabled()\"\n                [matTooltip]=\"tooltipKey() ? (tooltipKey() | uiTranslate) : ''\"\n                [aria-label]=\"ariaLabelKey() ? (ariaLabelKey() | uiTranslate) : ''\"\n                (change)=\"changed.emit($event.checked)\">\n    <ng-container *ngTemplateOutlet=\"label\" />\n  </mat-checkbox>\n}\n<ng-template #label>@if (labelKey()) { {{ labelKey() | uiTranslate }} } @else { <ng-content /> }</ng-template>\n", styles: [":host{display:inline-flex;box-sizing:border-box;min-width:0;max-width:100%}\n"], dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }, { kind: "ngmodule", type: MatCheckboxModule }, { kind: "component", type: i2$1.MatCheckbox, selector: "mat-checkbox", inputs: ["aria-label", "aria-labelledby", "aria-describedby", "aria-expanded", "aria-controls", "aria-owns", "id", "required", "labelPosition", "name", "value", "disableRipple", "tabIndex", "color", "disabledInteractive", "checked", "disabled", "indeterminate"], outputs: ["change", "indeterminateChange"], exportAs: ["matCheckbox"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "directive", type: i3$1.MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }, { kind: "pipe", type: UiTranslatePipe, name: "uiTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedCheckboxComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ui-shared-checkbox', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, imports: [NgTemplateOutlet, ReactiveFormsModule, MatCheckboxModule, MatTooltipModule, UiTranslatePipe], template: "@if (control(); as c) {\n  <mat-checkbox [formControl]=\"c\" [matTooltip]=\"tooltipKey() ? (tooltipKey() | uiTranslate) : ''\"\n                [aria-label]=\"ariaLabelKey() ? (ariaLabelKey() | uiTranslate) : ''\"><ng-container *ngTemplateOutlet=\"label\" /></mat-checkbox>\n} @else {\n  <mat-checkbox [checked]=\"checked()\" [indeterminate]=\"indeterminate()\" [disabled]=\"disabled()\"\n                [matTooltip]=\"tooltipKey() ? (tooltipKey() | uiTranslate) : ''\"\n                [aria-label]=\"ariaLabelKey() ? (ariaLabelKey() | uiTranslate) : ''\"\n                (change)=\"changed.emit($event.checked)\">\n    <ng-container *ngTemplateOutlet=\"label\" />\n  </mat-checkbox>\n}\n<ng-template #label>@if (labelKey()) { {{ labelKey() | uiTranslate }} } @else { <ng-content /> }</ng-template>\n", styles: [":host{display:inline-flex;box-sizing:border-box;min-width:0;max-width:100%}\n"] }]
        }] });

/** The one on/off switch: a boolean FormControl with a translated label (or projected content). */
class UiSharedToggleComponent {
    control = input.required();
    labelKey = input('');
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedToggleComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: UiSharedToggleComponent, isStandalone: true, selector: "ui-shared-toggle", inputs: { control: { classPropertyName: "control", publicName: "control", isSignal: true, isRequired: true, transformFunction: null }, labelKey: { classPropertyName: "labelKey", publicName: "labelKey", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: "<mat-slide-toggle [formControl]=\"control()\">@if (labelKey()) { {{ labelKey() | uiTranslate }} } @else { <ng-content /> }</mat-slide-toggle>\n", styles: [":host{display:inline-flex;box-sizing:border-box;min-width:0;max-width:100%}\n"], dependencies: [{ kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }, { kind: "ngmodule", type: MatSlideToggleModule }, { kind: "component", type: i2$2.MatSlideToggle, selector: "mat-slide-toggle", inputs: ["name", "id", "labelPosition", "aria-label", "aria-labelledby", "aria-describedby", "required", "color", "disabled", "disableRipple", "tabIndex", "checked", "hideIcon", "disabledInteractive"], outputs: ["change", "toggleChange"], exportAs: ["matSlideToggle"] }, { kind: "pipe", type: UiTranslatePipe, name: "uiTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedToggleComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ui-shared-toggle', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, imports: [ReactiveFormsModule, MatSlideToggleModule, UiTranslatePipe], template: "<mat-slide-toggle [formControl]=\"control()\">@if (labelKey()) { {{ labelKey() | uiTranslate }} } @else { <ng-content /> }</mat-slide-toggle>\n", styles: [":host{display:inline-flex;box-sizing:border-box;min-width:0;max-width:100%}\n"] }]
        }] });

/** The one radio group for forms. Options are `SelectOption`s (label or labelKey), like ui-shared-select. */
class UiSharedRadioGroupComponent {
    control = input.required();
    options = input.required();
    labelKey = input('');
    direction = input('row');
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedRadioGroupComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: UiSharedRadioGroupComponent, isStandalone: true, selector: "ui-shared-radio-group", inputs: { control: { classPropertyName: "control", publicName: "control", isSignal: true, isRequired: true, transformFunction: null }, options: { classPropertyName: "options", publicName: "options", isSignal: true, isRequired: true, transformFunction: null }, labelKey: { classPropertyName: "labelKey", publicName: "labelKey", isSignal: true, isRequired: false, transformFunction: null }, direction: { classPropertyName: "direction", publicName: "direction", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: "<mat-radio-group [formControl]=\"control()\" class=\"ui-shared-radio-group\" [class.ui-shared-radio-group--column]=\"direction() === 'column'\">\n  @if (labelKey()) { <span class=\"ui-shared-radio-group__label\">{{ labelKey() | uiTranslate }}</span> }\n  @for (o of options(); track o.value) {\n    <mat-radio-button [value]=\"o.value\">{{ o | uiOptionText }}</mat-radio-button>\n  }\n</mat-radio-group>\n", styles: [":host{display:block;box-sizing:border-box;min-width:0;max-width:100%}.ui-shared-radio-group{display:flex;flex-wrap:wrap;align-items:center}.ui-shared-radio-group--column{flex-direction:column;align-items:flex-start}\n"], dependencies: [{ kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }, { kind: "ngmodule", type: MatRadioModule }, { kind: "directive", type: i2$3.MatRadioGroup, selector: "mat-radio-group", inputs: ["color", "name", "labelPosition", "value", "selected", "disabled", "required", "disabledInteractive"], outputs: ["change"], exportAs: ["matRadioGroup"] }, { kind: "component", type: i2$3.MatRadioButton, selector: "mat-radio-button", inputs: ["id", "name", "aria-label", "aria-labelledby", "aria-describedby", "disableRipple", "tabIndex", "checked", "value", "labelPosition", "disabled", "required", "color", "disabledInteractive"], outputs: ["change"], exportAs: ["matRadioButton"] }, { kind: "pipe", type: UiTranslatePipe, name: "uiTranslate" }, { kind: "pipe", type: UiOptionTextPipe, name: "uiOptionText" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedRadioGroupComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ui-shared-radio-group', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, imports: [ReactiveFormsModule, MatRadioModule, UiTranslatePipe, UiOptionTextPipe], template: "<mat-radio-group [formControl]=\"control()\" class=\"ui-shared-radio-group\" [class.ui-shared-radio-group--column]=\"direction() === 'column'\">\n  @if (labelKey()) { <span class=\"ui-shared-radio-group__label\">{{ labelKey() | uiTranslate }}</span> }\n  @for (o of options(); track o.value) {\n    <mat-radio-button [value]=\"o.value\">{{ o | uiOptionText }}</mat-radio-button>\n  }\n</mat-radio-group>\n", styles: [":host{display:block;box-sizing:border-box;min-width:0;max-width:100%}.ui-shared-radio-group{display:flex;flex-wrap:wrap;align-items:center}.ui-shared-radio-group--column{flex-direction:column;align-items:flex-start}\n"] }]
        }] });

/**
 * The one segmented control (single-choice button toggle row). Three uses:
 *  - view state: `[value]` in, `(valueChange)` out;
 *  - form: `[control]`;
 *  - grid filter inside `<ui-shared-grid>`: `field` or `[clauseBuilder]`, plus
 *    `initial` (selected on load, restored by Clear; defaults to the first
 *    option). With `field`, the value `all` filters nothing.
 *
 * `storageKey` remembers the choice in the browser and restores it on load
 * (emitting `valueChange`, and applying it when used as a filter). The options
 * must be known on init for the restore to happen.
 *
 *   <ui-shared-segmented [options]="years" [value]="year()" (valueChange)="year.set($event)" storageKey="home.year" />
 *   <ui-shared-segmented [options]="statusOptions" initial="active" [clauseBuilder]="softDeleteClauseBuilder" />
 */
class UiSharedSegmentedComponent {
    options = input.required();
    value = input(null);
    disabled = input(false, { transform: booleanAttribute });
    ariaLabelKey = input('');
    valueChange = output();
    control = input(null);
    /** Remember the choice in the browser under this key. */
    storageKey = input('');
    /** Grid filter: OData field compared with `eq` (`all` = no filter). */
    field = input(null);
    /** Grid filter: custom clause for the picked value (overrides `field`). */
    clauseBuilder = input(null);
    /** Grid filter: value selected on load and restored by Clear; defaults to the first option. */
    initial = input(null);
    own = new FormControl(null);
    /** The group always binds a control: the caller's, or an internal one (view state / filter). */
    ctrl = computed(() => this.control() ?? this.own);
    filter = new GridFilterState(() => this.ctrl(), () => this.clauseBuilder() ?? this.fieldEq(), () => this.initial() ?? this.options()[0]?.value ?? null);
    constructor() {
        // View-state mode: [value] and [disabled] drive the internal control.
        effect(() => {
            const v = this.value();
            if (!this.control() && !this.filter.isFilter())
                this.own.setValue(v, { emitEvent: false });
        });
        effect(() => (this.disabled() ? this.own.disable({ emitEvent: false }) : this.own.enable({ emitEvent: false })));
    }
    ngOnInit() {
        this.filter.init();
        const key = this.storageKey();
        const saved = key ? storedChoice(key, this.options().map(o => o.value)) : null;
        if (saved !== null && saved !== this.ctrl().value) {
            this.filter.restore(saved);
            this.valueChange.emit(saved);
        }
    }
    onChange(value) {
        if (this.storageKey())
            storeChoice(this.storageKey(), value);
        this.valueChange.emit(value);
    }
    fieldEq() {
        const eq = eqClause(this.field());
        return eq && (v => (v === 'all' ? null : eq(v)));
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedSegmentedComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: UiSharedSegmentedComponent, isStandalone: true, selector: "ui-shared-segmented", inputs: { options: { classPropertyName: "options", publicName: "options", isSignal: true, isRequired: true, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, ariaLabelKey: { classPropertyName: "ariaLabelKey", publicName: "ariaLabelKey", isSignal: true, isRequired: false, transformFunction: null }, control: { classPropertyName: "control", publicName: "control", isSignal: true, isRequired: false, transformFunction: null }, storageKey: { classPropertyName: "storageKey", publicName: "storageKey", isSignal: true, isRequired: false, transformFunction: null }, field: { classPropertyName: "field", publicName: "field", isSignal: true, isRequired: false, transformFunction: null }, clauseBuilder: { classPropertyName: "clauseBuilder", publicName: "clauseBuilder", isSignal: true, isRequired: false, transformFunction: null }, initial: { classPropertyName: "initial", publicName: "initial", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { valueChange: "valueChange" }, host: { properties: { "class.ui-shared-filter": "filter.isFilter()" } }, providers: [provideGridFilter(() => UiSharedSegmentedComponent)], ngImport: i0, template: "<mat-button-toggle-group [formControl]=\"ctrl()\" hideSingleSelectionIndicator\n                         [attr.aria-label]=\"ariaLabelKey() ? (ariaLabelKey() | uiTranslate) : null\"\n                         (change)=\"onChange($event.value)\">\n  @for (o of options(); track o.value) {\n    <mat-button-toggle [value]=\"o.value\">{{ o | uiOptionText }}</mat-button-toggle>\n  }\n</mat-button-toggle-group>\n", styles: [":host{display:inline-flex;box-sizing:border-box;min-width:0;max-width:100%}mat-button-toggle-group{flex-wrap:wrap}\n"], dependencies: [{ kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }, { kind: "ngmodule", type: MatButtonToggleModule }, { kind: "directive", type: i2$4.MatButtonToggleGroup, selector: "mat-button-toggle-group", inputs: ["appearance", "name", "vertical", "value", "multiple", "disabled", "disabledInteractive", "hideSingleSelectionIndicator", "hideMultipleSelectionIndicator"], outputs: ["valueChange", "change"], exportAs: ["matButtonToggleGroup"] }, { kind: "component", type: i2$4.MatButtonToggle, selector: "mat-button-toggle", inputs: ["aria-label", "aria-labelledby", "id", "name", "value", "tabIndex", "disableRipple", "appearance", "checked", "disabled", "disabledInteractive"], outputs: ["change"], exportAs: ["matButtonToggle"] }, { kind: "pipe", type: UiTranslatePipe, name: "uiTranslate" }, { kind: "pipe", type: UiOptionTextPipe, name: "uiOptionText" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedSegmentedComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ui-shared-segmented', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, imports: [ReactiveFormsModule, MatButtonToggleModule, UiTranslatePipe, UiOptionTextPipe], providers: [provideGridFilter(() => UiSharedSegmentedComponent)], host: { '[class.ui-shared-filter]': 'filter.isFilter()' }, template: "<mat-button-toggle-group [formControl]=\"ctrl()\" hideSingleSelectionIndicator\n                         [attr.aria-label]=\"ariaLabelKey() ? (ariaLabelKey() | uiTranslate) : null\"\n                         (change)=\"onChange($event.value)\">\n  @for (o of options(); track o.value) {\n    <mat-button-toggle [value]=\"o.value\">{{ o | uiOptionText }}</mat-button-toggle>\n  }\n</mat-button-toggle-group>\n", styles: [":host{display:inline-flex;box-sizing:border-box;min-width:0;max-width:100%}mat-button-toggle-group{flex-wrap:wrap}\n"] }]
        }], ctorParameters: () => [] });

/**
 * The one file input: a button that opens the native picker and emits the
 * chosen file(s). The hidden `<input type="file">` is reset after each pick so
 * choosing the same file twice still emits.
 *
 *   <ui-shared-file-button labelKey="logo.upload" icon="upload" accept="image/*" (filesSelected)="upload($event[0])" />
 */
class UiSharedFileButtonComponent {
    labelKey = input.required();
    icon = input('upload');
    /** Native `accept` filter, e.g. `image/*` or `.pdf,.xml`. */
    accept = input('');
    multiple = input(false, { transform: booleanAttribute });
    disabled = input(false, { transform: booleanAttribute });
    variant = input('flat');
    color = input('primary');
    filesSelected = output();
    onChange(el) {
        const files = Array.from(el.files ?? []);
        el.value = '';
        if (files.length)
            this.filesSelected.emit(files);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedFileButtonComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: UiSharedFileButtonComponent, isStandalone: true, selector: "ui-shared-file-button", inputs: { labelKey: { classPropertyName: "labelKey", publicName: "labelKey", isSignal: true, isRequired: true, transformFunction: null }, icon: { classPropertyName: "icon", publicName: "icon", isSignal: true, isRequired: false, transformFunction: null }, accept: { classPropertyName: "accept", publicName: "accept", isSignal: true, isRequired: false, transformFunction: null }, multiple: { classPropertyName: "multiple", publicName: "multiple", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null }, color: { classPropertyName: "color", publicName: "color", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { filesSelected: "filesSelected" }, ngImport: i0, template: "<input #picker type=\"file\" hidden [attr.accept]=\"accept() || null\" [multiple]=\"multiple()\" (change)=\"onChange(picker)\" />\n@if (variant() === 'flat') {\n  <button mat-flat-button type=\"button\" [color]=\"color()\" [disabled]=\"disabled()\" (click)=\"picker.click()\">\n    @if (icon()) { <mat-icon>{{ icon() }}</mat-icon> }\n    <span>{{ labelKey() | uiTranslate }}</span>\n  </button>\n} @else {\n  <button mat-stroked-button type=\"button\" [color]=\"color()\" [disabled]=\"disabled()\" (click)=\"picker.click()\">\n    @if (icon()) { <mat-icon>{{ icon() }}</mat-icon> }\n    <span>{{ labelKey() | uiTranslate }}</span>\n  </button>\n}\n", styles: [":host{display:inline-flex;box-sizing:border-box;min-width:0;max-width:100%}\n"], dependencies: [{ kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i1$1.MatButton, selector: "    button[mat-button], button[mat-raised-button], button[mat-flat-button],    button[mat-stroked-button]  ", exportAs: ["matButton"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i5.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "pipe", type: UiTranslatePipe, name: "uiTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedFileButtonComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ui-shared-file-button', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, imports: [MatButtonModule, MatIconModule, UiTranslatePipe], template: "<input #picker type=\"file\" hidden [attr.accept]=\"accept() || null\" [multiple]=\"multiple()\" (change)=\"onChange(picker)\" />\n@if (variant() === 'flat') {\n  <button mat-flat-button type=\"button\" [color]=\"color()\" [disabled]=\"disabled()\" (click)=\"picker.click()\">\n    @if (icon()) { <mat-icon>{{ icon() }}</mat-icon> }\n    <span>{{ labelKey() | uiTranslate }}</span>\n  </button>\n} @else {\n  <button mat-stroked-button type=\"button\" [color]=\"color()\" [disabled]=\"disabled()\" (click)=\"picker.click()\">\n    @if (icon()) { <mat-icon>{{ icon() }}</mat-icon> }\n    <span>{{ labelKey() | uiTranslate }}</span>\n  </button>\n}\n", styles: [":host{display:inline-flex;box-sizing:border-box;min-width:0;max-width:100%}\n"] }]
        }] });

/**
 * Tiny HTML editor with a Source / Preview toggle.
 *
 *   - SOURCE  : textarea holding the raw HTML markup.
 *   - PREVIEW : the same markup rendered via `bypassSecurityTrustHtml` — meant
 *               for trusted (admin-authored) content only.
 *
 * Implements `ControlValueAccessor` so it slots straight into a reactive form
 * (`formControlName="bodyEn"`). The current mode is component-local; the
 * bound form value is always the raw HTML string.
 *
 *   <ui-shared-html-editor formControlName="bodyEn" rows="16" />
 */
class UiSharedHtmlEditorComponent {
    /** Visible row count for the source textarea. */
    rows = input(16, { transform: numberAttribute });
    /** Optional placeholder shown in the source textarea when empty. */
    placeholder = input('');
    sanitizer = inject(DomSanitizer);
    injector = inject(Injector);
    ta;
    value = signal('');
    disabled = signal(false);
    mode = signal('source');
    previewHtml = computed(() => this.sanitizer.bypassSecurityTrustHtml(this.value() || ''));
    onChange = () => { };
    onTouched = () => { };
    writeValue(v) {
        this.value.set(v ?? '');
    }
    registerOnChange(fn) { this.onChange = fn; }
    registerOnTouched(fn) { this.onTouched = fn; }
    setDisabledState(isDisabled) { this.disabled.set(isDisabled); }
    onInput(ev) {
        const next = ev.target.value;
        this.value.set(next);
        this.onChange(next);
    }
    onBlur() { this.onTouched(); }
    showSource() {
        this.mode.set('source');
        // The textarea only exists again after the next render.
        afterNextRender(() => this.ta?.nativeElement.focus(), { injector: this.injector });
    }
    showPreview() { this.mode.set('preview'); }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedHtmlEditorComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: UiSharedHtmlEditorComponent, isStandalone: true, selector: "ui-shared-html-editor", inputs: { rows: { classPropertyName: "rows", publicName: "rows", isSignal: true, isRequired: false, transformFunction: null }, placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null } }, providers: [{
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => UiSharedHtmlEditorComponent),
                multi: true,
            }], viewQueries: [{ propertyName: "ta", first: true, predicate: ["ta"], descendants: true }], ngImport: i0, template: "<div class=\"ui-shared-html-editor\" [class.ui-shared-html-editor--disabled]=\"disabled()\">\n  <div class=\"ui-shared-html-editor__toolbar\">\n    <button mat-button type=\"button\"\n            class=\"ui-shared-html-editor__tab\"\n            [class.ui-shared-html-editor__tab--active]=\"mode() === 'source'\"\n            (click)=\"showSource()\"\n            [matTooltip]=\"'htmlEditor.source' | uiTranslate\">\n      <mat-icon>code</mat-icon>\n      <span>{{ 'htmlEditor.source' | uiTranslate }}</span>\n    </button>\n    <button mat-button type=\"button\"\n            class=\"ui-shared-html-editor__tab\"\n            [class.ui-shared-html-editor__tab--active]=\"mode() === 'preview'\"\n            (click)=\"showPreview()\"\n            [matTooltip]=\"'htmlEditor.preview' | uiTranslate\">\n      <mat-icon>visibility</mat-icon>\n      <span>{{ 'htmlEditor.preview' | uiTranslate }}</span>\n    </button>\n  </div>\n\n  @if (mode() === 'source') {\n    <textarea #ta class=\"ui-shared-html-editor__source\"\n              [rows]=\"rows()\"\n              [value]=\"value()\"\n              [disabled]=\"disabled()\"\n              [placeholder]=\"placeholder()\"\n              (input)=\"onInput($event)\"\n              (blur)=\"onBlur()\"\n              spellcheck=\"false\"></textarea>\n  } @else {\n    <div class=\"ui-shared-html-editor__preview\" [innerHTML]=\"previewHtml()\"></div>\n  }\n</div>\n", styles: [":host{display:block;box-sizing:border-box;min-width:0;max-width:100%}.ui-shared-html-editor{display:flex;flex-direction:column;overflow:hidden}.ui-shared-html-editor--disabled{pointer-events:none}.ui-shared-html-editor__toolbar{display:flex;align-items:stretch}.ui-shared-html-editor__tab{display:inline-flex;align-items:center;min-width:0}.ui-shared-html-editor__source{width:100%;resize:vertical}.ui-shared-html-editor__preview{overflow-y:auto}\n"], dependencies: [{ kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i1$1.MatButton, selector: "    button[mat-button], button[mat-raised-button], button[mat-flat-button],    button[mat-stroked-button]  ", exportAs: ["matButton"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i5.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "directive", type: i3$1.MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }, { kind: "pipe", type: UiTranslatePipe, name: "uiTranslate" }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: UiSharedHtmlEditorComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ui-shared-html-editor', standalone: true, imports: [MatButtonModule, MatIconModule, MatTooltipModule, UiTranslatePipe], providers: [{
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => UiSharedHtmlEditorComponent),
                            multi: true,
                        }], template: "<div class=\"ui-shared-html-editor\" [class.ui-shared-html-editor--disabled]=\"disabled()\">\n  <div class=\"ui-shared-html-editor__toolbar\">\n    <button mat-button type=\"button\"\n            class=\"ui-shared-html-editor__tab\"\n            [class.ui-shared-html-editor__tab--active]=\"mode() === 'source'\"\n            (click)=\"showSource()\"\n            [matTooltip]=\"'htmlEditor.source' | uiTranslate\">\n      <mat-icon>code</mat-icon>\n      <span>{{ 'htmlEditor.source' | uiTranslate }}</span>\n    </button>\n    <button mat-button type=\"button\"\n            class=\"ui-shared-html-editor__tab\"\n            [class.ui-shared-html-editor__tab--active]=\"mode() === 'preview'\"\n            (click)=\"showPreview()\"\n            [matTooltip]=\"'htmlEditor.preview' | uiTranslate\">\n      <mat-icon>visibility</mat-icon>\n      <span>{{ 'htmlEditor.preview' | uiTranslate }}</span>\n    </button>\n  </div>\n\n  @if (mode() === 'source') {\n    <textarea #ta class=\"ui-shared-html-editor__source\"\n              [rows]=\"rows()\"\n              [value]=\"value()\"\n              [disabled]=\"disabled()\"\n              [placeholder]=\"placeholder()\"\n              (input)=\"onInput($event)\"\n              (blur)=\"onBlur()\"\n              spellcheck=\"false\"></textarea>\n  } @else {\n    <div class=\"ui-shared-html-editor__preview\" [innerHTML]=\"previewHtml()\"></div>\n  }\n</div>\n", styles: [":host{display:block;box-sizing:border-box;min-width:0;max-width:100%}.ui-shared-html-editor{display:flex;flex-direction:column;overflow:hidden}.ui-shared-html-editor--disabled{pointer-events:none}.ui-shared-html-editor__toolbar{display:flex;align-items:stretch}.ui-shared-html-editor__tab{display:inline-flex;align-items:center;min-width:0}.ui-shared-html-editor__source{width:100%;resize:vertical}.ui-shared-html-editor__preview{overflow-y:auto}\n"] }]
        }], propDecorators: { ta: [{
                type: ViewChild,
                args: ['ta']
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { UiSharedCheckboxComponent, UiSharedDateInputComponent, UiSharedFileButtonComponent, UiSharedHtmlEditorComponent, UiSharedPasswordFieldComponent, UiSharedRadioGroupComponent, UiSharedSegmentedComponent, UiSharedSelectComponent, UiSharedTextInputComponent, UiSharedTextareaInputComponent, UiSharedToggleComponent };
//# sourceMappingURL=borassoft-ui-components-inputs.mjs.map
