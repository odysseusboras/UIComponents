import * as i0 from "@angular/core";
/**
 * A stored reference to a lookup / organisation row, marked when that row has since been
 * soft-deleted: the label is struck through and a small "inactive" mark follows it. Use it in
 * grids and read-only views wherever old data may point to a value that is no longer offered.
 *
 *   <ui-shared-inactive-value [label]="a.regionName" [inactive]="a.regionIsDeleted" />
 */
export declare class UiSharedInactiveValueComponent {
    label: import("@angular/core").InputSignal<string | null | undefined>;
    inactive: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UiSharedInactiveValueComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UiSharedInactiveValueComponent, "ui-shared-inactive-value", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; "inactive": { "alias": "inactive"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=ui-shared-inactive-value.component.d.ts.map