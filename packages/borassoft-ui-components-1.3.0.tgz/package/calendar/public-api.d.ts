export * from './src/calendar/ui-shared-calendar.component';
//# sourceMappingURL=public-api.d.ts.map