import * as i0 from "@angular/core";
/** Kept only for call-site compatibility — it no longer changes the output. */
export type DisplayDateMode = 'datetime' | 'date';
/**
 * Single source of truth for rendering ANY date.
 *
 *   <ui-shared-display-date [value]="row.dateCreated" />
 *   <ui-shared-display-date [value]="row.dateCreated" empty="never" />
 *
 * ONE format app-wide, from `UI_DATE_FORMAT` (default `dd/MM/yyyy, HH:mm`),
 * rendered in the locale `UI_LOCALE` returns. The `mode` input is accepted
 * but IGNORED so existing `mode="date"` call sites keep working. Because the
 * locale is read inside a computed, a host whose `UI_LOCALE` reads a signal
 * gets a re-render on language change.
 */
export declare class UiSharedDisplayDateComponent {
    /** The date to render. Accepts ISO-8601 strings (the wire format), Date, number, null, undefined. */
    value: import("@angular/core").InputSignal<string | number | Date | null | undefined>;
    /** Accepted but IGNORED — there is one format (date + time). Kept so existing call sites don't break. */
    mode: import("@angular/core").InputSignal<DisplayDateMode>;
    /** What to render when the value is null/empty. Defaults to an em-dash. */
    empty: import("@angular/core").InputSignal<string>;
    private locale;
    private format;
    /** NULL when the value can't be rendered — the template branches to the [empty] rendering. */
    protected formatted: import("@angular/core").Signal<string | null>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UiSharedDisplayDateComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UiSharedDisplayDateComponent, "ui-shared-display-date", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "mode": { "alias": "mode"; "required": false; "isSignal": true; }; "empty": { "alias": "empty"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=ui-shared-display-date.component.d.ts.map