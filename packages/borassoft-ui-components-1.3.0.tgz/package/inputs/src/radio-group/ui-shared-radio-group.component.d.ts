import { FormControl } from '@angular/forms';
import { SelectOption } from '@borassoft/ui-components';
import * as i0 from "@angular/core";
/** The one radio group for forms. Options are `SelectOption`s (label or labelKey), like ui-shared-select. */
export declare class UiSharedRadioGroupComponent {
    control: import("@angular/core").InputSignal<FormControl<any>>;
    options: import("@angular/core").InputSignal<SelectOption<string>[]>;
    labelKey: import("@angular/core").InputSignal<string>;
    direction: import("@angular/core").InputSignal<"row" | "column">;
    static ɵfac: i0.ɵɵFactoryDeclaration<UiSharedRadioGroupComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UiSharedRadioGroupComponent, "ui-shared-radio-group", never, { "control": { "alias": "control"; "required": true; "isSignal": true; }; "options": { "alias": "options"; "required": true; "isSignal": true; }; "labelKey": { "alias": "labelKey"; "required": false; "isSignal": true; }; "direction": { "alias": "direction"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=ui-shared-radio-group.component.d.ts.map