/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@borassoft/ui-components/calendar" />
export * from './public-api';
//# sourceMappingURL=borassoft-ui-components-calendar.d.ts.map