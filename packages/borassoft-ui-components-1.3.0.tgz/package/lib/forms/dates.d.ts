import { Provider } from '@angular/core';
import { MatDateFormats, NativeDateAdapter } from '@angular/material/core';
import * as i0 from "@angular/core";
/** Sentinel format the adapter recognises as "the text-input format". */
export declare const UI_DATE_INPUT_FORMAT = "dd/MM/yyyy";
/**
 * Datepicker formats: every date INPUT renders and parses as dd/MM/yyyy
 * (day-first, matching <ui-shared-display-date>), the calendar popup keeps
 * the native month/year labels.
 */
export declare const UI_DATE_FORMATS: MatDateFormats;
/**
 * NativeDateAdapter with a fixed day-first text format. The stock adapter goes
 * through the browser's Intl locale (US builds show M/D/YYYY and parse "05/07"
 * as May 7); this pins dd/MM/yyyy for typing AND display, whatever the locale.
 */
export declare class UiDateAdapter extends NativeDateAdapter {
    format(date: Date, displayFormat: unknown): string;
    parse(value: unknown): Date | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<UiDateAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UiDateAdapter>;
}
/** Wires the day-first date adapter + formats into the app (`providers: [provideUiDates()]`). */
export declare function provideUiDates(): Provider[];
//# sourceMappingURL=dates.d.ts.map