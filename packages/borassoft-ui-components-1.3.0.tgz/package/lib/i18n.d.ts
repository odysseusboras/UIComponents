import { InjectionToken, PipeTransform } from '@angular/core';
import { Observable } from 'rxjs';
import * as i0 from "@angular/core";
/** English fallback for every key the library renders; used when the app provides no translator. */
export declare const UI_DEFAULT_TEXTS: Readonly<Record<string, string>>;
/**
 * Key -> text resolver. Apps plug their own i18n in:
 * `{ provide: UI_TRANSLATE, useFactory: () => { const i = inject(I18nService); return (k: string) => i.t(k); } }`
 * If the resolver reads a signal (active locale), labels update on locale change (the pipe is impure).
 */
export declare const UI_TRANSLATE: InjectionToken<(key: string) => string>;
export interface UiRefreshSignal {
    /** Matched against each grid's [refreshKey]. */
    grid: string;
}
/** Stream of "reload grid X" signals (e.g. from SignalR). Defaults to none. */
export declare const UI_REFRESH: InjectionToken<Observable<UiRefreshSignal>>;
/**
 * Active locale for date formatting (`<ui-shared-display-date>`). A host returns its
 * locale signal's value so the display re-evaluates on language change:
 * `{ provide: UI_LOCALE, useFactory: () => { const i = inject(I18nService); return () => i.locale(); } }`
 */
export declare const UI_LOCALE: InjectionToken<() => string>;
/** The one Angular date format `<ui-shared-display-date>` renders with. */
export declare const UI_DATE_FORMAT: InjectionToken<string>;
export declare class UiTranslatePipe implements PipeTransform {
    private translate;
    transform(key: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<UiTranslatePipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<UiTranslatePipe, "uiTranslate", true>;
}
//# sourceMappingURL=i18n.d.ts.map