import * as i0 from "@angular/core";
export type UiHintTone = 'muted' | 'danger' | 'warning';
/**
 * The one explanation: an "i" icon with the text.
 *  - `iconOnly`: just the icon, the text as its hover tooltip - the form inputs put it at the end of the
 *    field (`matSuffix`) and the checkbox / toggle / radio group / segmented after their label;
 *  - otherwise the icon and the text on one line, cut with an ellipsis when it is longer than its box
 *    and shown whole on hover (`clamp`, the default for a lede); an error (`tone="danger"`) wraps instead.
 *
 *   <ui-shared-hint textKey="settings.logo.hint" />
 *   <ui-shared-hint iconOnly [text]="hint" />
 */
export declare class UiSharedHintComponent {
    private translate;
    textKey: import("@angular/core").InputSignal<string>;
    text: import("@angular/core").InputSignal<string>;
    tone: import("@angular/core").InputSignal<UiHintTone>;
    iconOnly: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    /** One line with an ellipsis, the whole text on hover (off for an error, which must stay readable). */
    clamp: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    protected resolved: import("@angular/core").Signal<string>;
    protected icon: import("@angular/core").Signal<"info" | "error">;
    protected clamped: import("@angular/core").Signal<boolean>;
    protected hostClass: import("@angular/core").Signal<string>;
    /** Inside a checkbox / toggle label a click would flip the control: the icon is for reading only. */
    protected onClick(e: Event): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<UiSharedHintComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UiSharedHintComponent, "ui-shared-hint", never, { "textKey": { "alias": "textKey"; "required": false; "isSignal": true; }; "text": { "alias": "text"; "required": false; "isSignal": true; }; "tone": { "alias": "tone"; "required": false; "isSignal": true; }; "iconOnly": { "alias": "iconOnly"; "required": false; "isSignal": true; }; "clamp": { "alias": "clamp"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}
//# sourceMappingURL=ui-shared-hint.component.d.ts.map