import { UiSharedTabComponent } from './tab/ui-shared-tab.component';
import * as i0 from "@angular/core";
/**
 * The one tab strip: flat labels, no animation, content rendered only for the
 * selected tab. `selected` / `(selectedChange)` for two-way state (query params).
 *
 *   <ui-shared-tabs [selected]="tab()" (selectedChange)="tab.set($event)">
 *     <ui-shared-tab labelKey="tenant.sales.tabs.sales"> ... </ui-shared-tab>
 *     <ui-shared-tab [label]="monthLabel()"> ... </ui-shared-tab>
 *   </ui-shared-tabs>
 *
 * Routed tabs: give every tab a `link` and put the page's <router-outlet> after the strip -
 * the strip is then a nav bar (each tab a URL, active by the router), the tabs carry no content.
 *
 *   <ui-shared-tabs>
 *     <ui-shared-tab link="info" labelKey="admin.companies.tabs.info" />
 *     <ui-shared-tab link="users" labelKey="admin.companies.tabs.users" />
 *   </ui-shared-tabs>
 *   <router-outlet />
 */
export declare class UiSharedTabsComponent {
    selected: import("@angular/core").InputSignalWithTransform<number, unknown>;
    selectedChange: import("@angular/core").OutputEmitterRef<number>;
    protected tabs: import("@angular/core").Signal<readonly UiSharedTabComponent[]>;
    protected routed: import("@angular/core").Signal<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UiSharedTabsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UiSharedTabsComponent, "ui-shared-tabs", never, { "selected": { "alias": "selected"; "required": false; "isSignal": true; }; }, { "selectedChange": "selectedChange"; }, ["tabs"], ["*"], true, never>;
}
//# sourceMappingURL=ui-shared-tabs.component.d.ts.map