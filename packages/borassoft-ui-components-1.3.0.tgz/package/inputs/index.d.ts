/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@borassoft/ui-components/inputs" />
export * from './public-api';
//# sourceMappingURL=borassoft-ui-components-inputs.d.ts.map