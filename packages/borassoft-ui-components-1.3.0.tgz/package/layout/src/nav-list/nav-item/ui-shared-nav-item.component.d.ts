import * as i0 from "@angular/core";
/** One routed entry of <ui-shared-nav-list>: icon + label, highlighted while its route is active. */
export declare class UiSharedNavItemComponent {
    link: import("@angular/core").InputSignal<string | any[]>;
    icon: import("@angular/core").InputSignal<string>;
    labelKey: import("@angular/core").InputSignal<string>;
    /** Highlight only on an exact route match (for the index route). */
    exact: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UiSharedNavItemComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UiSharedNavItemComponent, "ui-shared-nav-item", never, { "link": { "alias": "link"; "required": true; "isSignal": true; }; "icon": { "alias": "icon"; "required": false; "isSignal": true; }; "labelKey": { "alias": "labelKey"; "required": true; "isSignal": true; }; "exact": { "alias": "exact"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=ui-shared-nav-item.component.d.ts.map