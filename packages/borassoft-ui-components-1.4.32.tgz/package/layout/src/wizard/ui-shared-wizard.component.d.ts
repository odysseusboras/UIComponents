import * as i0 from "@angular/core";
/** One wizard step. `link` makes the step header a router link (the host routes between steps). */
export interface WizardStep {
    key: string;
    labelKey: string;
    link?: any[] | string;
}
/**
 * A multi-step form frame: a numbered step strip on top, the current step's content in the
 * middle, Back / Next (or Finish) on the bottom. The host owns the state: it says which step is
 * active, which steps are done and whether Next is allowed; it navigates on `back` / `next`
 * (or through each step's `link`). Extra footer buttons ("Save draft") go in `[slot=actions]`.
 *
 *   <ui-shared-wizard [steps]="steps" [active]="step()" [done]="done()" [canNext]="form.valid"
 *                     finishKey="activity.submit" (back)="go(-1)" (next)="go(+1)" (finish)="submit()">
 *     <router-outlet />
 *     <ui-shared-button slot="actions" labelKey="activity.saveDraft" (click)="saveDraft()" />
 *   </ui-shared-wizard>
 */
export declare class UiSharedWizardComponent {
    steps: import("@angular/core").InputSignal<WizardStep[]>;
    /** Key of the active step. */
    active: import("@angular/core").InputSignal<string>;
    /** Keys of the steps already completed (clickable in the strip). */
    done: import("@angular/core").InputSignal<string[]>;
    canNext: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    canFinish: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    busy: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    backKey: import("@angular/core").InputSignal<string>;
    nextKey: import("@angular/core").InputSignal<string>;
    finishKey: import("@angular/core").InputSignal<string>;
    back: import("@angular/core").OutputEmitterRef<void>;
    next: import("@angular/core").OutputEmitterRef<void>;
    finish: import("@angular/core").OutputEmitterRef<void>;
    readonly activeIndex: import("@angular/core").Signal<number>;
    readonly isLast: import("@angular/core").Signal<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UiSharedWizardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UiSharedWizardComponent, "ui-shared-wizard", never, { "steps": { "alias": "steps"; "required": true; "isSignal": true; }; "active": { "alias": "active"; "required": true; "isSignal": true; }; "done": { "alias": "done"; "required": false; "isSignal": true; }; "canNext": { "alias": "canNext"; "required": false; "isSignal": true; }; "canFinish": { "alias": "canFinish"; "required": false; "isSignal": true; }; "busy": { "alias": "busy"; "required": false; "isSignal": true; }; "backKey": { "alias": "backKey"; "required": false; "isSignal": true; }; "nextKey": { "alias": "nextKey"; "required": false; "isSignal": true; }; "finishKey": { "alias": "finishKey"; "required": false; "isSignal": true; }; }, { "back": "back"; "next": "next"; "finish": "finish"; }, never, ["*", "[slot=actions]"], true, never>;
}
//# sourceMappingURL=ui-shared-wizard.component.d.ts.map