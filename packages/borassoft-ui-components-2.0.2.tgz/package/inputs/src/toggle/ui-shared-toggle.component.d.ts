import { FormControl } from '@angular/forms';
import * as i0 from "@angular/core";
/** The one on/off switch: a boolean FormControl with a translated label (or projected content). */
export declare class UiSharedToggleComponent {
    control: import("@angular/core").InputSignal<FormControl<boolean>>;
    labelKey: import("@angular/core").InputSignal<string>;
    /** A sentence of help under the control. */
    hintKey: import("@angular/core").InputSignal<string>;
    protected required: import("@angular/core").Signal<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UiSharedToggleComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UiSharedToggleComponent, "ui-shared-toggle", never, { "control": { "alias": "control"; "required": true; "isSignal": true; }; "labelKey": { "alias": "labelKey"; "required": false; "isSignal": true; }; "hintKey": { "alias": "hintKey"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}
//# sourceMappingURL=ui-shared-toggle.component.d.ts.map