import * as i0 from "@angular/core";
/**
 * The application's top bar: sticky, one row, three slots.
 *
 * ```html
 * <ui-shared-app-header>
 *   <a slot="brand" routerLink="/" class="ui-shared-app-header__brand">…mark + wordmark…</a>
 *   <nav slot="nav">…primary links…</nav>
 *   <div slot="actions">…language, theme, user menu…</div>
 * </ui-shared-app-header>
 * ```
 * Height is `--header-h` (also the side panel's sticky offset). Helper classes for the slots'
 * content live in the theme: `__brand`, `__mark`, `__wordmark`, `__sep`, `__user`, `__user-name`, `__user-role`.
 */
export declare class UiSharedAppHeaderComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<UiSharedAppHeaderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UiSharedAppHeaderComponent, "ui-shared-app-header", never, {}, {}, never, ["[slot=brand]", "[slot=nav]", "[slot=actions]"], true, never>;
}
//# sourceMappingURL=ui-shared-app-header.component.d.ts.map