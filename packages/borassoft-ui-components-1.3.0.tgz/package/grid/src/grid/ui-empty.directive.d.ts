import * as i0 from "@angular/core";
/**
 * Tells whether the host rendered any element at all. Lets a template hide a
 * control whose projected content ended up empty (a row-actions menu with no
 * items for that row) without knowing what the content decides.
 *
 *   <div hidden uiEmpty #probe="uiEmpty"><ng-container [ngTemplateOutlet]="actions" /></div>
 *   @if (!probe.empty()) { ...trigger... }
 */
export declare class UiEmptyDirective {
    readonly empty: import("@angular/core").WritableSignal<boolean>;
    private el;
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<UiEmptyDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<UiEmptyDirective, "[uiEmpty]", ["uiEmpty"], {}, {}, never, never, true, never>;
}
//# sourceMappingURL=ui-empty.directive.d.ts.map