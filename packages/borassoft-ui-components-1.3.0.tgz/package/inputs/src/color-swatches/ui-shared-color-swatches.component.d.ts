import { FormControl } from '@angular/forms';
import * as i0 from "@angular/core";
/** The default swatch palette; the first entry is the natural default for a new record. */
export declare const UI_COLOR_PRESETS: string[];
/**
 * A row of colour swatches bound to a string control (`#rrggbb`). With `optional` a
 * leading "none" swatch clears the value - the record then inherits its parent's colour.
 *
 *   <ui-shared-color-swatches [control]="form.controls.color" optional />
 */
export declare class UiSharedColorSwatchesComponent {
    control: import("@angular/core").InputSignal<FormControl<string> | FormControl<string | null>>;
    presets: import("@angular/core").InputSignal<string[]>;
    optional: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    /** Translation key of the "none" swatch's label. */
    noneKey: import("@angular/core").InputSignal<string>;
    protected pick(hex: string | null): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<UiSharedColorSwatchesComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UiSharedColorSwatchesComponent, "ui-shared-color-swatches", never, { "control": { "alias": "control"; "required": true; "isSignal": true; }; "presets": { "alias": "presets"; "required": false; "isSignal": true; }; "optional": { "alias": "optional"; "required": false; "isSignal": true; }; "noneKey": { "alias": "noneKey"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=ui-shared-color-swatches.component.d.ts.map