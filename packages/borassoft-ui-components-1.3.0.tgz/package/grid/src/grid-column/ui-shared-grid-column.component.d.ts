import { TemplateRef } from '@angular/core';
import * as i0 from "@angular/core";
/**
 * Column descriptor projected as a child of <ui-shared-grid>. Carries:
 *   - <c>key</c>: short identifier (used by ngFor + as a debug aid).
 *   - <c>labelKey</c>: translation key for the table header cell.
 *   - <c>sortField</c>: OData PascalCase field name for <c>$orderby</c>.
 *                       Omit to make the column non-sortable.
 *   - <c>align</c>: optional cell alignment hint (default left).
 *   - A single projected <c>#cell</c> ng-template that receives the row
 *     via <c>let-row</c> and renders the cell body.
 *
 * Example:
 * <pre>
 *   &lt;ui-shared-grid-column key="email"
 *                          labelKey="users.email"
 *                          sortField="Email"&gt;
 *     &lt;ng-template #cell let-u&gt;{{ u.email }}&lt;/ng-template&gt;
 *   &lt;/ui-shared-grid-column&gt;
 * </pre>
 */
export declare class UiSharedGridColumnComponent {
    key: import("@angular/core").InputSignal<string>;
    labelKey: import("@angular/core").InputSignal<string>;
    sortField: import("@angular/core").InputSignal<string | undefined>;
    align: import("@angular/core").InputSignal<"left" | "right" | "center">;
    /** Body cell template. Required — receives the row via <c>$implicit</c>. */
    cell: import("@angular/core").Signal<TemplateRef<{
        $implicit: unknown;
    }>>;
    /** Whether this column participates in sorting (has a sortField). */
    get sortable(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<UiSharedGridColumnComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UiSharedGridColumnComponent, "ui-shared-grid-column", never, { "key": { "alias": "key"; "required": true; "isSignal": true; }; "labelKey": { "alias": "labelKey"; "required": true; "isSignal": true; }; "sortField": { "alias": "sortField"; "required": false; "isSignal": true; }; "align": { "alias": "align"; "required": false; "isSignal": true; }; }, {}, ["cell"], never, true, never>;
}
//# sourceMappingURL=ui-shared-grid-column.component.d.ts.map